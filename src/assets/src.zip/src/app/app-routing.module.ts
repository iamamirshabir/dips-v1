import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { AuthGuard } from './auth-helpers/auth.guard';
import { ApplicationLoaderComponent } from './application-loader/application-loader.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';

const routes: Routes = [
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)},
  { path: 'resend-email', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)},
  { path: 'shadowplanner', loadChildren: () => import('./com/daisy/sp/main-layout/main-layout.module').then(m => m.MainLayoutModule),canActivate: [AuthGuard] },
  { path: 'reset-password', component: ForgotPasswordComponent},
  { path: '', component: ApplicationLoaderComponent,canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
      preloadingStrategy: PreloadAllModules,
      useHash: true ,
      onSameUrlNavigation: "reload"
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
