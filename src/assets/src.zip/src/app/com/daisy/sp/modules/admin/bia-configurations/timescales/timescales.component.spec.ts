import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimescalesComponent } from './timescales.component';

describe('TimescalesComponent', () => {
  let component: TimescalesComponent;
  let fixture: ComponentFixture<TimescalesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TimescalesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TimescalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
