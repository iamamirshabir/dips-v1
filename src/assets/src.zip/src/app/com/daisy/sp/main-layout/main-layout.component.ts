import { Component, OnInit, HostListener, ViewChild, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { MediaObserver } from '@angular/flex-layout';
import { SidenavComponent } from './sidenav/sidenav.component';
import { BaseClass } from '../utils/baseclass';
import { ModuleIDs } from '../utils/constants/module-ids';
import { RouteParams } from '../utils/model.route-params';
@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.sass']
})
export class MainLayoutComponent extends BaseClass implements OnInit {
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
  opened = true;
  over = 'side';
  expandHeight = '42px';
  collapseHeight = '42px';
  displayMode = 'flat';
  errorMessage: string;
  header: any = 'Home';
  watcher: Subscription;
  sidenavIsOpened: boolean = true;
  activeLinkId: any = 0;
  sideMenu: any = [{ id: ModuleIDs.BIA, key: "sp.modulesName.bia", icon: "schema" },
  { id: ModuleIDs.BCP, key: "sp.modulesName.bcp", icon: "menu_book" },
  { id: ModuleIDs.NOTIFICATION, key: "sp.modulesName.notification", icon: "notifications_active" },
  { id: ModuleIDs.RECOVERY, key: "sp.modulesName.recovery", icon: "maps_home_work" },
  { id: ModuleIDs.EXERCISING, key: "sp.modulesName.exercising", icon: "rule" },
  { id: ModuleIDs.ADMIN, key: "sp.modulesName.admin", icon: "miscellaneous_services" }]
  @ViewChild('sideNavBar') sideNavBar: any;
  @ViewChild('sideBarPanel') sideBarPanel: SidenavComponent;
  @ViewChild('sideNav') sideNav: any;


  constructor(private breakpointObserver: BreakpointObserver,
    private router: Router, @Inject(MediaObserver) media,) {
    super()
  }

  ngOnInit() {
    if (window.innerWidth <= 599) {
      this.sidenavIsOpened = false;
    }
    if (document.querySelectorAll(".leader-line")) {
      let myElements = document.querySelectorAll(".leader-line");
      if (myElements) {
        for (let i = 0; i < myElements.length; i++) {
          myElements[i]['style'].display = "none";
        }
      }
    }
  }

  public toggleSideBar(menuId) {
    this.activeLinkId = menuId;
    this.sideNavBar.toggle();
    this.sideBarPanel.getMenusByModuleId(menuId);
  }
  public toggleSidenav(menuId) {
    this.sideNav.toggle();
  }
  public menuClickHandler(menu) {
    this.activeLinkId = null;
    this.sideNavBar.toggle();
    if (menu !== null) {
      if (menu.hasChild) {
        this.activeLinkId = menu.moduleId;
        this.sideBarPanel.getMenusByModuleId(menu.moduleId, menu.id);
        setTimeout(() => {
          this.sideNavBar.toggle();
        }, 500);
      } else {
        let routeParams = new RouteParams;
        routeParams.routerLink = menu.routerLink;
        routeParams.pageState = this.PageState.ADD_STATE;
        routeParams.data = menu;
        this.routingService.openPage(routeParams.routerLink, routeParams);
      }
    }
  }
  public parentMenuHandler(menu) {
    this.activeLinkId = null;
    this.sideNavBar.toggle();
    setTimeout(() => {
      this.toggleSideBar(menu.moduleId);
    }, 500);
  }
  @HostListener('window:resize')
  public onWindowResize(): void {
    if (window.innerWidth <= 599) {
      this.sidenavIsOpened = false;

    }
    else {
      this.sidenavIsOpened = true;

    }
  }

}
