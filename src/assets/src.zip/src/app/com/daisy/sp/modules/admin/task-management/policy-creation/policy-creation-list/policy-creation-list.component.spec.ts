import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyCreationListComponent } from './policy-creation-list.component';

describe('PolicyCreationListComponent', () => {
  let component: PolicyCreationListComponent;
  let fixture: ComponentFixture<PolicyCreationListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyCreationListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyCreationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
