import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AngularMaterialModule } from "src/app/app.material.module";
import { ComponentsModule } from "../../../../common/components/components.module";
import { DependencySelectionComponent } from "./dependency-selection.component";

const routes: Routes = [
    {
      path: '', component: DependencySelectionComponent,
    }
  ]; 
  
  @NgModule({
    declarations: [DependencySelectionComponent],
    imports: [
      ComponentsModule,
      AngularMaterialModule,
      RouterModule.forChild(routes) 
    ]
  })
  export class DependencySelectionModule { }
  