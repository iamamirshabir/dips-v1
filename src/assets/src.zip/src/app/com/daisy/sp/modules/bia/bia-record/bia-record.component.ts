import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Chart } from 'chart.js';
import { SpChipFormFieldComponent } from '../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { BaseClass } from '../../../utils/baseclass';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { TimeScalesConstant } from '../../../utils/constants/timeScales-constant';
import { RouteParams } from '../../../utils/model.route-params';
import { BiaRecordsListComponent } from '../bia-records-list/bia-records-list.component';
import { BIAService } from '../bia.service';

@Component({
  selector: 'app-bia-record',
  templateUrl: './bia-record.component.html',
  styleUrls: ['./bia-record.component.sass']
})
export class BiaRecordComponent extends BaseClass implements OnInit {
  exerciseChart: Chart;
  biaRecordForm: FormGroup;
  biaRecord: any;
  addState: boolean = true;
  options = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      display: true
    },
    tooltips: {
      enabled: true
    }
  }
  categoryRecord: any;
  dependencyList: any = [
    { key: "bia.biaRecord.generalInformation", icon: "info", route: RouteConstants.BIA_RECORD_TAB_GENERAL_INFORMATION, complete: false, checked: true },
    { key: "bia.biaRecord.impactAssesment", icon: "apps", route: RouteConstants.BIA_RECORD_TAB_IMPACT_ASSESMENT, complete: false, checked: true },
    { key: "bia.biaRecord.processes", icon: "settings_backup_restore", route: RouteConstants.BIA_RECORD_TAB_PROCESSES, complete: false, checked: true },
    { key: "bia.biaRecord.Products", icon: "launch", route: RouteConstants.BIA_RECORD_TAB_PROUDUCTS_SERVICES, complete: false, checked: true },
    { key: "bia.biaRecord.risks", icon: "warning", route: RouteConstants.BIA_RECORD_TAB_RISKS, complete: false, checked: true },

  ];

  lowerDependencyList: any = [
    { key: "bia.biaRecord.Locations", icon: "location_searching", route: RouteConstants.BIA_RECORD_TAB_LOCATIONS, complete: false, checked: true },
    { key: "bia.biaRecord.resources", icon: "supervised_user_circle", route: RouteConstants.BIA_RECORD_TAB_RESOURCES, complete: false, checked: true },
    { key: "bia.biaRecord.itServices", icon: "people", route: RouteConstants.BIA_RECORD_TAB_IT_SERVICE, complete: false, checked: true },
    { key: "bia.biaRecord.suppliers", icon: "business_center", route: RouteConstants.BIA_RECORD_TAB_SUPPLIERS, complete: false, checked: true },
    { key: "bia.biaRecord.businessArea.businessArea", icon: "business", route: RouteConstants.BIA_RECORD_TAB_BUSINESS_AREA_LIST, complete: false, checked: true }
  ];

  // { key: "bia.biaRecord.dependencyList", route: RouteConstants.BIA_RECORD_LIST, complete: false }]
  public static RPO_TYPE: number = 1;
  public static RTO_TYPE: number = 2;
  public static ART_TYPE: number = 3;
  RTOdurationString: any = [];
  MTPDdurationString: any = [];
  timeScales: any = [];
  routeParams: any;
  biaRecordId: any;
  RTOArray: any = [];
  MTPDArray: any = [];
  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  dependencyCount: number;
  unfinishedCount: number = 0;
  finishedCount: any = 0;
  biaType: any;
  value: any = 0;
  biaBadgeTitle: string;
  dependencyData: any;
  typeNumber: any;
  biaListType: BiaRecordsListComponent;
  dependencyNewList: any = [];
  dependencyNewList1: any = [];
  divActivate: boolean;
  p = true;
  pS = true;
  location = true;
  resource = true;
  iT = true;
  supplier = true;
  bA = true;
  dependencyMap = "Dependency Map";
  dependencyTypeBits: any;
  constructor(private formBuilder: FormBuilder, private changeDetect: ChangeDetectorRef, private biaService: BIAService) {
    super();

  }
  get f() { return this.biaRecordForm.controls; }
  ngOnInit() {

    this.initializeData();

  }
  ngAfterViewChecked(): void {
    this.changeDetect.detectChanges();

  }
  formatLabel(value: number) {
    return value + '%';
  }

  timePointType(obj) {
    if (obj) {
      if (obj.recoveryTimeObject != null) {
        this.RTOdurationString = this.timePointDurationbyMeasure(obj.recoveryTimeObject.measure, obj.recoveryTimeObject.duration);
        obj.recoveryTimeObject['durationString'] = this.RTOdurationString;
        this.RTOArray.push(obj.recoveryTimeObject);
      }
      if (obj.mtpd != null) {
        this.MTPDdurationString = this.timePointDurationbyMeasure(obj.mtpd.measure, obj.mtpd.duration);
        obj.mtpd['durationString'] = this.MTPDdurationString;
        this.MTPDArray.push(obj.mtpd);
      }
    }


  }
  initializeData() {
    this.biaRecordForm = this.formBuilder.group({
      id: [null],
      name: ['', Validators.required],
      recoveryTimeObject: [null],
      mtpd: [null],
      lastUpdateDate: [null],
      lastReviewDate: [null],
      nextReviewDate: [null],
      reviewDate: [null],
      type: [1],
      owner: [null, Validators.required],
      organisation: [this.organisation],
      category: [null],
      generalComplete: [false],
      businessAreaComplete: [false],
      impactAssessmentComplete: [false],
      processComplete: [false],
      locationComplete: [false],
      productServicesComplete: [false],
      suppliersComplete: [false],
      itServicesComplete: [false],
      resourcesComplete: [false],
      risksComplete: [false],
      version: [null],
      description: [''],
      recoveryPolicy: [null],
      businessPeaks: [],
      operatingHours: [],
      locationHeadCount: [],
      headCount: [],
      realEntity: [null],
      participants: [null],
      status: [0],
      updatedBy: [null],
      updatedByName: [""]
    });
  }

  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    if (this.routeParams.data.categoryRecord != null) {
      this.biaRecordId = this.routeParams.data.categoryRecord.id;
    }
    else {
      this.biaRecordId = this.routeParams.data.id;
    }
    this.biaType = this.routeParams.parentParams;
    if (this.routeParams.data.category != null) {
      this.typeNumber = this.routeParams.data.category.type;
    }
    else {
      this.typeNumber = this.routeParams.data.categoryRecord.category.type;
    }
    if (this.routedPageState != 1) {
      this.biaService.getByCategoryRecordIdAndStatus(this.biaRecordId, 0).subscribe((res) => {
        this.biaRecord = res;
        this.addState = false;
        this.setDependencyChecks();
        this.patchFormValues();
      }, err => {
        this.biaRecordForm.patchValue({
          name: this.routeParams.data.name,
          description: this.routeParams.data.description,
          recoveryTimeObject: this.routeParams.data.rto,
          recoveryPolicy: this.routeParams.data.category.recoveryPolicy
        });
        this.routedPageState = 1;
        this.setDependencyChecks();
      });
    }

  }
  setDependencyChecks() {
    this.biaService.getBiaDependencySelectionData(this.organisation.id).subscribe(res => {
      this.dependencyData = res;
      this.dependencyData.forEach(element => {
        if (this.typeNumber === element.type) {
          if (element.businessArea == false) {
            this.bA = element.businessArea
            this.lowerDependencyList[4].checked = this.bA;
          }
          else if (element.businessArea) {
            this.lowerDependencyList[4].checked = true;
            if (this.biaRecord) {
              if (this.biaRecord.businessAreaComplete) {
                this.lowerDependencyList[4].complete = this.biaRecord.businessAreaComplete;
              }
            }
          }
          if (element.it == false) {
            this.iT = element.it;
            this.lowerDependencyList[2].checked = this.iT;
          }
          else if (element.it) {
            if (this.biaRecord) {
              if (this.biaRecord.itServicesComplete) {
                this.lowerDependencyList[2].complete = this.biaRecord.itServicesComplete;
              }
            }
          }
          if (element.location == false) {
            this.location = element.location;
            this.lowerDependencyList[0].checked = this.location;
          }
          else if (element.location) {
            if (this.biaRecord) {
              if (this.biaRecord.locationComplete) {
                this.lowerDependencyList[0].complete = this.biaRecord.locationComplete;
              }
            }
          }
          if (element.processes == false) {
            this.p = element.processes;
            this.dependencyList[2].checked = this.p;
          }
          else if (element.processes) {
            if (this.biaRecord) {
              if (this.biaRecord.processComplete) {
                this.dependencyList[2].complete = this.biaRecord.processComplete;
              }
            }
          }
          if (element.resource == false) {
            this.resource = element.resource;
            this.lowerDependencyList[1].checked = this.resource;
          }
          else if (element.resource) {
            if (this.biaRecord) {
              if (this.biaRecord.resourcesComplete) {
                this.lowerDependencyList[1].complete = this.biaRecord.resourcesComplete;
              }
            }
          }
          if (element.productAndServices == false) {
            this.pS = element.productAndServices;
            this.dependencyList[3].checked = this.pS;
          }
          else if (element.productAndServices) {
            if (this.biaRecord) {
              if (this.biaRecord.productServicesComplete) {
                this.dependencyList[3].complete = this.biaRecord.productServicesComplete;
              }
            }
          }
          if (element.supplier == false) {
            this.supplier = element.supplier;
            this.lowerDependencyList[3].checked = this.supplier;
          }
          else if (element.supplier) {
            if (this.biaRecord) {
              if (this.biaRecord.suppliersComplete) {
                this.lowerDependencyList[3].complete = this.biaRecord.suppliersComplete;
              }
            }
          }
          if (this.biaRecord) {
            if (this.biaRecord.generalComplete) {
              this.dependencyList[0].complete = true;
            }
            if (this.biaRecord.impactAssessmentComplete) {
              this.dependencyList[1].complete = true;
            }
            if (this.biaRecord.risksComplete) {
              this.dependencyList[4].complete = true;

            }
          }
        }
      });
      this.dependencyList.forEach(element => {
        if (element.checked == true) {
          this.dependencyNewList.push(element);
        }
      });

      this.lowerDependencyList.forEach(element => {
        if (element.checked == true) {
          this.dependencyNewList1.push(element);
        }
      });
      if (this.dependencyNewList.length <= 5 && this.dependencyNewList1.length == 0) {
        this.divActivate = true;
      }
      else {
        this.divActivate = false;
      }
      this.dataStatistics()
    });
  }
  patchFormValues() {
    this.ownerContact.patchDataInControls(this.biaRecord['owner']);
    this.biaRecord.name = this.routeParams.data.name;
    this.biaRecord.description = this.routeParams.data.description;
    if (this.biaRecord.updatedBy != null) {
      this.biaRecord.updatedByName = this.biaRecord.updatedBy.firstName + " " + this.biaRecord.updatedBy.lastName;
    }
    if (this.routeParams.data.categoryRecord) {
      this.biaRecord.recoveryPolicy = this.routeParams.data.categoryRecord.category.recoveryPolicy;
    }
    else {
      this.biaRecord.recoveryPolicy = this.routeParams.data.category.recoveryPolicy;
    }
    this.timePointType(this.biaRecord);
    this.biaRecordForm.patchValue(this.biaRecord);

  }
  dataStatistics() {
    var checkDependencies = [...this.dependencyNewList, ...this.dependencyNewList1]
    checkDependencies.forEach(countBooleans => {
      if (countBooleans.complete) {
        this.finishedCount++;
      }
      else
        this.unfinishedCount++;
    });
    var total = this.unfinishedCount + this.finishedCount;
    var percentCalculate = this.finishedCount * 100;
    this.value = Math.floor(percentCalculate / total);
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  biaDependencyClicked(dependencyType) {
    this.openForm(this.biaRecord, this.routedPageState, dependencyType);
  }
  openForm(biaRecord, routedPageState, dependecyType) {
    let routeParams: RouteParams = new RouteParams();

    routeParams.parentParams = this.routeParams.parentParams;
    routeParams.pageState = routedPageState;
    if (dependecyType != this.dependencyMap) {
      routeParams.title = dependecyType.key;
      routeParams.routerLink = dependecyType.route;
    }
    else {
      routeParams.routerLink = RouteConstants.DEPENDENCY_MAP;
    }

    if (biaRecord) {
      routeParams.data = biaRecord;
      routeParams.nextRouterLink = [...this.dependencyNewList, ...this.dependencyNewList1];
    }
    routeParams.parentParams = this.biaType;
    routeParams.id = routeParams.data['id'];
    this.routingService.openPage(routeParams.routerLink, routeParams);

  }
  onSubmit(btnAction: ButtonActions) {
    if (this.biaRecordForm.invalid) {
      return
    }
    this.showLoader();
    if (Array.isArray(this.biaRecordForm.value.owner)) {
      this.biaRecordForm.value.owner.forEach(owners => {
        this.biaRecordForm.value.owner = owners;
      });
    }
    if (this.routeParams.data.categoryRecord != null) {
      this.biaRecordForm.value.categoryRecord = this.routeParams.data.categoryRecord;
    }
    else {
      this.biaRecordForm.value.categoryRecord = this.routeParams.data;
    }
    this.biaRecordForm.value.name = this.routeParams.data.name;
    this.biaRecordForm.value.description = this.routeParams.data.description;
    if (this.routeParams.data.category != null) {
      this.biaRecordForm.value.recoveryPolicy = this.routeParams.data.category.recoveryPolicy;
    }
    else {
      this.biaRecordForm.value.recoveryPolicy = this.routeParams.data.recoveryPolicy;
    }

    this.biaService.saveBiaRecord(this.biaRecordForm.value).subscribe((res) => {
      this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD_LIST, this.routeParams.parentParams);
      this.addState = false;
      this.hideLoader();
      if (this.routedPageState === 1) {
        this.alertService.success("Successfully Created");
      }
      else {
        this.alertService.success("Successfully Updated")
      }

    }, err => {
      this.hideLoader();
      console.log(err);
    })
  }
  goBackToMainPage(btnAction: ButtonActions) {

    if (this.routeParams.parentParams === null) {
      this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD_LIST, this.routeParams);
    }
    else {
      this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD_LIST, this.routeParams.parentParams);
    }
  }
}
