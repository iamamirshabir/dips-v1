import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { IListingView } from './listing-view.interface';

@Injectable({
  providedIn: 'root'
})
export class ListingViewService {

  constructor() { }

  private subject = new Subject<any>();

  sendListingView(listingView: IListingView) {
      this.subject.next(listingView);
  }

  clearListingView() {
      this.subject.next();
  }

  onListingView(): Observable<IListingView> {
      return this.subject.asObservable();
  }
}
