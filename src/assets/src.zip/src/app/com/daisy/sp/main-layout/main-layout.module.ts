import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MainLayoutComponent } from './main-layout.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { BCPModule } from '../modules/bcp/bcp.module';
import { BIAModule } from '../modules/bia/bia.module'
import { MainLayoutRoutingModule } from './main-layout-routing.module';
import { FilterPipe } from '../common/pipes/filter.pipe';
import { NotificationsComponent } from './header/notifications/notifications.component';
import { HelpComponent } from './header/help/help.component';
import { UserMenuComponent } from './header/user-menu/user-menu.component';
import { OrgStructureComponent } from './header/org-structure/org-structure.component';
import { SearchComponent } from './header/search/search.component';
import { SettingComponent } from './header/setting/setting.component';
import { DashboardComponent } from '../modules/dashboard/dashboard.component';
import { BreadcrumbComponent } from '../common/components/breadcrumb/breadcrumb.component';
import { PasswordPolicyComponent } from '../modules/admin/password/password-policy/password-policy.component';
import { ChangePasswordComponent } from '../modules/admin/password/change-password/change-password.component';
import { ComponentsModule } from '../common/components/components.module';
import { SPLoaderComponent } from '../common/components/SPloader/SPloader.component';
import { MyDashboardComponent } from '../modules/my-dashboard/my-dashboard.component';


@NgModule({
  declarations: [MainLayoutComponent, HeaderComponent, FooterComponent, SidenavComponent, DashboardComponent,
        NotificationsComponent,
        BreadcrumbComponent,
        SPLoaderComponent,
        HelpComponent,
        UserMenuComponent,
        PasswordPolicyComponent,
        OrgStructureComponent,
        SearchComponent,
        FilterPipe,
        SettingComponent,
        ChangePasswordComponent,
        MyDashboardComponent,
     
      ],
  imports: [      
    ComponentsModule,
    MainLayoutRoutingModule,
    BCPModule,
    BIAModule
  ],
  exports:[],
  providers: [],
  bootstrap: [MainLayoutComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MainLayoutModule {}
