import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';

@Component({
  selector: 'app-category-productService-form',
  templateUrl: './category-productService-form.component.html',
  styleUrls: ['./category-productService-form.component.sass']
})
export class CategoryProductServiceFormComponent extends BaseClass implements OnInit {
  categoryProductServiceForm: FormGroup;
  submitted = false;
  ButtonActions = ButtonActions;
  routeParams: any;
  subCategories: any;
  RTOArray: any =[];
  categorySupplier: any;
  realEntities: any;
  selectedART: any;
  @ViewChild('perspectiveDepartmental') perspectiveDepartmental: SpChipFormFieldComponent;
  @ViewChild('perspectiveLocational') perspectiveLocational: SpChipFormFieldComponent;
  categoryObject: any;
  cat_Supplier_Id: any;
  categorySupplierObj: any;
  categorySupplierRealEntityObj: any;
  categorySupplierInternalOwnerObj: any;
  categorySupplierAccountManagerObj: any;
  businessEntitiesList: any;
  cat_product_service_Id: any;
  cat_product_service_data: any;
  cat_product_service_type: any;
  perspectiveLocationalObj: any;
  perspectiveDepartmentalObj: any;
  rtoTimeScale: any;
  timeScales: any;
  hierarchy:string;
  public RTOdurationString: any = [];
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.categoryProductServiceForm.controls; }
  ngOnInit(): void {

    this.categoryProductServiceForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: ['', [Validators.required]],
      description: [''],
      category: [null],
      perspectiveDepartmental : [null],
      perspectiveLocational : [null] ,
      rto: [null],
      art:[null],
      ola:[''],
      sla: [''],
      categoryName:[null],
      businessEntities:[null],
      version: [null]
    });
    this.loadingService.enableLoading();
    this.getBusinessEntity();
    this.getRealEntity();
 
  }
 

  openFormByState(routeParams) {
    console.log("reciever");
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_product_service_Id = this.routeParams['id'];
    this.cat_product_service_data = this.routeParams['data'];
    this.hierarchy = this.cat_product_service_data.hierarchy;
    if (this.cat_product_service_Id) {
      this.getCategoryProductServiceByIds(this.cat_product_service_Id);
    }
    if( this.cat_product_service_data){
      this.cat_product_service_type = this.cat_product_service_data['type'];
      this.rtoTimeScale = this.cat_product_service_data['rtoTimeScale'];
    
      if (this.rtoTimeScale != null) {
        this.RTOArray = this.setTimeScalesList(this.rtoTimeScale.id,TimeScalesConstant.RTO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.RTO_TYPE)
            this.RTOArray = data.list;
           });
      }
 
      this.getCategoryByOrgId();
      this.hierarchy = this.cat_product_service_data.hierarchy;
      this.categoryProductServiceForm.controls['category'].setValue(this.cat_product_service_data);
    }
  }
  getCategoryProductServiceByIds(id) {
    this.showLoader();
    this.CategoryProductServiceService.getCategoryProductServiceById(id).subscribe(data => {
      this.hideLoader();
      this.categoryObject = data;
      this.patchFormData();
    }, error => {
      this.hideLoader();
    })

  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.perspectiveLocational.patchDataInControls(this.categoryProductServiceForm.controls['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryProductServiceForm.controls['perspectiveDepartmental']);
    } else {

      this.perspectiveLocational.patchDataInControls(this.categoryObject['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryObject['perspectiveDepartmental']);
      this.categoryProductServiceForm.controls['id'].setValue(this.categoryObject['id']);
      this.categoryProductServiceForm.controls['version'].setValue(this.categoryObject['version']);
      this.bindJsonObjectToFormObject(this.categoryObject, this.categoryProductServiceForm);
    

    }
  }
  getCategoryByOrgId() {
    this.showLoader();
    this.CategoryProductServiceService.getSubCategories(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.subCategories = data;
      let SubCatObj =this.subCategories.find(item =>(item.type == this.cat_product_service_type));
      if(SubCatObj != undefined){
       this.categoryProductServiceForm.controls['categoryName'].setValue(SubCatObj.name);
      }
      if(this.hierarchy){
        this.categoryProductServiceForm.patchValue({ categoryName: this.hierarchy });
      }
    }, error => {
      this.hideLoader();
    })
  }
  getBusinessEntity(){
    this.showLoader();
    this.CategoryProductServiceService.getBusinessEntity(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.businessEntitiesList = data;
    }, error => {
      this.hideLoader();
    })
  }


  getCategorySupplierByOrgId() {
    this.showLoader();
    this.categoryItService.getCategorySupplierByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.categorySupplier = data;
    }, error => {
      this.hideLoader();
    })
  }
  getRealEntity() {
    this.showLoader();
    this.CategoryProductServiceService.getRealEntityByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.realEntities = data;
    }, error => {
      this.hideLoader();
    })
  }

  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.categoryProductServiceForm.invalid) {
      return;
    }
    this.categoryProductServiceForm.controls['organisation'].setValue(this.organisation);
    this.showLoader();
    this.perspectiveLocationalObj =  this.categoryProductServiceForm.value.perspectiveLocational;
    this.perspectiveDepartmentalObj =  this.categoryProductServiceForm.value.perspectiveDepartmental;

    this.categoryProductServiceForm.controls['perspectiveLocational'].setValue(this.perspectiveLocationalObj);
    this.categoryProductServiceForm.controls['perspectiveDepartmental'].setValue(this.perspectiveDepartmentalObj);
    this.CategoryProductServiceService.saveCategoryProductService(this.categoryProductServiceForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        } 
        // else if (btnType == ButtonActions.SAVE_AND_CONT) {
        //   this.contactObject = res;
        //   this.routedPageState = PageState.EDIT_STATE;
        //   this.patchFormData();
        // }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CATEGORY_PRODUCT_SERVICE_LIST);
  }

 

 
}