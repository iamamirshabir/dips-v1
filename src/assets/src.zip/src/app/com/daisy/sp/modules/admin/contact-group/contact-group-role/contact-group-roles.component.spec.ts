import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactGroupRolesComponent } from './contact-group-roles.component';

describe('ContactGroupRollsComponent', () => {
  let component: ContactGroupRolesComponent;
  let fixture: ComponentFixture<ContactGroupRolesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactGroupRolesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactGroupRolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
