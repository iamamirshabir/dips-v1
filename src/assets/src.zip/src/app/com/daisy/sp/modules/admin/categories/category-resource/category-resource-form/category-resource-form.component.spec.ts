import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryResourceFormComponent } from './category-resource-form.component';

describe('CategoryResourceFormComponent', () => {
  let component: CategoryResourceFormComponent;
  let fixture: ComponentFixture<CategoryResourceFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CategoryResourceFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoryResourceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
