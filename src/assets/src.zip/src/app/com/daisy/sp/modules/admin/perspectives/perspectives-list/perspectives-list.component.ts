import { Component, OnInit, Inject } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../real-entity/real-entity-form/real-entity-form.component'; 
import { DOCUMENT } from '@angular/common'; 
import { debounce } from '@agentepsilon/decko';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { PerspectivesFormComponent } from '../perspectives-form/perspectives-form.component';
@Component({
  selector: 'app-perspectives-list',
  templateUrl: './perspectives-list.component.html',
  styleUrls: ['./perspectives-list.component.sass']
})
export class PerspectivesListComponent extends BaseClass implements OnInit { 
  nodes: any[] = [];
  dropTargetIds = [];
  nodeLookup = {};
  dropActionTodo: DropedNodeInfo = null;
  dialogRef: MatDialogRef<PerspectivesFormComponent> | null;
  selectedNode: any;
  deletedRealEntityList: any[] = [];
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new TreeDataSource(this.treeControl, this.nodes);
  constructor(public dialog: MatDialog,
    @Inject(DOCUMENT) private document: Document) {
    super();
  }
  ngOnInit() {
    this.getRealEntitiesList();
  }
  getRealEntitiesList() {
    this.realEntityService.getPerspectivesListByOrgId(this.organisation.id).subscribe(data => { 
    this.nodes = [data];
    this.deletedRealEntityList = [];
    this.setEmptyChildren(this.nodes);
    this.prepareDragDrop(this.nodes);
    this.dataSource = new TreeDataSource(this.treeControl, this.nodes);
    }, error => { 
    });
  }

  prepareDragDrop(nodes: any[]) {
    nodes.forEach(node => {
      this.dropTargetIds.push(node.id);
      this.nodeLookup[node.id] = node;
      this.prepareDragDrop(node.children);
    });
  }
  setEmptyChildren(treeData) {
    treeData.forEach(element => {
      element.id = element.id.toString();
      if (element.children && element.children.length > 0) {
          element.children = element.children.sort((a, b) => a.order - b.order);
        this.setEmptyChildren(element.children);
      } else {
        element.children = [];
      }
    });
  }

  @debounce(50)
  dragMovedHandler(event) {
    let ele = this.document.elementFromPoint(event.pointerPosition.x, event.pointerPosition.y); 
    if (!ele) {
      this.clearDragingInfo();
      return;
    }
    let realEntityRow = ele.classList.contains("real-entity-node") ? ele : ele.closest(".real-entity-node");
    if (!realEntityRow) {
      this.clearDragingInfo();
      return;
    }
    this.dropActionTodo = {
      targetId: realEntityRow.getAttribute("node-id")
    };
    const targetRect = realEntityRow.getBoundingClientRect();
    const oneThird = targetRect.height / 3;

    if (event.pointerPosition.y - targetRect.top < oneThird) { 
      this.dropActionTodo["action"] = "before";
    } else if (event.pointerPosition.y - targetRect.top > 2 * oneThird) { 
      this.dropActionTodo["action"] = "after";
    } else { 
      this.dropActionTodo["action"] = "inside";
    }
    this.showDragingInfo();
  } 

  dropNodeHandler(event) {
    if (!this.dropActionTodo) return; 
    const draggedItemId = event.item.data;
    const parentItemId = event.previousContainer.id;
    const targetListId = this.getParentNodeId(this.dropActionTodo.targetId, this.nodes, 'main'); 
    const draggedItem = this.nodeLookup[draggedItemId]; 
    const oldItemContainer = parentItemId != 'main' ? this.nodeLookup[parentItemId].children : this.nodes;
    const newContainer = targetListId != 'main' ? this.nodeLookup[targetListId].children : this.nodes; 
    let i = oldItemContainer.findIndex(c => c.id === draggedItemId);
    oldItemContainer.splice(i, 1); 
    switch (this.dropActionTodo.action) {
      case 'before':
      case 'after':
        const targetIndex = newContainer.findIndex(c => c.id === this.dropActionTodo.targetId);
        if (this.dropActionTodo.action == 'before') {
          newContainer.splice(targetIndex, 0, draggedItem);
        } else {
          newContainer.splice(targetIndex + 1, 0, draggedItem);
        }
        break; 
      case 'inside':
        this.nodeLookup[this.dropActionTodo.targetId].children.push(draggedItem)
        this.nodeLookup[this.dropActionTodo.targetId].isExpanded = true;
        break;
    } 
    this.clearDragingInfo(true)
  }
  getParentNodeId(id: string, nodesToSearch: any[], parentId: string): string {
    for (let node of nodesToSearch) {
      if (node.id == id) return parentId;
      let ret = this.getParentNodeId(id, node.children, node.id);
      if (ret) return ret;
    }
    return null;
  }
  showDragingInfo() {
    this.clearDragingInfo();
    if (this.dropActionTodo) {
      this.document.getElementById("node-" + this.dropActionTodo.targetId).classList.add("drop-" + this.dropActionTodo.action);
    }
  }
  clearDragingInfo(dropped = false) {
    if (dropped) {
      this.dropActionTodo = null;
    }
    this.document
      .querySelectorAll(".drop-before")
      .forEach(element => element.classList.remove("drop-before"));
    this.document
      .querySelectorAll(".drop-after")
      .forEach(element => element.classList.remove("drop-after"));
    this.document
      .querySelectorAll(".drop-inside")
      .forEach(element => element.classList.remove("drop-inside"));
  } 

  activatedNodeChange(activeNode) {
    this.selectedNode = activeNode;
  }
  addNode() {
    if (this.selectedNode == null) {
      this.alertService.error("please select a parent node first");
      return;
    }
    this.openRealEntityDialog(null, this.selectedNode, this.PageState.ADD_STATE);
  }
  openRealEntityDialog(node, parentNode, pageState) {
    let data = { "node": node, "parentNode": parentNode, "pageState": pageState }
    this.dialogRef = this.dialog.open(PerspectivesFormComponent, {
      height: '450',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });
    this.dialogRef.beforeClosed().subscribe((result: any) => { 
    });
    this.dialogRef.afterClosed().subscribe((result: any) => {
      let cloneObject = Object.assign({}, result.parentNode);
      cloneObject.children = [];
      if (result && result.pageState == this.PageState.ADD_STATE) {
        let node: any = {
          id: null,
          name: result.node ? result.node.name : "",
          organisation: { "id": this.organisation.id, "version": 0 },
          children: [],
          externalUid: null,
          address: result.node ? result.node.address : "",
          lk: null,
          rk: null,
          bcCoordinator: null,
          order: result.parentNode ? result.parentNode.children.length + 1 : 0,
          parent: cloneObject,
          perspectiveGroup: result.node ? result.node.perspectiveGroup : null,
        }
        this.addNewNode(node, result.parentNode);
      } else if (result && result.pageState == this.PageState.EDIT_STATE) {

      }
      this.dialogRef = null;
    });
  }
  addNewNode(node: any, parentNode: any) {
    this.dataSource.add(node, parentNode);
    this.selectedNode = null;
  }
  editNode(node: any = null) {
    this.openRealEntityDialog(node, this.selectedNode, this.PageState.EDIT_STATE);
  }
  remove(node: any) {
    let parentNode = this.nodes[0];
    if (node.children && node.children.length > 0) {
      node.children.forEach(element => {
        parentNode.children.push(element);
      });
    }
    this.dataSource = new TreeDataSource(this.treeControl, this.nodes);
    this.deletedRealEntityList.push(node);
    this.dataSource.remove(node);
  }
  saveRealEntities() {
    this.showLoader();
    let data: any = this.nodes[0];
    if (this.deletedRealEntityList && this.deletedRealEntityList.length > 0) {
      data.toRemove = this.deletedRealEntityList;
    }
    this.realEntityService.savePerspective(data).subscribe(data => {
      this.hideLoader();
      this.deletedRealEntityList = [];  
      this.getRealEntitiesList();
    }, error => {
      console.log("error", error);
      this.hideLoader();
    });
  }
  setNode(child,index):any{
    child.order = index;
    return {node:child};
  }
}
export interface DropedNodeInfo {
  targetId: string;
  action?: string;
} 
export class TreeDataSource extends MatTreeNestedDataSource<any> {
  constructor(
    private treeControl: NestedTreeControl<any>,
    intialData: any[]
  ) {
    super();
    this._data.next(intialData);
  }

  public add(node: any, parent: any) {
    const newTreeData = {
      id: null,
      name: null,
      organisation: null,
      children: this.data,
      externalUid: null,
      address: null,
      lk: null,
      rk: null,
      bcCoordinator: null,
      parent: null
    }; 
    this._add(node, parent, newTreeData);
    this.data = newTreeData.children;
  }

  public remove(node: any) {
    const newTreeData = {
      id: null,
      name: null,
      organisation: null,
      children: this.data,
      externalUid: null,
      address: null,
      lk: null,
      rk: null,
      bcCoordinator: null,
      parent: null
    };
    this._remove(node, newTreeData);
    this.data = newTreeData.children;
  }

  protected _add(newNode: any, parent: any, tree: any) {
    if (tree === parent) {
      tree.children = [...tree.children!, newNode];
      this.treeControl.expand(tree);
      return true;
    }
    if (!tree.children) {
      return false;
    }
    return this.update(tree, this._add.bind(this, newNode, parent));
  }

  _remove(node: any, tree: any): boolean {
    if (!tree.children) {
      return false;
    }
    const i = tree.children.indexOf(node);
    if (i > -1) {
      tree.children = [
        ...tree.children.slice(0, i),
        ...tree.children.slice(i + 1)
      ];
      this.treeControl.collapse(node);
      return true;
    }
    return this.update(tree, this._remove.bind(this, node));
  }

  protected update(tree: any, predicate: (n: any) => boolean) {
    let updatedTree: any, updatedIndex: number;

    tree.children!.find((node, i) => {
      if (predicate(node)) {
        updatedTree = { ...node };
        updatedIndex = i;
        this.moveExpansionState(node, updatedTree);
        return true;
      }
      return false;
    });

    if (updatedTree!) {
      tree.children![updatedIndex!] = updatedTree!;
      return true;
    }
    return false;
  }

  moveExpansionState(from: any, to: any) {
    if (this.treeControl.isExpanded(from)) {
      this.treeControl.collapse(from);
      this.treeControl.expand(to);
    }
  }
}