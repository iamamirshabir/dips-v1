import { Component, OnInit } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ActivatedRoute, Router } from '@angular/router';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { TimescalesFormComponent } from '../timescales-form/timescales-form.component';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-timescales-list',
  templateUrl: './timescales-list.component.html',
  styleUrls: ['./timescales-list.component.sass']
})
export class TimescalesListComponent extends BaseClass implements OnInit {
 
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  dialogRef: MatDialogRef<TimescalesFormComponent> | null;
  myOrganisation: any;
  timeScales: any[];
  constructor(private router: Router, protected activatedRoute: ActivatedRoute,
      public dialog: MatDialog,private translate: TranslateService) {
      super();
  }

  ngOnInit(): void {
      this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
      { key: 'name', name: 'Name', checked: 'true' },
      // { key: 'categoryType', name: 'Type' ,checked: 'true'},
      { key: 'description', name: 'Description', checked: 'true' },
      { key: 'typeName', name: 'Type', checked: 'true' },
      { key: 'timeScalesDta', name: 'Duration', checked: 'true' },
      { key: 'action', name: '', checked: 'true' }];

      this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
      { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

      this.setDataTable([]);
  }
  ngAfterViewInit() {

      this.getTimeScaleList();
      this.timeScales = TimeScalesConstant.timeScalesTypes;
      this.hideLoader();

  }
  getTimeScaleList() {
      this.showLoader();
      this.timeScalesService.getTimeScalesListByOrgId(this.organisation.id).
          subscribe(res => {
              this.hideLoader();
              this.tableData = res;
              this.setFormData(this.tableData);
              this.setDataTable(this.tableData);
          }, error => {
              this.hideLoader();
              this.tableData = [];
              this.setDataTable(this.tableData);
          })
  }
  setFormData(timeScales){
    timeScales.forEach(element => {
      element.timeScalesDta =   this.setTimeScaleOnView(element.timePoints);
      let getType =  this.timeScales.find(val => val.type == element.type );
      let translatedNames=  this.languageTranslator(getType.name);
      element.typeName = translatedNames;
  });
  

  }
  setTimeScaleOnView(timeScalesArray: any): String {
    let idx: Number = 0;
    let timeScales: string = "";
    timeScales += this.createTimeScaleValue(timeScalesArray);
    return timeScales.substring(0, timeScales.length - 3);
  }
  createTimeScaleValue(timescalesArray: Array<any>): String {
    var timeScales: string = "";
    var idx: number = 0;
    timescalesArray.forEach(element => {
      let timeScale: any = element;
      idx++;
      // if (timeScale.systemFieldType == 0) {}
        if (idx == timescalesArray.length)
          timeScales += "+ ";
        timeScales += " " + this.timePointDurationbyMeasure(timeScale.measure, timeScale.duration) + " / ";
      
      // else {
      //   timeScales += "<i> " + this.getTimeScaleTypeLabel(timeScale.systemFieldType) + "</i> / ";
      // }
    });
    return timeScales;
  }



  setDataTable(tableData) {
      this.iListingView = {
          listTitle: this.languageTranslator('admin.bia.timescales.title'),
          displayedColumns: this.displayedColumns,
          dataSource: tableData,
          tableButtons: this.tableButtons,
          pagination: true,
          search: true,
          recordsPerpage: true,
          showSelectAll: true,
          showFilters: false,
          filterSelectObj: this.filterSelectObj,
          chevronMenuClassName: ChevronMenuClassName.TimeScalesListChevronMenu,
          listObject: new Object
      }
      this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
      this.openFormHandler(data, PageState.EDIT_STATE);
  }


  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.BIA_CONFIG_TIMESCALES_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  printClick(data, exportType) {

  }
  chevronMenuClick(chevronMenu: any) {
      let btnAction = chevronMenu.btnAction;
      let data = chevronMenu.data;
      if (btnAction == ButtonActions.EDIT) {
          this.openFormHandler(data, PageState.EDIT_STATE);
      }
      if (btnAction == ButtonActions.DELETE) {
          let that = this;
          this.alertService.confirmation("deleteOneConfirm",
              function () {
                  that.deleteImpactcategoryById(data.id);
              });

      }
      if (btnAction == ButtonActions.VIEW) {
          this.openFormHandler(data, PageState.VIEW_STATE);
      }
      
  }


  deleteImpactcategoryById(id) {
      this.showLoader();
      this.timeScalesService.removeTimeScale([id]).
          subscribe(res => {
              this.hideLoader();
              this.getTimeScaleList();
          }, error => {
              this.hideLoader();
          })
  }

  deleteAllClick(data) {
      console.log("data", data)
      let timeScaleId = this.getIdsFromList(data);
      this.showLoader();
      this.timeScalesService.removeTimeScale(timeScaleId).
          subscribe(res => {
              this.hideLoader();
              this.getTimeScaleList();
          }, error => {
              this.hideLoader();
          })
  }
}
