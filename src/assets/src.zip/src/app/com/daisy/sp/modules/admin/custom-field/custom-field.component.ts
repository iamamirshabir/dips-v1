import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-field',
  templateUrl: './custom-field.component.html',
  styleUrls: ['./custom-field.component.sass']
})
export class CustomFieldComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
