import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryProductServiceService {
  public catProductDetails: any;
  constructor(private httpClient: HttpClient) { }
  
  getBusinessEntity(orgId){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_BUSINESS_ENTITY_BY_ORG_ID + orgId);
  }

  getSubCategories(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_FIND_BY_ORG_ID + '/' + orgID);
  }
  
  getCategoryProductServiceByOrgId(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_PRODUCT_SERVICE_FIND_BY_ORGANIZATION_ID + '/' + orgID);
  }
  
  getRealEntityByOrgId(id){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_BY_ORG_ID+"/"+id,id);
  }
  
  getCategoryProductServiceById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.CATEGORY_PRODUCT_SERVICE_ID+id);
    
  }

  saveCategoryProductService(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_PRODUCT_SERVICE_SAVE}`, data);
  }
 
  deleteProductServiceById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_PRODUCT_SERVICE_REMOVE_BY_ID}`, id);
  }

  getAllByOrganisationIdAndCanDoBia(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.CATEGORY_ALL_BY_ORGANISATION_ID +id + Api.CAN_DO_BIA);   
  }
  
  getCategoryProductServiceByOrgIdAndCanDoBia(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_PRODUCT_SERVICE_FIND_BY_ORGANIZATION_ID + '/' + orgID + Api.CAN_DO_BIA);
  }
  
  getCategoryProductServiceBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_PRODUCT_SERVICE, data);
  }
}
