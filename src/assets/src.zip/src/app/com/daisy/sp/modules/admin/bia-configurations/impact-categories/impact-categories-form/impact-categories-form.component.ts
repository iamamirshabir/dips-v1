import { Component, OnInit, Inject } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';
import { LoginComponent } from 'src/app/login/login.component';

@Component({
  selector: 'app-impact-categories-form',
  templateUrl: './impact-categories-form.component.html',
  styleUrls: ['./impact-categories-form.component.sass']
})
export class ImpactcategoriesFormComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  public breakpoint: number;
  disableLevelType: boolean;
  disableCategoryTypes:boolean=false;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RealEntityFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
    console.log("modelData", this.modalData);

    this.modalFormFroup = this.fb.group({
      id: [null],
      name: [null, [Validators.required]],
      description: [null],
      order: [null],
      organisation: [null],
      version: [null],
      impactCategoryLevels:[null]
    });
  
  }
  ngOnInit(): void {
    this.breakpoint = window.innerWidth <= 600 ? 1 : 1; // Breakpoint observer code
    if (this.modalData) {
      this.modalFormFroup.patchValue(this.modalData.data);
      
    }
  }

  saveFormData(): void {
    if (this.modalFormFroup.invalid) {
      return;
    }
    console.log(this.modalFormFroup.value);


    this.modalData.data = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 1;
  }
  
  
} 