import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RealEntityService {

  constructor(private httpClient: HttpClient) { }
  
  saveRealEntity(data){ 
    return this.httpClient.post(`${environment.baseUrl}`+Api.REAL_ENTITY_SAVE,data);
  } 

  savePerspective(data){ 
    return this.httpClient.post(`${environment.baseUrl}`+Api.PERSPECTIVES_SAVE,data);
  } 
  
  getRealEntityListByOrgId(id){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_BY_ORG_ID+"/"+id,id);
  }

  getPerspectivesListByOrgId(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.PERSPECTIVES_FIND_BY_ORG_ID+"/"+id,id);
  }

  findFlatListOrganisationId(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_FLAT_LIST_BY_ORG_ID+"/"+id,id);
  }
  getPerspectivesTree() { 
    return this.httpClient.get<any>('./rules.json');
  }
}
