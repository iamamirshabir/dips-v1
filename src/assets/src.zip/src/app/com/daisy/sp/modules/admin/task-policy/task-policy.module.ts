import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { TaskPolicyComponent } from './task-policy.component';
import { TaskPolicyListComponent } from './task-policy-list/task-policy-list.component';
import { TaskPolicyFormComponent } from './task-policy-form/task-policy-form.component';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { ComponentsModule } from '../../../common/components/components.module';


const routes :Routes=[
  {
    path: '', component :TaskPolicyComponent,
    children:[
      {path: 'task-policy-list', component:TaskPolicyListComponent},
      {path: 'task-policy-form', component:TaskPolicyFormComponent},
            
    ]
  }
];

@NgModule({
  declarations: [ TaskPolicyComponent,TaskPolicyListComponent,TaskPolicyFormComponent],
  imports: [
    CommonModule,
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ],
  providers: [],
  entryComponents: [TaskPolicyComponent]
})
export class TaskPolicyModule { }
