import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { TaskManagementComponent } from './task-management.component';
import { RoleAssignmentComponent } from './role-assignment/role-assignment.component';
import { PolicyCreationFormComponent } from './policy-creation/policy-creation-form.component';
import { PolicyCreationListComponent } from './policy-creation/policy-creation-list/policy-creation-list.component';


const routes: Routes = [
  {
    path: '', component: TaskManagementComponent,
    children: [
                {path:'role-assignment', component:RoleAssignmentComponent},
                {path:'policy-creation-form', component:PolicyCreationFormComponent},
                {path: 'policy-creation-list', component: PolicyCreationListComponent}
    ]
  }
]; 

@NgModule({
  declarations: [
    TaskManagementComponent,
    RoleAssignmentComponent,
    PolicyCreationFormComponent,
    PolicyCreationListComponent
    ],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[PolicyCreationFormComponent,RoleAssignmentComponent]
})
export class TaskManagementModule { }
