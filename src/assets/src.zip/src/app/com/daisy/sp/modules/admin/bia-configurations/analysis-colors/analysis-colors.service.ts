import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class AnalysisColorsService {

  constructor(private router: Router, private httpClient: HttpClient) { }

  saveAnalysisColor(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_CONFIGURATIONS_ANALYSIS_COLORS_SAVE}`, data);
  }

  getAnalysisColorsList(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_ANALYSIS_COLORS_LIST + id);
  }

  deleteAnalysisColor(id) {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_CONFIGURATIONS_ANALYSIS_COLORS_REMOVE}`, id);
  }
  deleteAnalysisColorById(id) {
    return this.httpClient.delete<any>(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_ANALYSIS_COLORS_REMOVE_BY_ID + "/" + id);
  }

}