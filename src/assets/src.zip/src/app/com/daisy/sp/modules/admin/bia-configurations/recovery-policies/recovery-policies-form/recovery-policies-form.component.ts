import { Component, OnInit, SystemJsNgModuleLoader, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatExpansionPanel } from '@angular/material/expansion';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { RecoveryPoliciesService } from '../recovery-policies.service';


@Component({
  selector: 'app-recovery-policies-form',
  templateUrl: './recovery-policies-form.component.html',
  styleUrls: ['./recovery-policies-form.component.sass']
})
export class RecoveryPoliciesFormComponent extends BaseClass implements OnInit {

  @ViewChild('impactPanel') impactPanel: MatExpansionPanel;

  RTOPolicyForm: FormGroup;
  state = "closed";
  impactList: any = [];
  analysisColors: any = [];
  methodSelected: any = "2";
  selectImpact: any = [];
  selectedAnalysis;
  impactAnalysis: any = [];
  levels = [];
  routeParams: any;
  recoveryPolicyObject: any;
  recoveryPolicyId: any;
  impactLevel: any;
  impactCategory: any = [];
  disableTextbox: boolean = true;
  
  // method: any = '2';
  constructor(private formBuilder: FormBuilder, private recoveryPolicyService: RecoveryPoliciesService) {
    super();
    this.RTOPolicyForm = this.formBuilder.group({
      id: [null],
      version: [null],
      name: ['', Validators.required],
      description: [''],
      threshold: [''],
      setRTO: ['rto'],
      // methodType: ['2'],
      levels: [],
      organisation: this.organisation,
    });
  }
  get f() { return this.RTOPolicyForm.controls; }

  ngOnInit(): void { }
  // ngAfterViewInit(): void {
  //   this.changeDetector.detectChanges();
  // }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.recoveryPolicyId = this.routeParams.id;
    if (this.routedPageState != 1) {
      // this.recoveryPolicyObject = this.routeParams.data;
      this.recoveryPolicyService.getRecoveryPolicyById(this.recoveryPolicyId).subscribe((res) => {
        this.recoveryPolicyObject = res;

        this.getImpactcategoryList();
        this.patchFormValues();
      }, err => {
        console.log(err);
      });

    }
    else {
      this.getImpactcategoryList();
    }
  }

  patchFormValues() {
    // this.recoveryPolicyObject.methodType = JSON.stringify(this.recoveryPolicyObject.methodType);
    // this.methodSelected = this.recoveryPolicyObject.methodType;
    this.RTOPolicyForm.patchValue(this.recoveryPolicyObject);
    this.recoveryPolicyObject.levels.forEach(category => {
      this.impactCategory.push(category);
    });
  }
  patchImpact() {
    this.impactList.forEach(listItem => {
      this.impactCategory.forEach(patchListItem => {
        if (listItem.id === patchListItem.impactCategory.id) {
          listItem.checked = true;
          listItem.impactCategoryLevels.forEach(listLevel => {
            if (listLevel.id === patchListItem.level.id) {
              listLevel.analysisColour.selected = true;
            }
            if(patchListItem.mtpdLevel){
            if (listLevel.id === patchListItem.mtpdLevel.id) {
              listLevel.analysisColour.mtpdSelected = true;
            }
          }
          });
          if(listItem.mtpdLevels){
            listItem.mtpdLevels.forEach(listLevel => {
              let newVal = listItem.impactCategoryLevels.find(val => val.analysisColour.selected == true);
              if (listLevel.severity <= newVal.severity) {
                listLevel.analysisColour.mtpdSelected = false;
                listLevel.analysisColour.mtpdDisabled = true;
              }
              else {
                listLevel.analysisColour.mtpdDisabled = false;
              }
            });
          }
      
        }
      });

    });
  }

  selectedImpact(event, impact) {
    impact.checked = event.checked;
  }
  getImpactcategoryList() {
    this.impactcategoriesService.getsavedImpactCategoryLists(this.organisation.id).
      subscribe(res => {
        res.forEach(impact => {
          this.impactList.push(impact);
          this.impactList.forEach(impact => {
            impact.mtpdLevels = impact.impactCategoryLevels;
            impact.impactCategoryLevels.sort((a, b) => a.severity - b.severity);
            impact.mtpdLevels.sort((a, b) => a.severity - b.severity);
            impact.impactCategoryLevels.forEach(impactCategory => {
              impactCategory.analysisColour.selected = false;
            });
            impact.mtpdLevels.forEach(impactCategory => {
              impactCategory.analysisColour.mtpdSelected = false;
            });
          });
        });

        this.patchImpact();
      }, error => {
      })
  }
  clickedColor(checkedImpactCategory, selectedImpactLevel, impact) {
    checkedImpactCategory.forEach(category => {
      category.analysisColour.selected = false;
    });
    selectedImpactLevel.analysisColour.selected = !selectedImpactLevel.analysisColour.selected;
    this.impactList.forEach(listItem => {
      if (listItem.id === impact.id) {
        listItem.mtpdLevels.forEach(listLevel => {
          if (listLevel.severity <= selectedImpactLevel.severity) {
            listLevel.analysisColour.mtpdSelected = false;
            listLevel.analysisColour.mtpdDisabled = true;
          }
          else {
            listLevel.analysisColour.mtpdDisabled = false;
          }
        });
      }
    });

  }


  clickedMtpdColor(checkedImpactCategory, selectedMtpdLevel) {
    // this.disableTextbox = !this.disableTextbox;
    checkedImpactCategory.forEach(mtpdLevels => {
      mtpdLevels.analysisColour.mtpdSelected = false;
    });
    selectedMtpdLevel.analysisColour.mtpdSelected = !selectedMtpdLevel.analysisColour.mtpdSelected;
  }


  radioChange(ev) {
    this.methodSelected = ev.value;
  }
  levelImpact() {
    this.levels = [];
    var levels = {};
    this.impactList.forEach(impactChecked => {
      impactChecked.impactCategoryLevels.forEach(category => {
        if (impactChecked.checked && category.analysisColour.selected && category.analysisColour.mtpdSelected) {
          levels = {
            impactCategory: impactChecked,
            level: category,
            mtpdLevel: category,
          }
          this.levels.push(levels);
        }
        else if (impactChecked.checked && category.analysisColour.selected) {
          levels = {
            impactCategory: impactChecked,
            level: category,
          }
          this.levels.push(levels);
        }
        else if (impactChecked.checked && category.analysisColour.mtpdSelected) {
          this.levels.forEach(level => {
            if (impactChecked.id === level.impactCategory.id) {
              level.mtpdLevel = category;
            }
          });
        }
      });
    });
    var oldLevels = this.RTOPolicyForm.value.levels;
    this.RTOPolicyForm.value.levels = this.levels;
    this.RTOPolicyForm.value.levels.forEach(level => {
      oldLevels.forEach(oldLevel => {
        if (level.impactCategory.id === oldLevel.impactCategory.id) {
          level.id = oldLevel.id
        }
      });
    });
  }
  onSubmit(btnAction: ButtonActions) {
    if (this.RTOPolicyForm.invalid) {
      return
    }
    this.levelImpact();
    let formData: any = this.RTOPolicyForm.value;
    if (formData.levels.length < 1) {
      this.alertService.error(this.languageTranslator('admin.configurations.recovery.policy.select.category.level'));
      return;
    }
    this.showLoader();
    // if (this.RTOPolicyForm.value.methodType === "1") {
    //   this.RTOPolicyForm.value.levels = [];
    // }
    // else if (this.RTOPolicyForm.value.methodType === "2") {
    //   this.RTOPolicyForm.value.threshold = null;
    // }

    this.recoveryPolicyService.saveRecoveryPolicy(this.RTOPolicyForm.value).subscribe((res) => {
      this.hideLoader();
      if (this.routedPageState === 1) {
        this.alertService.success("Successfully Created");
      }
      else {
        this.alertService.success("Successfully Updated")
      }
      if (btnAction == ButtonActions.SAVE) {
        this.goBackToMainPage();
      }
    }, err => {
      this.hideLoader();
      console.log(err);
    })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.BIA_CONFIG_RECOVERY_POLICIES_LIST);
  }

}
