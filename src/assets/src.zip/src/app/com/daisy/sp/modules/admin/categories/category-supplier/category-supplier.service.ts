import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategorySupplierService {

  constructor(private httpClient: HttpClient) { }
   public catSupplierDetails :any;
  getSubCategories(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategorySupplierByOrgId(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_SUPPLIER_FIND_BY_ORG_ID + '/' + orgID);
  }
  getRealEntityByOrgId(id){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_BY_ORG_ID+"/"+id,id);
  }
  getCategoryITByOrgId(orgID){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_IT_SERVICE_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategorySupplierById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_SUPPLIER_SERVICE_FIND_BY_ID + '/' + id);
  }
  saveCategorySupplier(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_SUPPLIER_SERVICE_SAVE}`, data);
  }
 
  deleteCategorySupplierById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_SUPPLIER_SERVICE_REMOVE_BY_ID}`, id);
  }
  getCategorySupplierByOrgIdAndCanDoBia(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_SUPPLIER_FIND_BY_ORG_ID + '/' + orgID + Api.CAN_DO_BIA);
  }
  getCategorySupplierBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_SUPPLIER_SERVICE, data);
  }
}
