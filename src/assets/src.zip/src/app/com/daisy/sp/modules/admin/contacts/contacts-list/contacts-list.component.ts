import { Component, OnInit, AfterContentInit, AfterViewInit } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { ListRequest } from '../../../../utils/mode.listRequest';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants';
import { RouteParams } from '../../../../utils/model.route-params';
import { Router, ActivatedRoute } from '@angular/router';
import { PageState } from '../../../../utils/constants/page-state-constants';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';

@Component({
  selector: 'app-contacts-list',
  templateUrl: './contacts-list.component.html',
  styleUrls: ['./contacts-list.component.sass']
})
export class ContactsListComponent extends BaseClass implements OnInit, AfterViewInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  public listTitle : any;
  constructor(private router: Router, protected activatedRoute: ActivatedRoute) {
    super();
  }

  ngOnInit(): void {
    
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'username', name: 'Username', checked: 'true' },
    { key: 'workEmail', name: 'Work Email', checked: 'true' },
    { key: 'jobTitle', name: 'Job' },
    { key: 'workTel', name: 'Work Tel' },
    { key: 'workMobile', name: 'Work Mobile' },
    { key: 'homeTel', name: 'Home Tel' },
    { key: 'homeMobile', name: 'Home Mobile' },
    { key: 'homeEmail', name: 'Home Email' },
    { key: 'address', name: 'Address' },
    { key: 'location', name: 'Location' },
    { key: 'organisationName', name: 'Organisation' },
    { key: 'contactType', name: 'Contact Type' },
    { key: 'employeeNo', name: 'Employee No' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD },
    ];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', options: [] },
    { name: 'Username', columnProp: 'username', options: [] },
    { name: 'Email', columnProp: 'workEmail', options: [] }];
    this.setDataTable([]);
  }
  ngAfterViewInit() {
    this.getContactList();
    this.hideLoader();
  }
  getContactList() {
    this.showLoader();
    // let listParams = new ListRequest();
    // listParams.pageNumber = 0;
    // listParams.recordPerPage = 500;
    // listParams.sortDirection = 'asc'
    // listParams.sortField = 'firstName'
    
    
    this.contactService.getFullContactList().
      subscribe(contacts => {
        if (contacts) {
          this.tableData = contacts;
        } else {
          this.tableData = [];
        }
        this.hideLoader();
        if (this.tableData) {
          this.tableData.forEach(element => {
            element.name = element.firstName + " " + element.lastName;
          });
        }
        this.setDataTable(this.tableData);
      }, error => {
        this.hideLoader();
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
  }

  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.contacts'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ContactListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, PageState.EDIT_STATE);
  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    
    if (data) {
      routeParams.id = data['id'];
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.CONTACT_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  printClick(data,exportType) {

  }
  deleteAllClick(data) {
    this.showLoader();
    let ids = this.getIdsFromList(data);
    this.contactService.deleteAllContacts(ids).
      subscribe(res => {
        this.hideLoader();
        this.getContactList();
      }, error => {
        this.hideLoader();
      })
  }
  deleteContactById(id) {
    this.showLoader();
    this.contactService.deleteContactById(id).
      subscribe(res => {
        this.alertService.success("deleteOne.successfull", true);
        this.hideLoader();
        this.getContactList();
      }, error => {
        this.hideLoader();
      })
  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteContactById(data.id);
        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }
}
