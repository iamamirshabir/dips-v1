import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TimescalesListComponent } from './timescales-list/timescales-list.component';
import { TimescalesFormComponent } from './timescales-form/timescales-form.component'; 
import { TimescalesComponent } from './timescales.component';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule, Routes } from '@angular/router';
const routes: Routes = [
  {
    path: '', component: TimescalesComponent,
    children: [
      { path: 'timescales-list', component: TimescalesListComponent },
      { path: 'timescales-form', component: TimescalesFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [TimescalesListComponent, TimescalesFormComponent,TimescalesComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
})
export class TimescalesModule { }
