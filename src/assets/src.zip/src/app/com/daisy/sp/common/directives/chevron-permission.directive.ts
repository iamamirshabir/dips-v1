import { Directive, ElementRef, TemplateRef, ViewContainerRef, Input, Output, EventEmitter, HostBinding } from '@angular/core';
import { MainLayoutService } from '../../main-layout/main-layout-service';
import { Subscription } from 'rxjs';
import { SecurityActions } from '../../modules/admin/security/security-actions'; 

@Directive({
  exportAs: 'appPermission',
  selector: '[appPermission]'
})

export class ChevronPermissionDirective {

  private permissions: any[] = [];
  private securityAreaPermissions: any[] = []; 
  constructor( private templateRef: TemplateRef<any>,
               private viewContainer: ViewContainerRef,
               private mainLayoutService: MainLayoutService) { 
  }  
  @Input() 
  set appPermission(ISecurity) {
    if (ISecurity) {
      this.permissions = this.mainLayoutService.getPermissions()
      this.securityAreaPermissions = this.permissions.find(security => security.accessArea == ISecurity.accessArea); 
      this.checkPermission(this.securityAreaPermissions, ISecurity);
    }
  }

  checkPermission(permissions,security) {
    this.viewContainer.createEmbeddedView(this.templateRef);
    if (security.accessArea == -1 || security.securityAction == -1) {
        security.menu.disabled = false;
    }else {
      switch (security.securityAction) {
        case SecurityActions.SECURITY_ACTION_CREATE:
          if (permissions.create == SecurityActions.YES) {
              security.menu.disabled = false
          } else {
              security.menu.disabled = true
          }
          break;
        case SecurityActions.SECURITY_ACTION_READ:
          if (permissions.read == SecurityActions.YES) {
              security.menu.disabled = false
          } else {
              security.menu.disabled = true
          }
          break;
        case SecurityActions.SECURITY_ACTION_UPDATE:
          if (permissions.update == SecurityActions.YES) {
              security.menu.disabled = false
          } else {
             security.menu.disabled = true
          }
          break;
        case SecurityActions.SECURITY_ACTION_DELETE:
          if (permissions.delete == SecurityActions.YES) {
            security.menu.disabled = false
          }else { 
            security.menu.disabled = true 
          }
          break;
        }  
      }
  }

}
