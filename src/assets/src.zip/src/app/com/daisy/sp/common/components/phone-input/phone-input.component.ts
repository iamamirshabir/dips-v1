import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phone-input',
  templateUrl: './phone-input.component.html',
  styleUrls: ['./phone-input.component.sass']
})
export class PhoneInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
