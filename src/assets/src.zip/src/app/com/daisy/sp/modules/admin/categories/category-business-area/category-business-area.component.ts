import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-business-area',
  templateUrl: './category-business-area.component.html',
  styleUrls: ['./category-business-area.component.sass']
})
export class CategoryBusinessAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
