import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { SearchModalComponent } from '../../../common/components/search-modal/search-modal.component';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.sass']
})
export class SearchComponent implements OnInit {
  @ViewChild('filterIcon') filterIcon: ElementRef;
  dialogRef: MatDialogRef<SearchModalComponent>;

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  openDialog(): void {
    if (this.dialogRef == null) {
      let targetAttr = this.filterIcon.nativeElement.getBoundingClientRect();
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.hasBackdrop = false;
      dialogConfig.panelClass = 'filter-popup';

      dialogConfig.position = {
        left: `${targetAttr.left - 390}px`,
        top: `${targetAttr.bottom - 0}px`
      };
      dialogConfig.width = "100vw";
      // dialogConfig.minHeight = "10%"
      dialogConfig.height = "80vh";
      dialogConfig.maxHeight = "100vh";
    
      this.dialogRef = this.dialog.open(SearchModalComponent, dialogConfig);

      this.dialogRef.afterClosed().subscribe(data => {
        this.dialogRef = null;
      });
    }
  }
}