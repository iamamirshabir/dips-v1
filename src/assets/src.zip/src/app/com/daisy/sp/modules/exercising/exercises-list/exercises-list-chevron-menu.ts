import { ChevronMenuBase } from '../../../common/components/chevron-menus/chevron-menu-base';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../utils/constants/mat-icons-constants';
import { AccessAreas } from '../../admin/security/access-areas';
import { SecurityActions } from '../../admin/security/security-actions';

export class ExercisesListChevronMenu extends ChevronMenuBase { 
    constructor(record, recordsList) { 
     super();
     this.record = record;
     this.recordsList = recordsList;
     this.onInitChevronMenu();
    } 
    onInitChevronMenu(){ 
        this.addMenu(ButtonActions.VIEW_EXERCISE_RECORD, MatIcons.PREVIEW,AccessAreas.EXERCISING,SecurityActions.SECURITY_ACTION_READ);
        this.addMenu(ButtonActions.PRINT_EXERCISE_RECORD, MatIcons.PRINT,AccessAreas.EXERCISING);
        this.addMenu(ButtonActions.CREATE_TEMPLATE_FROM_EXERCISE, MatIcons.ADD,AccessAreas.EXERCISING); 
        this.addMenu(ButtonActions.RERUN_EXERCISE, MatIcons.EDIT,AccessAreas.EXERCISING); 
        this.addMenu(ButtonActions.EDIT_REAL_ENTITIES, MatIcons.EDIT,AccessAreas.EXERCISING); 
    } 
}