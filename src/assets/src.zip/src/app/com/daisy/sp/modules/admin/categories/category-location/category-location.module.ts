import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { CategoryLocationListComponent } from './category-location-list/category-location-list.component';
import { CategoryLocationFormComponent } from './catrgory-location-form/category-location-form.component';
import { CategoryLocationComponent } from './category-location.component';
const routes: Routes = [
  {
    path: '', component: CategoryLocationComponent,
    children: [
      { path: 'category-location-list', component: CategoryLocationListComponent },
      { path: 'category-location-form', component: CategoryLocationFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [CategoryLocationListComponent, CategoryLocationFormComponent, CategoryLocationComponent ],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[CategoryLocationFormComponent]
})
export class CategoryLocationModule { }
