import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SecurityProfilesComponent } from './security-profiles.component';

describe('SecurityProfilesFormComponent', () => {
  let component: SecurityProfilesComponent;
  let fixture: ComponentFixture<SecurityProfilesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SecurityProfilesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityProfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
