import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class BIAService {

    constructor(private httpClient: HttpClient) { }

    saveBiaRecord(biaRecord): Observable<any> {
        return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
    }
    getBiaRecordById(id) {
        return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_GET_RECORD_BY_ID + '/' + id);
    }
    getBiaRecordList(id) {
        return this.httpClient.get<any>(`${environment.baseUrl + Api.BIA_FIND_RECORD_LIST}/` + id);
    }
    
    deleteBiaRecordById(id): Observable<any> {
        return this.httpClient.post(`${environment.baseUrl + Api.BIA_REMOVE_RECORD}`, id);
    }
    getEmployeeHeadCounts(orgID) {
        return this.httpClient.get<any>(`${environment.baseUrl}` + Api.EMPLOYEE_TYPE_FIND_BY_BIA_TYPE_AND_ORGANISATION + '/' + orgID);
    }
    getLocationsByOragnisation(orgID) {
        return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_GET_LOCATIONS_BY_ORGID + '/' + orgID);
    }
    getByCategoryRecordIdAndStatus(id, status) {
        return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_GET_BY_CATEGORY_ID_AND_STATUS + id + "/" + status);
    }
    deleteBiaByCategoryRecordId(ids): Observable<any> {
        return this.httpClient.post(`${environment.baseUrl + Api.BIA_REMOVE_RECORD_BY_CATEGORY_RECORD_ID}`, ids);
    }
    getBiaDependencySelectionData(orgID)
    {
        return this.httpClient.get<any>(`${environment.baseUrl + Api.BIA_CONFIGURATIONS_DEPENDENCY_SELECTION_FIND_BY_ORGANISATION_ID}` + '/' + orgID);
    }
    getDependencyMapbyBiaId(biaId)
    {
        return this.httpClient.get<any>(`${environment.baseUrl + Api.BIA_GET_DEPENDENCY_MAP}` + '/' + biaId);
    }
  
}