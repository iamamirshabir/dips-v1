import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';

@Injectable({
  providedIn: 'root'
})
export class ItServiceService {

  constructor(private httpClient: HttpClient) { }
  getItServiceListsByBiaId(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_IT_SERVICE_FIND_BY_BIA_ID + id);
  }
  getItServiceListsById(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_IT_SERVICE_FIND_BY_ID + id);
  }
  deleteItServiceById(id): Observable<any> {
    return this.httpClient.post<any>(`${environment.baseUrl + Api.BIA_IT_SERVICE_REMOVE_BY_ID}`, id);
  }
  deleteItServiceByChevron(id) {
    return this.httpClient.delete<any>(`${environment.baseUrl}` + Api.BIA_IT_SERVICE_REMOVE_BY_ID + "/" + id);
  }
  saveItService(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_IT_SERVICE_SAVE}`, data);
  }
  saveAllItService(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_IT_SERVICE_SAVE_ALL}`, data);
  }
 
  deleteBusinessAreaRow(data){
    return this.httpClient.post(`${environment.baseUrl + Api.DELETE_BUSINESS_AREA_BY_ID}`,data)
  }

}
