import { Injectable } from '@angular/core';   
import { ChevronMenuClassName } from './chevron-menu-class-names';
import { ChevronMenuBase } from './chevron-menu-base';
import { ContactListChevronMenu } from '../../../modules/admin/contacts/contacts-list/contact-list-chevron-menu';
import { ExercisesListChevronMenu } from '../../../modules/exercising/exercises-list/exercises-list-chevron-menu';
import { AnalysisColorsListChevronMenu } from '../../../modules/admin/bia-configurations/analysis-colors/analysis-colors-list/analysis-colors-list-chevron-menu';
import { RiskStrategiesListChevronMenu } from '../../../modules/admin/bia-configurations/risk-strategies/risk-strategies-list/risk-strategies-chevron-list.component';
import { ImpactcategoriesListChevronMenu } from '../../../modules/admin/bia-configurations/impact-categories/impact-categories-list/impact-categories-chevron-list.component';
import { ImpactlevelsListChevronMenu } from '../../../modules/admin/bia-configurations/impact-categories/impact-levels/impact-levels-list/impact-levels-chevron-list.component';
import { EmployeeTypeListChevronMenu } from '../../../modules/admin/contacts/employee-type/employee-type-list/employee-type-list-chevron-menu';
import { ProcessesListChevronMenu } from '../../../modules/bia/bia-record-tab/processes/processes-list/processes-chevron-list.component';
import { ItServiceTypeListCheveronMenue } from '../../../modules/admin/bia-configurations/it-service-type/it.service.type.list.cheveron.menue';
import { RisksListChevronMenu } from '../../../modules/bia/bia-record-tab/risks/risk-list/risks-chevron-list.component';
import { ProductServiceListChevronMenu } from '../../../modules/bia/bia-record-tab/product-services/products-services-list/products-service-chevron-list.component';
import { CostCenterListChevronMenu } from '../../../modules/admin/bia-configurations/cost-center/cost-center-list-chevron-menu';
import { BusinessEntityListChevronMenu } from '../../../modules/admin/bia-configurations/business-entity/business-entity-list-chevron-menu';
import { ResourcesListChevronMenu } from '../../../modules/bia/bia-record-tab/resources/resources-list/resources-chevron-list.component';
import { PerspectivesChevronMenu } from '../../../modules/admin/real-entity/real-entity-form/perspective-chevron-menu';
import { RecoveryPolicyListChevronMenu } from '../../../modules/admin/bia-configurations/recovery-policies/recovery-policies-list/recovery-policies-chevron-list.component';
import { CategoryITListChevronMenu } from '../../../modules/admin/categories/category-it/category-it-list/category-it-chevron-list.component';
import { CategorySupplierListChevronMenu } from '../../../modules/admin/categories/category-supplier/category-supplier-list/category-supplier-chevron-list.component';
import { CategoryProductServiceListChevronMenu } from '../../../modules/admin/categories/category-productService/category-productService-list/category-productService-chevron-list.component';
import { SuppliersListChevronMenu } from '../../../modules/bia/bia-record-tab/suppliers/suppliers-list/suppliers-chevron-list.component';
import { BusinessAreaListChevronMenu } from '../../../modules/bia/bia-record-tab/business-area/business-area-list/business-area-chevron-list.component';
import { BiaRecordChevronMenu } from '../../../modules/bia/bia-records-list/bia-record-chevron-menu';
import { OrganisationListChevronMenu } from '../../../modules/admin/organisation/organisation-list/organisation-list-chevron-menu';
import { TimeScalesListChevronMenu } from '../../../modules/admin/bia-configurations/timescales/timescales-list/timescales-chevron-list.component';
@Injectable({
  providedIn: 'root'
})
export class ChevronMenuService {
  constructor() {} 

  getChevronMenuClass(menuClassName, record = null , recordList = null): ChevronMenuBase{
    let menuClass:any;
    switch(menuClassName) {
      case ChevronMenuClassName.ContactListChevronMenu :
           menuClass = new ContactListChevronMenu(record, recordList);
           break;
      case ChevronMenuClassName.ExercisesListChevronMenu :
          menuClass = new ExercisesListChevronMenu(record, recordList);
          break;
      case ChevronMenuClassName.AnalysisColorsListChevronMenu :
          menuClass = new AnalysisColorsListChevronMenu(record, recordList);
          break;
      case ChevronMenuClassName.RiskStrategiesChevronMenu :
          menuClass = new RiskStrategiesListChevronMenu(record, recordList);
          break;
      case ChevronMenuClassName.ImpactCategoriesChevronMenu :
          menuClass = new ImpactcategoriesListChevronMenu(record, recordList);
          break;   
      case ChevronMenuClassName.ImpactLevelsChevronMenu :
        menuClass = new ImpactlevelsListChevronMenu(record, recordList);
        break;    
      case ChevronMenuClassName.EmployeeTypeListChevronMenu :
        menuClass = new EmployeeTypeListChevronMenu(record, recordList);
        break;  
        case ChevronMenuClassName.BIAProcessesChevronMenu :
        menuClass = new ProcessesListChevronMenu(record, recordList);
        break;  
      case ChevronMenuClassName.ItServiceTypeListCheveronMenue :
        menuClass = new ItServiceTypeListCheveronMenue(record, recordList);
        break;    
      case ChevronMenuClassName.RisksListChevronMenu :
        menuClass = new RisksListChevronMenu(record, recordList);
        break;        
      case ChevronMenuClassName.BIAProductServiceChevronMenu :
        menuClass = new ProductServiceListChevronMenu(record, recordList);
        break;
      case ChevronMenuClassName.CostCenterListChevronMenu :
        menuClass = new CostCenterListChevronMenu(record, recordList);
        break;
      case ChevronMenuClassName.BusinessEntityListChevronMenu :
        menuClass = new BusinessEntityListChevronMenu(record, recordList);
        break;
      case ChevronMenuClassName.BIAResourcesListChevronMenu :
        menuClass = new ResourcesListChevronMenu(record, recordList);
        break;
      case ChevronMenuClassName.PerspectivesChevronMenu :
        menuClass = new PerspectivesChevronMenu(record, recordList);
        break;
        case ChevronMenuClassName.RecoveryPolicyListChevronMenu :
          menuClass = new RecoveryPolicyListChevronMenu(record, recordList);
          break;
        case ChevronMenuClassName.CategoryITListChevronMenu :
          menuClass = new CategoryITListChevronMenu(record, recordList);
          break;
        case ChevronMenuClassName.CategorySupplierListChevronMenu :
          menuClass = new CategorySupplierListChevronMenu(record, recordList);
          break;
        case ChevronMenuClassName.CategoryProductServiceListChevronMenu :
          menuClass = new CategoryProductServiceListChevronMenu(record, recordList);
          break;
        case ChevronMenuClassName.SuppliersListChevronMenu :
          menuClass = new SuppliersListChevronMenu(record, recordList);
          break;
        case ChevronMenuClassName.BusinessAreaListChevronMenu :
          menuClass = new BusinessAreaListChevronMenu(record, recordList);
          break;  
        case ChevronMenuClassName.BiaRecordChevronMenu :
          menuClass = new BiaRecordChevronMenu(record, recordList);
          break;  
          case ChevronMenuClassName.OrganisationListChevronMenu :
            menuClass = new OrganisationListChevronMenu(record, recordList);
            break;  
        case ChevronMenuClassName.TimeScalesListChevronMenu :
            menuClass = new TimeScalesListChevronMenu(record, recordList);
            break;    
      default : {
            menuClass = new ChevronMenuBase();
      }
            
    }
    return menuClass.menusList;
  }  
}
