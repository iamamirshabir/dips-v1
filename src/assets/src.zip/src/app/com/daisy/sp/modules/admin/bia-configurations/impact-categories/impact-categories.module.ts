
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { ImpactcategoriesComponent } from './impact-categories.component';
import { ImpactcategoriesListComponent } from './impact-categories-list/impact-categories-list.component';
import { ImpactcategoriesFormComponent } from './impact-categories-form/impact-categories-form.component';
import { ImpactLevelsFormComponent } from './impact-levels/impact-levels-form/impact-levels-form.component';
import { ImpactLevelsListComponent } from './impact-levels/impact-levels-list/impact-levels-list.component';

const routes: Routes = [
  {
    path: '', component: ImpactcategoriesComponent,
    children: [
      { path: 'impact-categories-list', component: ImpactcategoriesListComponent },
      { path: 'impact-categories-form', component: ImpactcategoriesFormComponent },
      { path: 'impact-levels-form', component: ImpactLevelsFormComponent },
      { path: 'impact-levels-list', component: ImpactLevelsListComponent },
    ]
  }
];

@NgModule({
  declarations: [ImpactcategoriesComponent,
    ImpactcategoriesListComponent,
    ImpactcategoriesFormComponent,
    ImpactLevelsFormComponent,
    ImpactLevelsListComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [ImpactcategoriesFormComponent]
})
export class ImpactCategoriesModule { }
