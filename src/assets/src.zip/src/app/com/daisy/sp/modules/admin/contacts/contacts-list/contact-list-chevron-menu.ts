import { ChevronMenuBase } from '../../../../common/components/chevron-menus/chevron-menu-base';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants'; 
import { ButtonActions } from '../../../../utils/constants/btn-types-constants'; 
import { SecurityActions } from '../../security/security-actions';
import { AccessAreas } from '../../security/access-areas';

export class ContactListChevronMenu extends ChevronMenuBase { 
    constructor(record, recordsList) { 
     super();
     this.record = record;
     this.recordsList = recordsList;
     this.onInitChevronMenu();
    } 
    onInitChevronMenu(){ 
        this.addMenu(ButtonActions.EDIT, MatIcons.EDIT,AccessAreas.ADMIN,SecurityActions.SECURITY_ACTION_UPDATE);
        this.addMenu(ButtonActions.VIEW, MatIcons.PREVIEW,AccessAreas.ADMIN,SecurityActions.SECURITY_ACTION_READ);
        this.addMenu(ButtonActions.DELETE, MatIcons.DELETE,AccessAreas.ADMIN,SecurityActions.SECURITY_ACTION_DELETE); 
    } 
}