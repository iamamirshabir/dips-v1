import { ChangeDetectorRef, Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { BehaviorSubject } from 'rxjs';
import { BaseClass } from '../../../utils/baseclass';
import { MatTable } from '@angular/material/table';



@Component({
  selector: 'app-exercising-observation',
  templateUrl: './exercising-observation.component.html',
  styleUrls: ['./exercising-observation.component.sass'],
  animations: [
    trigger("detailExpand", [
      state("collapsed", style({ height: "0px", minHeight: "0" })),
      state("expanded", style({ height: "*" })),
      transition(
        "expanded <=> collapsed",
        animate("225ms cubic-bezier(0.4, 0.0, 0.2, 1)")
      )
    ])
  ]
})
export class ExercisesObservationComponent extends BaseClass implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable, { static: false }) matTable: MatTable<any>;
  actions: FormGroup;
  expandedElement: null;
  dataSource = new MatTableDataSource();
  nestedDataSource = new MatTableDataSource();
  exerciseObservationForm = new FormArray([]);
  dataSource1 = new BehaviorSubject<AbstractControl[]>([]);
  impactType: any = [];
  displayedColumns: string[] = [
    "Ref",
    "Type",
    "Detail",
    "Action Identifier",
    "Actions"
  ];
  routeParams;
  routedState;
  exerciseId;
  issuesRecorded: any = [];
  innerDisplayedColumns = ['Action Ref', 'Action Detail', 'Owner', 'Impact', 'Actions'];
  selectedObservations: any;
  exerciseRecord;
  exerciseObservationTypeSelected;
  exerciseObservationPatch;
  exerciseObservation = [];
  exerciseName: string;


  constructor(private fb: FormBuilder, private cd: ChangeDetectorRef) {
    super();
  }

  ngOnInit() {
    this.exercisingService.getObservationImpact(this.organisation.id).subscribe((res) => {
      this.impactType = res;
    }, error => {
      console.log(error);
    });
    this.exercisingService.getObservationTypes().subscribe((res) => {
      this.issuesRecorded = res;
    },
      err => {
        console.log(err);
      }
    );
    this.dataSource.paginator = this.paginator;

  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedState = this.routeParams.pageState;
    this.routedPageState = this.routeParams['pageState'];
    this.exerciseId = this.routeParams.data.id;

    if (this.exerciseId) {
      this.exerciseRecord = this.routeParams.data;
      this.exerciseName = this.exerciseRecord.name;
      this.exercisingService.findExerciseObservationbyExerciseId(this.exerciseId).subscribe(observation => {
        this.exerciseObservationPatch = observation;
        if (this.exerciseObservationPatch.length) {
          this.patchFormValues();
        }
        else {
          this.addRow();
        }
      }, error => {
      })
    }
  }
  patchFormValues() {
    if (this.exerciseObservationPatch.length > 0) {
      {
        this.exerciseObservationPatch.forEach(observation => {
          if (observation && observation !== undefined) {
            let observations = <FormArray>this.exerciseObservationForm;
            let obser = this.patchObservations(observation)
            let actionForm = <FormArray>obser['controls'].actions;
            if (observation.actions.length) {
              observation.actions.forEach(action => {
                // this.impactType.push(action.impact);
                actionForm.push(this.patchActions(action));
              });
            }
            observations.push(obser);
            if (observation.type !== undefined) {
              // this.issuesRecorded.push(observation.type);
            }
            this.dataSource.data = observations.controls;
          }
        });
      }
      this.hideLoader();
    }
    this.hideLoader();
  }
  patchObservations(observation = null) {
    return this.fb.group({
      id: observation ? observation.id : [null],
      version: observation ? observation.version : [null],
      ref: observation ? observation.ref : [null],
      type: observation ? observation.type : [null, Validators.required],
      detail: observation ? observation.detail : [null, Validators.required],
      actions: this.fb.array([]),
    });
  }
  patchActions(action = null) {
    return this.fb.group({
      actionRef: action ? action.actionRef : this.fb.control(null),
      actionDetail: action ? action.actionDetail : this.fb.control(null),
      owner: action ? action.owner : [null],
      impact: action ? action.impact : this.fb.control(null),
    });
  }
  addRow() {

    let row = this.fb.group({
      id: [null],
      version: [null],
      ref: new FormControl(null),
      type: [null, Validators.required],
      detail: [null, Validators.required],
      actions: this.fb.array([]),
    });
    this.dateFormArray.push(row);
    this.dataSource.data = this.dateFormArray.controls;
  }
  createActionFormGroup() {
    return this.fb.group({
      actionRef: this.fb.control(null),
      actionDetail: [null, Validators.required],
      owner: [null],
      impact: [null, Validators.required],
    });
  }

  get dateFormArray(): FormArray {
    return this.exerciseObservationForm as FormArray;
  }
  observationToDelete: any = [];
  removeRow(observation = null, i) {
    const index = this.exerciseObservationForm.controls.indexOf(observation);
    if (index > -1) {
      this.exerciseObservationForm.controls.splice(index, 1);
    }
    var observationId = observation.value.id;
    this.observationToDelete.push(observationId);
    const control = <FormArray>this.exerciseObservationForm;
    this.matTable.renderRows();
    if (control.length == 0) {
      this.addRow();
    }
  }

  getActualIndex(index: number) {
    if (this.paginator != undefined)
      return index + this.paginator.pageSize * this.paginator.pageIndex;
  }
  removeNestedRow(i, action) {
    const index = i;
    this.nestedDataSource.data.splice(index, 1);
    this.exerciseObservationForm.value.forEach(element => {
      element.actions.forEach(actions => {
        if (actions === action.value) {
          var index = element.actions.indexOf(actions);
          if (index > -1) {
            element.actions.splice(index, 1);
          }
        }
      });
    });
    this.nestedDataSource._updateChangeSubscription();

    if (this.selectedObservations.controls.actions.length === 0) {
      this.addNestedRow();
    }
  }
  addNestedRow() {
    this.selectedObservations.controls.actions.controls.push(this.createActionFormGroup());
    this.nestedDataSource._updateChangeSubscription();
  }
  getNestedData(params = null) {
    let observation: any = this.dateFormArray.controls.find(item => item === params);
    this.selectedObservations = observation;
    if (this.selectedObservations.controls.actions.controls.length) {
      this.nestedDataSource.data = this.selectedObservations.controls.actions.controls;
      this.nestedDataSource._updateChangeSubscription();
    }
    else {
      this.selectedObservations.controls.actions.controls.push(this.createActionFormGroup())
      this.nestedDataSource.data = this.selectedObservations.controls.actions.controls;
      this.nestedDataSource._updateChangeSubscription();
    }
    if (this.nestedDataSource.data.length) {
      this.nestedDataSource.data.forEach((entry) => {
        if (entry['value']) {
          if (entry['value'].owner != null) {
            if (entry['value'].owner.name === "undefined undefined") {
              entry['value'].owner.name = entry['value'].owner[0].name;
              this.cd.detectChanges();
              setTimeout(() => {
                this.cd.detectChanges();
                this.nestedDataSource._updateChangeSubscription();
              }, 2000)
            }
          }
        }
      });
    }
    else {
      return
    }
  }
  noPatchAction(observation) {
    observation['controls'].actions.controls.forEach((action) => {
      if (observation.value.actions.includes(action.value)) {
        return
      }
      else {
        observation.value.actions.push(action.value);
      }
    });
  }
  actionControlArray = [];
  actionValidationCheck() {
    this.actionControlArray = [];
    this.exerciseObservationForm.controls.forEach(item => {
      item['controls'].actions.controls.forEach(actionControls => {
        this.actionControlArray.push(actionControls.valid);
        if (actionControls.invalid) {
          this.exerciseObservationForm.controls.forEach(item => {
            var observationMarked = item;
            observationMarked['controls'].actions.controls.forEach(control => {
              Object.keys(control['controls']).forEach((field) => {
                this.alertService.error('Action is required for Observation' + " " + this.selectedObservations.value.ref);
                const actionControl = control.get(field);
                actionControl.markAsTouched({ onlySelf: true });
              })
            });
          });
        }
      });
    });
  }
  observationValidationCheck() {
    this.exerciseObservationForm.controls.forEach(item => {
      if (item.invalid) {
        if (item['controls'].type.value && item['controls'].detail.value) {
          return
        }
        else {
          Object.keys(item['controls']).forEach((field) => {
            const observationArray = item.get(field);
            observationArray.markAsTouched({ onlySelf: true });
          })
        }
      }
      else {
        return
      }
    });
  }
  onSubmit(btnType: ButtonActions) {
    this.actionValidationCheck();
    if (this.exerciseObservationForm.invalid) {
      this.observationValidationCheck();
    }
    if (this.observationToDelete.length) {
      this.observationToDelete.forEach(observationID => {
        if (observationID != null) {
          this.exercisingService.deleteObseravtionById(observationID).subscribe((res) => {
            this.observationToDelete = [];
            this.alertService.success('Successfully Deleted')
          }, err => {
            console.log(err);
          })
        }
      });
    }
    else {
      let checker = arr => arr.every(v => v === true);
      var actionChecker = checker(this.actionControlArray);
      if (actionChecker) {
        this.exerciseObservation = this.exerciseObservationForm.value;
        this.exerciseObservationForm.controls.forEach((i) => {
          if (this.exerciseObservationPatch.length) {
            this.exerciseObservationPatch.forEach(response => {
              if (response.actions.length) {
                response.actions.forEach(resAction => {
                  i['controls'].actions.controls.forEach(element => {
                    if (element.value.actionRef === resAction.actionRef) {
                      element.value['id'] = resAction.id;
                      element.value['version'] = resAction.version;
                      i.value.actions.push(element.value);
                      var index = i.value.actions.indexOf(element.value);
                      if (index > -1) {
                        i.value.actions.splice(index, 1);
                      }
                    }
                    else {
                      if (i.value.actions.includes(element.value)) {
                        return
                      }
                      else {
                        i.value.actions.push(element.value);
                      }
                    }
                  });
                });
              }
              else {
                this.noPatchAction(i);
              }
            });
          }
          else {
            this.noPatchAction(i);
          }
        });
        this.exerciseObservation.forEach((observation) => {
          observation['exercise'] = this.exerciseRecord
          observation.actions.forEach(action => {
            if (action != null) {
              if (Array.isArray(action.owner)) {
                action.owner.forEach((owner) => {
                  action.owner = owner;
                });
              }
              action['exercise'] = this.exerciseRecord;
            }
          });
        });
        this.showLoader();
        this.exerciseObservationForm.value.forEach(element => {
          element.actions.forEach(elementAction => {
            if (elementAction.actionDetail == null) {
              element.actions = []
            }
          });
        });
        this.exercisingService.saveExercisingObservation(this.exerciseObservationForm.value).subscribe((res) => {
          this.navigationHandlerAfterSave(btnType, res);
          this.hideLoader();
          this.alertService.success('Successfully Created')
        }, error => {
          console.log(error);
        });
      }
      else { }
    }
  }
}
