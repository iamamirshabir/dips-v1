import { NgModule } from '@angular/core'; 
import { ContactsListComponent } from './contacts-list.component'; 
import { RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from '../../../../../../../app.material.module';

export const routes =[{
  path: '', component:ContactsListComponent,children:[
           { path: 'contacts-list', component: ContactsListComponent } 
   ]}  
  ]; 
@NgModule({
  declarations: [ContactsListComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule, 
    RouterModule.forChild(routes)
  ]
})
export class ContactsListModule { }
