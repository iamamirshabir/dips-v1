import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AccessAreas } from '../modules/admin/security/access-areas';
import { Api } from '../utils/api';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainLayoutService {
  private permissions: any[] = [];
  constructor(private httpClient: HttpClient) {
    this.permissions = [{ accessArea: AccessAreas.ADMIN, create: 1, read: 1, update: 1, delete: 1 },
    { accessArea: AccessAreas.EXERCISING, create: 1, read: 1, update: 1, delete: 1 }];
    console.log("this.permissions", this.permissions);
  }
  loggedInUser: any;
  setloggedInUser(loggedInUser) {
    this.loggedInUser = loggedInUser;
  }

  getloggedInUser() {
    return this.loggedInUser;
  }

  loggedInOrganisation: any;
  setloggedInOrganisation(loggedInOrganisation) {
    this.loggedInOrganisation = loggedInOrganisation;
  }

  getloggedInOrganisation() {
    return this.loggedInOrganisation;
  }

  getBiaMenuItems(): Observable<any> {
    return this.httpClient.get(`${environment.baseUrl + Api.BIA_MENU_ITEMS}/`+this.loggedInOrganisation.id);
  }
  
  setPermissions(permissions: any): void {
    this.permissions = permissions;
  }

  getPermissions() {
    return this.permissions;
  }

  realEntitiesFlatList: any;
  setRealEntitiesList(realEntitiesFlatList) {
    this.realEntitiesFlatList = realEntitiesFlatList;
  }

  getRealEntitiesList() {
    return this.realEntitiesFlatList;
  }
}
