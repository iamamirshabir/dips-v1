
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ProcessesFormComponent } from '../processes-form/processes-form.component';
import { ExpandListingView } from 'src/app/com/daisy/sp/common/components/expand-listing-view/expand-listing-view.interface';
import { BIAService } from '../../../bia.service';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';


@Component({
    selector: 'app-processes-list',
    templateUrl: './processes-list.component.html',
    styleUrls: ['./processes-list.component.sass']
})
export class ProcessesListComponent extends BaseClass implements OnInit {
    expandListingView: ExpandListingView;
    public tableData: any[] = [];
    public displayedColumns: any;
    public expandableColumns: any;
    public tableButtons: any;
    public filterSelectObj: any = [];
    dialogRef: MatDialogRef<ProcessesFormComponent> | null;
    processRecord: any[] = [];
    rtoList: any[];
    rtoData: any;
    subscription: any;
    processObj: any;
    processRecordData: Object;
    businessPeaklist: any;
    routeParams: any;
    biaRecordId: any;
    bia: any;
    biaRecord: any;
    constructor(private router: Router, protected activatedRoute: ActivatedRoute,
        public dialog: MatDialog, private biaService: BIAService) {
        super();
    }

    ngOnInit(): void {


        this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
        { key: 'name', name: 'Name', checked: 'true' },
        { key: 'description', name: 'Description', checked: 'true' },
        { key: 'rtoName', name: 'RTO', checked: 'true' },
        { key: 'head_count', name: 'Headcount', checked: 'true' },
        { key: 'businessPeaks', name: 'Peak Periods', checked: 'true' },
        { key: 'action', name: '', checked: 'true' }];

        this.expandableColumns = [
            [
                { key: 'sla', name: 'SLA Information' },
                { key: 'rtoReason', name: 'RTO Reason' }]
        ];

        this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
        { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

        this.setDataTable([]);
    }

    openFormByState(routeParams) {
        this.hideLoader();
        this.routeParams = routeParams;
        this.routedPageState = this.routeParams['pageState'];
        this.biaRecordId = this.routeParams.data.id;
        this.biaRecord = this.routeParams.data;
        this.getBiaRecord();
    }
    getBiaRecord() {
        this.showLoader();
        this.biaService.getBiaRecordById(this.biaRecordId).subscribe((res) => {
            this.bia = res;
            this.getProcessList();
        }, err => {
            this.hideLoader();
            console.log(err);
        });
    }

    getProcessList() {
        this.showLoader();
        this.processService.getProcessLists(this.biaRecordId).subscribe(res => {
            this.hideLoader();
            this.processRecord = res;
            this.setFormData(this.processRecord);
        }, error => {
            this.hideLoader();
            this.tableData = [];
            this.setDataTable(this.tableData);
        })
    }
    setFormData(processRecord) {
        processRecord.forEach(element => {
            element.rtoName =  this.timePointDurationbyMeasure(element.rto.measure, element.rto.duration);
        });
        processRecord.forEach(element => {
            let Templist = [];
            let stringForPeaks: string;
            if (element.biaBusinessPeaks.length > 0) {
                element.biaBusinessPeaks.forEach(value => {
                    let dateFrom = this.setShortDateFormat(value.dateFrom);
                    let dateTo = this.setShortDateFormat(value.dateTo);
                    if (dateFrom == "") {
                        stringForPeaks = dateTo + " | " + value.recurrence;
                    }
                    if (dateTo == "") {
                        stringForPeaks = dateFrom + " | " + value.recurrence;
                    }
                    if (value.recurrence == null) {
                        stringForPeaks = dateFrom + ' - ' + dateTo;
                    }
                    if (dateTo !== "" && dateFrom !== "" && value.recurrence !== null) {
                        stringForPeaks = dateFrom + ' - ' + dateTo + " | " + value.recurrence;
                    }
                });
            }
            element.businessPeaks = stringForPeaks;
        });
        this.tableData = processRecord;
        this.setDataTable(this.tableData);

    }
 

    setDataTable(tableData) {
        this.expandListingView = {
            listTitle: "",
            displayedColumns: this.displayedColumns,
            dataSource: tableData,
            tableButtons: this.tableButtons,
            pagination: true,
            search: true,
            recordsPerpage: true,
            showSelectAll: true,
            showFilters: false,
            filterSelectObj: this.filterSelectObj,
            chevronMenuClassName: ChevronMenuClassName.BIAProcessesChevronMenu,
            listObject: new Object,
            expandable: true,
            expandableColumns: this.expandableColumns
        }
        this.ExpandlistingViewService.sendExpandedListingView(this.expandListingView);
    }
    btnDoubleClicked(data) {
        this.openFormHandler(data, PageState.EDIT_STATE);
    }
    openFormHandler(record, pageState) {
        let data = { "data": record, "pageState": pageState, "bia": this.bia }
        this.dialogRef = this.dialog.open(ProcessesFormComponent, {
            width: '70%',
           
            disableClose: true,
            hasBackdrop: true,
            data: data
        });
        this.dialogRef.afterClosed().subscribe((result: any) => {
            if (result == null) {
                return
            }
            let resultData = result.data;
            if (result && result.pageState == this.PageState.ADD_STATE) {
                resultData.organisation = this.organisation;
                resultData.order = 0;
                this.saveRecord(resultData, this.PageState.ADD_STATE);
            } else if (result && result.pageState == this.PageState.EDIT_STATE) {
                this.saveRecord(resultData, this.PageState.EDIT_STATE);
            }
            this.dialogRef = null;
        });
    }
    chevronMenuClick(chevronMenu: any) {
        let btnAction = chevronMenu.btnAction;
        let data = chevronMenu.data;
        if (btnAction == ButtonActions.EDIT) {
            this.openFormHandler(data, PageState.EDIT_STATE);
        }
        if (btnAction == ButtonActions.DELETE) {
            this.deleteProcessById(data.id);
        }
        if (btnAction == ButtonActions.VIEW) {
            this.openFormHandler(data, PageState.VIEW_STATE);
        }
    }
    saveRecord(data , pageState) {
        this.showLoader();
        this.processService.saveProcess(data).subscribe(res => {
            this.hideLoader();
            this.processRecordData = res;
            if (pageState == this.PageState.ADD_STATE) {
                this.alertService.success("creation.successfull", true);
            }
            else {
                this.alertService.success("updation.successfull", true)
            }
            this.getProcessList();
        }, error => {
            this.hideLoader();
            this.tableData = [];
            this.setDataTable(this.tableData);
        })
    }
    deleteProcessById(id) {
        this.showLoader();
        this.processService.deleteProcessbyId(id).
            subscribe(res => {
                this.hideLoader();
                this.alertService.success("deleteOne.successfull", true);
                this.getProcessList();
            }, error => {
                this.hideLoader();
            })
    }

    deleteAllClick(data) {
        let processId = this.getIdsFromList(data);
        console.log("data", data)
        this.showLoader();
        this.processService.deleteAllProcess(processId).
            subscribe(res => {
                this.hideLoader();
                this.alertService.success("deleteOne.successfull", true);
                this.getProcessList();
            }, error => {
                this.hideLoader();
            })
    }

    clickComplete(btnAction: ButtonActions) {
        this.showLoader();
        this.biaRecord['processComplete'] = true;
        this.processService.saveBiaRecord(this.biaRecord).subscribe((res) => {
            this.hideLoader();
            this.alertService.success('Process Completed Successfully', true);
            var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
            this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
            this.biaRecord = res;
            this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
        }, err => {
            this.hideLoader();
            console.log(err);
        });
    }
    goBackToMainPage(btnAction: ButtonActions) {
        this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
    }
}
