import { Component, OnInit, AfterContentInit } from '@angular/core';
import { BaseClass } from '../../../utils/baseclass';
import { IListingView } from '../../../common/components/listing-view/listing-view.interface';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from '../../../common/components/chevron-menus/chevron-menu-class-names';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { RouteParams } from '../../../utils/model.route-params';
import { PageState } from '../../../utils/constants/page-state-constants';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-exercises-list',
  templateUrl: './exercises-list.component.html',
  styleUrls: ['./exercises-list.component.sass']
})
export class ExercisesListComponent extends BaseClass implements OnInit, AfterContentInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  filterForm: FormGroup;
  constructor(private router: Router, protected activatedRoute: ActivatedRoute, private formBuilder: FormBuilder) {
    super();
    activatedRoute.queryParams.subscribe(val => {
      this.filterForm = this.formBuilder.group({
        deputies: [[], Validators.required]
      });
    });
  }
  ngOnInit(): void {
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    // { key: 'status', name: 'Status' },
    { key: 'typeName', name: 'Type', checked: 'true' },
    { key: 'lead', name: 'Lead', checked: 'true' },
    { key: 'owner', name: 'Owner' },
    { key: 'startDateStr', name: 'Start date' },
    { key: 'endDateStr', name: 'End Date' },
    { key: 'testResult', name: 'Test Results', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD },
    { "name": "Edit Real Entity", "type": ButtonActions.EDIT_REAL_ENTITIES, "icon": MatIcons.REAL_ENTITY }];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', options: [] },
    // { name: 'Status', columnProp: 'status', options: [] },
    { name: 'Type', columnProp: 'typeName', options: [] },
    { name: 'Lead', columnProp: 'lead', options: [] },
    { name: 'Owner', columnProp: 'owner', options: [] },
    { name: 'Start date', columnProp: 'startDateStr', options: [] },
    { name: 'End Date', columnProp: 'endDateStr', options: [] },
    { name: 'Test Results', columnProp: 'testResult', options: [] }
    ];
    this.setDataTable([]);
  }
  ngAfterContentInit() {
    this.getExcerciseList();
  }
  getExcerciseList() {
    this.showLoader();
    this.exercisingService.getExercisingListOfOrganisation(this.organisation.id).
      subscribe(res => {
        this.hideLoader();
        this.tableData = res;
        if (this.tableData) {
          this.tableData.forEach(element => {
            element.startDateStr = this.setShortDateFormat(element.startDate);
            element.endDateStr = this.setShortDateFormat(element.endDate);
            if (element.type) {
              element.typeName = element.type.name;
            }
            if (element.lead != null && element.owner != null) {
              element.lead = element.lead.fullName;
              element.owner = element.owner.fullName;
            }
            else
              return
          });
        }
        this.setDataTable(this.tableData);
      }, error => {
        this.hideLoader();
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
  }

  setDataTable(tableData) {
    let listObject = new Object;
    listObject['isShowAreaOfScope'] = true;
    this.iListingView = {
      listTitle: this.languageTranslator('exercising.exercise.records'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ExercisesListChevronMenu,
      listObject: listObject
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, PageState.EDIT_STATE);
  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    routeParams.parentParams = this.pageParams;
    if (data) {
      routeParams.id = data['id'];
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.EXERCISING;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  printClick(data, exportType) {

  }
  deleteAllClick(data) {
    let exerciseId = this.getIdsFromList(data);
    this.showLoader();
    this.exercisingService.deleteExerciseById(exerciseId).
      subscribe(res => {
        this.hideLoader();
        this.getExcerciseList();
      }, error => {
        this.hideLoader();
      })
  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.VIEW_EXERCISE_RECORD) {
      this.openFormHandler(data, PageState.VIEW_STATE);

    }
    if (btnAction == ButtonActions.CREATE_TEMPLATE_FROM_EXERCISE) {
      this.openFormHandler(data, PageState.EDIT_STATE);

    }
    if (btnAction == ButtonActions.RERUN_EXERCISE) {
      this.openFormHandler(data, PageState.EDIT_STATE);

    }
    if (btnAction == ButtonActions.PRINT_EXERCISE_RECORD) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.EDIT_REAL_ENTITIES) {
      this.openRealEntityModel([data]);
    }
  }
  isShowAreaOfScope: boolean = false;
  showAreaOfScope(isShow) {
    this.isShowAreaOfScope = isShow;
  }
  doFilter(filters) {
    let areaOfScopeIds: any[] = [];
    if (filters && filters.length > 0) {
      filters.forEach(element => {
        areaOfScopeIds.push(element.id);
      });
      this.exercisingService.getExercisesByAreaOfScopes(areaOfScopeIds).
        subscribe(res => {
          this.tableData = res;
          if (this.tableData) {
            this.tableData.forEach(element => {
              element.startDateStr = this.setShortDateFormat(element.startDate);
              element.endDateStr = this.setShortDateFormat(element.endDate);
              if (element.type) {
                element.typeName = element.type.name;
              }
              if (element.leadContact != null) {
                element.lead = element.leadContact.firstName + " " + element.leadContact.lastName;
                element.owner = element.ownerContact.firstName + " " + element.ownerContact.lastName;
              }
              else
                return
            });
          }
          this.setDataTable(this.tableData);
        }, error => {
          this.tableData = [];
          this.setDataTable(this.tableData);
        })
    } else {
      this.getExcerciseList();
    }
  }
  updateRealEntities(data) {
    this.showLoader();
    this.exercisingService.saveAllExercisingRecord(data.records)
      .subscribe(record => {
        this.hideLoader()
        this.alertService.success("Real Entities are successfuly added to selected record");
        this.getExcerciseList();
      }, error => {
        this.hideLoader()
        this.getExcerciseList();
      })
  }
}
