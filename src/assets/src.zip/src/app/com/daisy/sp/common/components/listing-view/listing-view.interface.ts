export interface IListingView {
  listTitle: string;
  pagination: boolean;
  search: boolean;
  recordsPerpage: boolean;
  displayedColumns: Array<Object>;
  dataSource: Array<Object>;
  tableButtons: Array<any>;
  showSelectAll: boolean;
  showFilters: boolean;
  filterSelectObj: Array<any>;
  chevronMenuClassName: any;
  listObject: Object;
}