import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysisColorsComponent } from './analysis-colors.component';

describe('AnalysisColorsComponent', () => {
  let component: AnalysisColorsComponent;
  let fixture: ComponentFixture<AnalysisColorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnalysisColorsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalysisColorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
