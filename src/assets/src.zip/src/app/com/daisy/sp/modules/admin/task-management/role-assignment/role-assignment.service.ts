import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class RoleAssignmentService {

  constructor(private router: Router, private httpClient: HttpClient) { }

  saveRoleAssignments(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.ADMIN_TASK_MANAGEMENT_ROLE_ASSIGNMENT_SAVE_ALL}`, data);
  }

  getRoleAssignmentByOrgId() {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ADMIN_TASK_MANAGEMENT_ROLE_ASSIGNMENT_FIND_BY_ORG );
  }



}