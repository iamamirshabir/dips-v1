import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpandListingViewComponent } from './expand-listing-view.component';

describe('ExpandListingViewComponent', () => {
  let component: ExpandListingViewComponent;
  let fixture: ComponentFixture<ExpandListingViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpandListingViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpandListingViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
