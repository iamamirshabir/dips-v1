import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryITService {
  public catItDetails: any;
  constructor(private httpClient: HttpClient) { }

  getSubCategories(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategorySupplierByOrgId(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_SUPPLIER_FIND_BY_ORG_ID + '/' + orgID);
  }
  getRealEntityByOrgId(id){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_BY_ORG_ID+"/"+id,id);
  }
  getCategoryITByOrgId(orgID){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_IT_SERVICE_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategoryITById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_IT_SERVICE_FIND_BY_ID + '/' + id);
  }
  saveCategoryIT(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_IT_SERVICE_SAVE}`, data);
  }
 
  deleteCategoryITById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_IT_SERVICE_REMOVE_BY_ID}`, id);
  }
  getCategoryITServiceByOrgIdAndCanDoBia(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_IT_SERVICE_FIND_BY_ORG_ID + '/' + orgID + Api.CAN_DO_BIA);
  }

  getCategoryITBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_IT_SERVICE, data);
  }
}
