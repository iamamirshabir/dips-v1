import { NgModule } from '@angular/core';
import { ContactFormComponent } from './contact-form.component';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';

export const routes = [
  { path: '', component: ContactFormComponent,}
]; 
@NgModule({
  declarations: [ContactFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,    
    RouterModule.forChild(routes)
  ]
})
export class ContactFormModule { }
