import { Component, OnInit, ViewChild, ViewChildren, ElementRef, ChangeDetectorRef, AfterViewChecked, Input, Output, EventEmitter } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { BaseClass } from '../../../../../../utils/baseclass';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { RouteParams } from '../../../../../../utils/model.route-params';
import { RouteConstants } from '../../../../../../utils/constants/route-constants';
import { PageState } from '../../../../../../utils/constants/page-state-constants';
import { AfterViewInit } from '@angular/core';
import { ListRequest } from '../../../../../../utils/mode.listRequest';
import { ButtonActions } from '../../../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../../../utils/constants/mat-icons-constants';
import { IListingView } from '../../../../../../common/components/listing-view/listing-view.interface';
import { ChevronMenuClassName } from '../../../../../../common/components/chevron-menus/chevron-menu-class-names';
import { ImpactLevelsFormComponent } from '../impact-levels-form/impact-levels-form.component';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ChevronMenuService } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-service';
import { ChevronMenusComponent } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menus.component';
import { ImpactcategoriesFormComponent } from '../../impact-categories-form/impact-categories-form.component';



@Component({
  selector: 'app-impact-levels-list',
  templateUrl: './impact-levels-list.component.html',
  styleUrls: ['./impact-levels-list.component.sass']
})

export class ImpactLevelsListComponent extends BaseClass implements OnInit, AfterViewInit {
  @Input() exercise;
  iListingView: IListingView;
  public tableData: any;
  public displayedColumns: any;
  public tableButtons: any;
  form: FormGroup;
  public filterSelectObj: any = [];
  impactCatId;
  routeParams;
  impactLevelRecord: any;
  dialogRef: MatDialogRef<ImpactLevelsFormComponent> | null;
  dialogRefImpactCategory: MatDialogRef<ImpactcategoriesFormComponent> | null;
  impactcategoryRecord: any;
  impactLevelDescription: any;
  impactLevelQuestion: any;
  impactCategoryType: any;
  impactCategoryName: any;
  deleteLevelByID: boolean = false;
  @ViewChild('chevronMenuImpact') chevronMenuImpact: ChevronMenusComponent;
  @Output() chevronMenuEvent = new EventEmitter<any>();
  analysisColorsList: any;

  constructor(private router: Router, protected activatedRoute: ActivatedRoute,
    private planningForm: FormBuilder,
    public dialog: MatDialog,
    private chevronMenuService: ChevronMenuService
  ) {
    super();
    this.form = this.planningForm.group({});
  }


  ngOnInit(): void {
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'severity', name: 'Severity', checked: 'true' },
    { key: 'name', name: 'Impact Level Name', checked: 'true' },
    { key: 'colourName', name: 'Analysis Color', colType: 'colorBox', checked: 'true' },
    { key: 'description', name: 'Description', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.setDataTable([]);
  }

  ngAfterContentInit(): void {
    this.hideLoader();

  }


  openFormByState(routeParams) {
    console.log("reciever", routeParams);
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.impactCatId = this.routeParams.id;
    if (this.impactCatId) {
      this.getImpactCategoryById();
    }
  }
  getImpactCategoryById() {
    this.impactcategoriesService.getImpactCategoryById(this.impactCatId).
      subscribe(res => {
        this.impactcategoryRecord = res;
        this.setFormData(this.impactcategoryRecord);
      }, error => {
        this.tableData = [];
        this.setDataTable(this.tableData);
        this.getColorForKey(this.tableData);
      })
  }
  setFormData(impactcategoryRecord) {
    this.impactLevelDescription = impactcategoryRecord.description;
    this.impactCategoryName = impactcategoryRecord.name;

    if (impactcategoryRecord.impactCategoryLevels && impactcategoryRecord.impactCategoryLevels.length > 0)
      impactcategoryRecord.impactCategoryLevels.sort((a, b) => a.severity - b.severity);
    for (let i = 0; i < this.impactcategoryRecord.impactCategoryLevels.length; i++) {
      this.impactcategoryRecord.impactCategoryLevels[i].severity = i + 1;
    }
    this.tableData = impactcategoryRecord.impactCategoryLevels;
    this.setDataTable(this.tableData);
    this.getColorForKey(this.tableData);
  }

  getColorForKey(tableData) {
    if (tableData.length > 0) {
      tableData.forEach(item => {
        item.colourName = item.analysisColour.colour;
      });
    }
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: "",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: false,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ImpactLevelsChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  deleteAllClick(data) {
    for (var i = data.length - 1; i >= 0; i--) {
      var index = this.impactcategoryRecord.impactCategoryLevels.findIndex(x => x.id == data[i].id);
      this.impactcategoryRecord.impactCategoryLevels.splice(index, 1);

    }
    this.deleteLevelByID = true;
    this.saveImapactCategory(this.impactcategoryRecord);
    this.showLoader();

  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteImpactLevelById(data.id);
        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }
  updateImapactCategory(data) {
    this.showLoader();
    this.impactcategoriesService.saverImpactCategory(data).subscribe(res => {
      this.hideLoader();
      this.alertService.success('updation.successfull', true);
      this.impactcategoryRecord = res;
      this.setFormData(this.impactcategoryRecord);
    }, error => {
      this.hideLoader();
    })

  }


  saveImapactCategory(data) {
    this.showLoader();
    if (this.deleteLevelByID == true) {
      this.impactcategoriesService.saverImpactCategory(data).subscribe(res => {
        this.hideLoader();
        this.deleteLevelByID = false;
        this.impactcategoryRecord = res;
        this.setFormData(this.impactcategoryRecord);
      }, error => {
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
    }
    else {
      this.impactcategoriesService.saverImpactCategory(data).subscribe(res => {
        this.hideLoader();
        this.alertService.success('creation.successfull', true);
        this.impactcategoryRecord = res;
        this.setFormData(this.impactcategoryRecord);
      }, error => {
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
    }

  }

  deleteImpactLevelById(id) {
    this.showLoader();
    var index = this.impactcategoryRecord.impactCategoryLevels.findIndex(x => x.id == id);
    this.impactcategoryRecord.impactCategoryLevels.splice(index, 1);
    this.deleteLevelByID = true;
    this.saveImapactCategory(this.impactcategoryRecord);
  }


  btnDoubleClicked(data) {
    this.openFormHandler(data, PageState.EDIT_STATE);
  }
  openFormHandler(record, pageState) {
    let data = { "data": record, "pageState": pageState }
    this.dialogRef = this.dialog.open(ImpactLevelsFormComponent, {
      width: '600px',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });
    this.dialogRef.afterClosed().subscribe((result: any) => {
      if (result == null) {
        return
      }
      let impactLevel = result.data;
      if (result && result.pageState == this.PageState.ADD_STATE) {
        if (this.impactcategoryRecord.impactCategoryLevels == null) {
          this.impactcategoryRecord.impactCategoryLevels = [];
        }

        impactLevel.severity = this.impactcategoryRecord.impactCategoryLevels.length + 1;
        this.impactcategoryRecord.impactCategoryLevels.push(impactLevel);
        this.saveImapactCategory(this.impactcategoryRecord);
      } else if (result && result.pageState == this.PageState.EDIT_STATE) {
        for (var i = 0; i < this.impactcategoryRecord.impactCategoryLevels.length; i++) {
          if (this.impactcategoryRecord.impactCategoryLevels[i].id == impactLevel.id) {
            this.impactcategoryRecord.impactCategoryLevels[i].name = impactLevel.name;
            this.impactcategoryRecord.impactCategoryLevels[i].description = impactLevel.description;
            this.impactcategoryRecord.impactCategoryLevels[i].analysisColour = impactLevel.analysisColour;
          }
        }
        this.updateImapactCategory(this.impactcategoryRecord);
      }
      this.dialogRef = null;
    });
  }

  onOpenMenu(): void {
    let menusList = this.chevronMenuService.getChevronMenuClass(ChevronMenuClassName.ImpactCategoriesChevronMenu, this.impactcategoryRecord);
    this.chevronMenuImpact.data = this.impactcategoryRecord;
    this.chevronMenuImpact.setMenu(menusList);
  }
  chevronMenuImpactCategories(chevronMenuEvent: any) {
    let btnAction = chevronMenuEvent.btnAction;
    let data = chevronMenuEvent.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandlerForImpactCategories(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteImpactcategoryById(data.id);
        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandlerForImpactCategories(data, PageState.VIEW_STATE);
    }
  }
  openFormHandlerForImpactCategories(record, pageState) {
    let data = { "data": record, "pageState": pageState }
    this.dialogRefImpactCategory = this.dialog.open(ImpactcategoriesFormComponent, {
      width: '600px',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });
    this.dialogRefImpactCategory.afterClosed().subscribe((result: any) => {
      if (result == null) {
        return
      }
      let resultData = result.data;
      if (result && result.pageState == this.PageState.ADD_STATE) {
        resultData.organisation = this.organisation;
        resultData.order = 0;
        this.saveImapactCategory(resultData);
      } else if (result && result.pageState == this.PageState.EDIT_STATE) {
        this.updateImapactCategory(resultData);
      }
      this.dialogRef = null;
    });
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.BIA_CONFIG_IMPACT_CATEGORIES_LIST);
  }
  deleteImpactcategoryById(id) {
    this.showLoader();
    this.impactcategoriesService.deleteImpactCategoryId(id).
      subscribe(res => {
        this.hideLoader();
        this.getImpactCategoryById();
        this.goBackToMainPage();
      }, error => {
        this.hideLoader();
      })
  }




}

