import { Component, OnInit, Output, EventEmitter, Input, Pipe, PipeTransform, ChangeDetectorRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { RoutingService } from '../../common/services/routing-service';
import { RouteConstants } from '../../utils/constants/route-constants';
import { ModuleIDs } from '../../utils/constants/module-ids';
import { MainLayoutService } from '../main-layout-service';
import { BaseClass } from '../../utils/baseclass';
import { Router } from '@angular/router';
import { RouteParams } from '../../utils/model.route-params';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.sass']
})
export class SidenavComponent extends BaseClass implements OnInit {
  control = new FormControl();
  filterText: string;
  @Output() menuClickHandler = new EventEmitter<any>();
  @Output() parentMenuHandler = new EventEmitter<any>();
  currentModuleMenuList: any[] = [];
  currentModuleName: any = '';
  childMenu: any;
  menuList: any = [];
  biaMenuItems: any = [];

  constructor(public routingService: RoutingService, public mainLayoutService: MainLayoutService) {
    super();
  }

  ngOnInit(): void {
    this.getBiaMenuItems();
    this.initializeMenu();
  }

  initializeMenu() {

    this.menuList = [{ id: 1, name: "Favourites", moduleId: ModuleIDs.HOME, moduleName: "sp.modulesName.home", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 2, name: "Recent", moduleId: ModuleIDs.HOME, moduleName: "sp.modulesName.home", routerLink: "", enabled: true, hasChild: false, parentId: 0 },

    // { id: 109, name: "Create New", moduleId: ModuleIDs.BIA, moduleName: "sp.modulesName.bia", routerLink: RouteConstants.BIA_RECORD, enabled: true, hasChild: false, parentId: 0 },
    { id: 110, name: "All", moduleId: ModuleIDs.BIA, moduleName: "sp.modulesName.bia", routerLink: RouteConstants.BIA_RECORD_LIST, enabled: true, hasChild: false, parentId: 0 },

    { id: 201, name: "Favourites", moduleId: ModuleIDs.BCP, moduleName: "sp.modulesName.bcp", routerLink: "", enabled: false, hasChild: false, parentId: 0 },
    { id: 202, name: "Recent", moduleId: ModuleIDs.BCP, moduleName: "sp.modulesName.bcp", routerLink: "", enabled: false, hasChild: false, parentId: 0 },
    { id: 203, name: "Dashboard", moduleId: ModuleIDs.BCP, moduleName: "sp.modulesName.bcp", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 204, name: "Content Library", moduleId: ModuleIDs.BCP, moduleName: "sp.modulesName.bcp", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 205, name: "Plan Builder", moduleId: ModuleIDs.BCP, moduleName: "sp.modulesName.bcp", routerLink: "", enabled: true, hasChild: false, parentId: 0 },

    { id: 301, name: "Favourites", moduleId: ModuleIDs.NOTIFICATION, moduleName: "sp.modulesName.notification", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 302, name: "Recent", moduleId: ModuleIDs.NOTIFICATION, moduleName: "sp.modulesName.notification", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 303, name: "Dashboard", moduleId: ModuleIDs.NOTIFICATION, moduleName: "sp.modulesName.notification", routerLink: "", enabled: true, hasChild: false, parentId: 0 },

    { id: 401, name: "Favourites", moduleId: ModuleIDs.RECOVERY, moduleName: "sp.modulesName.recovery", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 402, name: "Recent", moduleId: ModuleIDs.RECOVERY, moduleName: "sp.modulesName.recovery", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 403, name: "Dashboard", moduleId: ModuleIDs.RECOVERY, moduleName: "sp.modulesName.recovery", routerLink: "", enabled: true, hasChild: false, parentId: 0 },

    { id: 501, name: "Favourites", moduleId: ModuleIDs.EXERCISING, moduleName: "sp.modulesName.exercising", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 502, name: "Recent", moduleId: ModuleIDs.EXERCISING, moduleName: "sp.modulesName.exercising", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 503, name: "Dashboard", moduleId: ModuleIDs.EXERCISING, moduleName: "sp.modulesName.exercising", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    { id: 504, name: "Test Observation", moduleId: ModuleIDs.EXERCISING, moduleName: "sp.modulesName.exercising", routerLink: "", enabled: true, hasChild: false, parentId: 0 },
    // {id:505,name:"Exercising",moduleId:ModuleIDs.EXERCISING,moduleName:"sp.modulesName.exercising",routerLink:RouteConstants.EXERCISING,enabled:true,hasChild:false,parentId:0},
    { id: 506, name: "Exercise Records", moduleId: ModuleIDs.EXERCISING, moduleName: "sp.modulesName.exercising", routerLink: RouteConstants.EXERCISES_LIST, enabled: true, hasChild: false, parentId: 0 },

    { id: 601, name: "Favourites", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: "", enabled: false, hasChild: false, parentId: 0 },
    // {id:602,name:"Recent",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin",routerLink:"",enabled:false,hasChild:false,parentId:0},  
    { id: 603, name: "Dashboard", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: false, parentId: 0 },
    { id: 604, name: "Configurations", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: '', enabled: true, hasChild: true, parentId: 0, childCount: 8 },
    { id: 6041, name: "Favourites", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: false, parentId: 604 },
    { id: 6042, name: "Recent", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.SECURITY_PROFILES, enabled: true, hasChild: false, parentId: 604 },
    {id:  6043, name: "Custom Field", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_CUSTOM_FIELD_LIST, enabled: true, hasChild: false, parentId: 604 },
    // {id:6043,name:"BIA admin",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin.sectionAdmin",routerLink:RouteConstants.CONTACTS_LIST,enabled:true,hasChild:false,parentId:604}, 
    { id: 6044, name: "BC Planning admin", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: false, parentId: 604 },
    { id: 6045, name: "Notification admin", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: false, parentId: 604 },
    { id: 6046, name: "Recovery admin", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: false, parentId: 604 },
    // {id:6047,name:"Security Profiles",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin.sectionAdmin",routerLink:RouteConstants.SECURITY_PROFILES,enabled:true,hasChild:false,parentId:604}, 
    { id: 6048, name: "Security Profiles", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.BULK_ASSOCIATIONS, enabled: true, hasChild: false, parentId: 604 },
    { id: 6049, name: "Contact", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: '', enabled: true, hasChild: true, parentId: 604, childCount: 1 },
    { id: 60491, name: "Employee Type", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.sectionAdmin", routerLink: RouteConstants.EMPLOYEE_TYPE_LIST, enabled: true, hasChild: false, parentId: 6049 },
    // {id:605,name:"Import and export",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin",routerLink:RouteConstants.CONTACTS_LIST,enabled:true,hasChild:false,parentId:0}, 
    // {id:606,name:"Messaging",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin",routerLink:RouteConstants.CONTACTS_LIST,enabled:false,hasChild:false,parentId:0},  
    { id: 607, name: "BIA configuration", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: true, parentId: 604, childCount: 9 },
    { id: 6071, name: "Analysis Colours", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_ANALYSIS_COLORS_LIST, enabled: true, hasChild: false, parentId: 607 },
    { id: 6072, name: "Timescales", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_TIMESCALES_LIST, enabled: true, hasChild: false, parentId: 607 },
    { id: 6073, name: "Impact Categories", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_IMPACT_CATEGORIES_LIST, enabled: true, hasChild: false, parentId: 607 },
  
    { id: 6075, name: "Recovery Policies", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_RECOVERY_POLICIES_LIST, enabled: true, hasChild: false, parentId: 607 },
    { id: 6076, name: "IT Service Type", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_IT_SERVICE_TYPE, enabled: true, hasChild: false, parentId: 607 },
    { id: 6077, name: "Cost Center", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_COST_CENTER, enabled: true, hasChild: false, parentId: 607 },
    { id: 6078, name: "Business Entity", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_BUSINESS_ENTITY, enabled: true, hasChild: false, parentId: 607 },
    
    // {id:608,name:"Risks",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin",routerLink:RouteConstants.CONTACTS_LIST,enabled:false,hasChild:false,parentId:0},  
    { id: 608, name: "Risks", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_RISK_LEVELS, enabled: true, hasChild: true, parentId: 607 },
    { id: 6081, name: "Risks Levels", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_RISK_LEVELS, enabled: true, hasChild: false, parentId: 608 },
    { id: 6082, name: "Risks Assessment Matrix", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_RISK_ASSESSMENT_MATRIX, enabled: true, hasChild: false, parentId: 608 },
    { id: 6083, name: "Risk Strategies", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_RISK_STRATEGIES_LIST, enabled: true, hasChild: false, parentId: 608 },
    { id: 6079, name: "Dependency Selection", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin.biaConfigurations", routerLink: RouteConstants.BIA_CONFIG_DEPENDENCY_SELECTION, enabled: true, hasChild: false, parentId: 607 },
    // {id:609,name:"Configurations",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin",routerLink:RouteConstants.CONTACTS_LIST,enabled:true,hasChild:false,parentId:0},  
    // {id:610,name:"Testing",moduleId:ModuleIDs.ADMIN,moduleName:"sp.modulesName.admin",routerLink:RouteConstants.CONTACTS_LIST,enabled:false,hasChild:false,parentId:0},  
    { id: 611, name: "Contacts", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: false, parentId: 0 },
    { id: 612, name: "Contact Groups", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CONTACT_GROUPS_LISTING, enabled: true, hasChild: false, parentId: 0 },
    { id: 613, name: "Password Policy", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.PASSWORD_POLICY_FORM, enabled: true, hasChild: false, parentId: 0 },
    { id: 614, name: "Library", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: '', enabled: true, hasChild: true, parentId: 0 },
    { id: 615, name: "Category", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.ADMIN_LIBRARY_CATEGORY, enabled: true, hasChild: false, parentId: 614 },
    // { id: 609, name: "Category Record", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CONTACTS_LIST, enabled: true, hasChild: true, parentId: 614 },
    // { id: 6091, name: "Category - IT", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CATEGORY_IT_LIST, enabled: true, hasChild: false, parentId: 609 },
    // { id: 6092, name: "Category - Supplier", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CATEGORY_supplier_LIST, enabled: true, hasChild: false, parentId: 609 },
    // { id: 6093, name: "Category - Location", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CATEGORY_LOCATION_LIST, enabled: true, hasChild: false, parentId: 609 },
    // { id: 6094, name: "Category - Business Area", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CATEGORY_BUSINESS_AREA_LIST, enabled: true, hasChild: false, parentId: 609 },
    // { id: 6095, name: "Category - Resource", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CATEGORY_RESOURCE_LIST, enabled: true, hasChild: false, parentId: 609 },
    // { id: 6096, name: "Category - Product/Service", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.CATEGORY_PRODUCT_SERVICE_LIST, enabled: true, hasChild: false, parentId: 609 }
    { id: 616, name: "Organisation", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.organisation", routerLink: RouteConstants.ORGANISATION_LIST, enabled: true, hasChild: false, parentId: 0 },
    { id: 609, name: "Task Management", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: '', enabled: true, hasChild: true, parentId: 0, childCount: 2 },
    { id: 6091, name: "Policy Creation", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.ADMIN_TASK_MANAGEMENT_POLICY_CREATION_LIST, enabled: true, hasChild: false, parentId: 609 },
    { id: 6092, name: "Role Assignment", moduleId: ModuleIDs.ADMIN, moduleName: "sp.modulesName.admin", routerLink: RouteConstants.ADMIN_TASK_MANAGEMENT_ROLE_ASSIGNMENT, enabled: true, hasChild: false, parentId: 609 },
    ];
   
  }
  linkClick(menu) {
    this.closeWindow(menu);
  }
  getMenusByModuleId(moduleId, parentId = 0) {
    this.filterText = '';
    this.currentModuleMenuList = this.menuList.filter(item => item.moduleId === moduleId && item.parentId === parentId);
    this.childMenu = this.currentModuleMenuList[0];
    this.currentModuleName = this.currentModuleMenuList[0].moduleName;
  }
  getBiaMenuItems() {
    this.mainLayoutService.getBiaMenuItems().subscribe((res) => {
      res.forEach(element => {
        element['moduleId'] = ModuleIDs.BIA;
        element['moduleName'] = "sp.modulesName.bia";
        element['routerLink'] = RouteConstants.BIA_RECORD_LIST;
        element['enabled'] = true;
        element['hasChild'] = false;
        element['parentId'] = 0;
        this.menuList.push(element);
      });
      // var depenedencyMap = { id: 109, name: "Dependency Map", moduleId: ModuleIDs.BIA, moduleName: "sp.modulesName.bia", routerLink: RouteConstants.BIA_RECORD_LIST, enabled: true, hasChild: false, parentId: 0 };
      // this.menuList.push(depenedencyMap);
    }, err => {
      console.log(err);
    });
  }
  closeWindow(menu = null) {
    this.filterText = '';
    this.menuClickHandler.emit(menu);
  }
  getParentMenu(menu) {
    if (menu.parentId > 0) {
      this.filterText = '';
      this.parentMenuHandler.emit(menu);
    } else {
      this.closeWindow(null);
    }
  }
}