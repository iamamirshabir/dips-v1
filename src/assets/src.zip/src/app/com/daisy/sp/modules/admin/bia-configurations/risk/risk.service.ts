import { Api } from './../../../../utils/api';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RiskService {

  constructor(private router:Router, private httpClient:HttpClient) { }

  saveRiskLevel(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_RISK_LEVELS_SAVE}`,data);
  } 
  saveAllRiskLevel(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_RISK_LEVELS_SAVE_ALL}`,data);
  } 
  getRiskLevelsByOrgId(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_RISK_LEVELS_BY_ORG_ID+id);
  }
  saveRiskAssessmentMatrix(data){
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_RISK_ASSESSMENT_SAVE}`,data);
  }
  getRiskAssessment(){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_FIND_RISK_ASSESSMENT_BY_ORG);
  }

}
