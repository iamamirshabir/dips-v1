import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class RiskStrategiesService {

  constructor(private router : Router,private httpClient: HttpClient){}

  saverRiskStrategy(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_RISK_STRATEGY_SAVE}`,data);
  } 

  getsaverRiskStrategyLists(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_RISK_STRATEGY_LIST+id);
  } 

  deleteRiskStrategyId(id){
    return this.httpClient.delete<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_RISK_STRATEGY_REMOVE_BY_ID+id);
  }
  deleteAllRiskStrategy(obj){
    return this.httpClient.post<any>(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_RISK_STRATEGY_REMOVE_ALL}`,obj);
  }

}