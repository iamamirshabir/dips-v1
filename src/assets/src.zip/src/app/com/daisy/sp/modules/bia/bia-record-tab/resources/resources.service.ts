import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ResourcesService {

  biaValue: any =0;


  constructor(private router : Router,private httpClient: HttpClient){}


  getRtoTimePonints(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_RTO + id + '/type/' + 2);
  }

  saveBIAResource(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_RESOURCE_SAVE}`,data);
  } 

  saveAllBiaResources(data)
  {
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_RESOURCE_SAVE_ALL}`,data)
  }

  getBIAResourceLists(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_RESOURCE_LIST_BY_BIA_ID+id);
  } 

  getResourcesLists(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.GENERAL_RESOURCES_LIST_BY_ID+id);
  } 

  deleteResourcebyId(id){
    return this.httpClient.post<any>(`${environment.baseUrl+Api.BIA_RESOURCE_REMOVE_ALL}`, id);
  }
  deleteAllResources(id): Observable<any> {
    return this.httpClient.post<any>(`${environment.baseUrl+Api.BIA_RESOURCE_REMOVE_ALL}`, id);
  }
  saveBiaRecord(biaRecord): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
}

}