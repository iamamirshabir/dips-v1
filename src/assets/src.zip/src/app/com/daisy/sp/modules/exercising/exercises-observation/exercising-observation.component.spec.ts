import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExercisingObservationComponent } from './exercising-observation.component';

describe('ExercisingObservationComponent', () => {
  let component: ExercisingObservationComponent;
  let fixture: ComponentFixture<ExercisingObservationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExercisingObservationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExercisingObservationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
