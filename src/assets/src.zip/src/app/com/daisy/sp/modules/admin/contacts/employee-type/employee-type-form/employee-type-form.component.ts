import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';

@Component({
  selector: 'app-employee-type-form',
  templateUrl: './employee-type-form.component.html',
  styleUrls: ['./employee-type-form.component.sass']
})
export class EmployeeTypeFormComponent extends BaseClass implements OnInit {

  employeeTypeForm: FormGroup;
  employeeType: any;
  routeParams: any;
  employeeTypeId: any;
  employeeTypeObject: any;
  public modalData: any;
  public wasFormChanged = false;

  constructor(private formBuilder: FormBuilder, public dialog: MatDialog, public dialogRef: MatDialogRef<EmployeeTypeFormComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.initialiseFormData();
    this.modalData = data;
  }
  get f() { return this.employeeTypeForm.controls; }
  ngOnInit(): void {
    if(this.modalData.pageState && this.modalData.data){
      this.modalData.data.typeGroup = { contactType : this.modalData.data.contactType , biaType : this.modalData.data.biaType};
      if(this.modalData.pageState == this.PageState.VIEW_STATE){
        this.employeeTypeForm.disable();
      }
      this.employeeTypeForm.patchValue(this.modalData.data);
    }
  }

  initialiseFormData() {
    this.employeeTypeForm = this.formBuilder.group({
      name:[null, Validators.required],
      description: [''],
      id: [null],
      version: [null],
      typeGroup: new FormGroup({
        contactType: new FormControl(true),
        biaType: new FormControl(false)
      }, this.requireCheckboxesToBeCheckedValidator(1))
    });
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  closeModal(): void {
    this.dialogRef.close(null);
  }

  saveFormData(): void {
    if (this.employeeTypeForm.invalid) {
      Object.keys(this.employeeTypeForm.controls).forEach(field => {
        const control = this.employeeTypeForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      return;
    }
    
    this.modalData.data = this.employeeTypeForm.value;
    this.dialogRef.close(this.modalData);
  }

  requireCheckboxesToBeCheckedValidator(minRequired = 1): ValidatorFn {
    return function validate (formGroup: FormGroup) {
      let checked = 0;
      Object.keys(formGroup.controls).forEach(key => {
        const control = formGroup.controls[key];
        if (control.value === true) {
          checked ++;
        }
      });
      if (checked < minRequired) {
        return {
          requireOneCheckboxToBeChecked: true,
        };
      }
      return null;
    };
  }
}
