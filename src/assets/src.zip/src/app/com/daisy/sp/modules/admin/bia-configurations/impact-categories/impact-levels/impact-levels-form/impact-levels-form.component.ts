import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../../real-entity/real-entity-form/real-entity-form.component';


@Component({
  selector: 'app-impact-levels-form',
  templateUrl: './impact-levels-form.component.html',
  styleUrls: ['./impact-levels-form.component.sass']
})
export class ImpactLevelsFormComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  analysisColorsList: any = [];
  selectedAnalysisColor: any;
  selectedColor: any;
  requiredAnalysisColor: boolean = null;

  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RealEntityFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
    console.log("modelData", this.modalData);
  }
  public ngOnInit(): void {
    this.getAnalysisColorsList();
    this.modalFormFroup = this.fb.group({
      id: [null],
      name: [null, [Validators.required]],
      description: [null],
      severity: [0],
      version: [null],
      analysisColour: [null, [Validators.required]]
    });
    if (this.modalData) {
      this.modalFormFroup.patchValue(this.modalData.data);
      if (this.modalData.data['analysisColour']) {
        this.selectedAnalysisColor = this.modalData.data['analysisColour'];
        this.selectedColor = this.modalData.data['analysisColour'].colour;
      }
    }
  }

  saveFormData(): void {

    this.modalFormFroup.controls['analysisColour'].setValue(this.selectedAnalysisColor);
    if (this.modalFormFroup.controls['analysisColour'].value == null) {
      this.requiredAnalysisColor = true;
    }
    else {
      this.requiredAnalysisColor = false;
    }
    if (this.modalFormFroup.invalid) {
      return;
    }

    this.modalData.data = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  getAnalysisColorsList() {
    this.analysisColorsService.getAnalysisColorsList(this.organisation.id).
      subscribe(res => {
        this.analysisColorsList = res;
      }, error => {

      })
  }
  onChange(value) {
    console.log(value);
    this.requiredAnalysisColor = false;
    this.selectedAnalysisColor = value;
    this.selectedColor = value.colour;

  }
}