import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-it',
  templateUrl: './category-it.component.html',
  styleUrls: ['./category-it.component.sass']
})
export class CategoryITComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
