import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, forkJoin } from 'rxjs';
import { Api } from '../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class SecurityProfilesService {

  constructor(private router : Router,private httpClient: HttpClient){}

  getPageData(): Observable<any[]> {
    let contactList = this.httpClient.get<any>(`${environment.baseUrl}`+Api.CONTACT_FIND_ALL_CONTACTS);
    let securityProfilesList = this.httpClient.get<any>(`${environment.baseUrl}`+Api.SECURITY_FIND_SECURITY_ROLES);
    return forkJoin([contactList, securityProfilesList]);
  }

}