import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-supplier',
  templateUrl: './category-supplier.component.html',
  styleUrls: ['./category-supplier.component.sass']
})
export class CategorySupplierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
