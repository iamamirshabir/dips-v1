import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recovery-policies',
  templateUrl: './recovery-policies.component.html',
  styleUrls: ['./recovery-policies.component.sass']
})
export class RecoveryPoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
