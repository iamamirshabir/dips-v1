import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';
import { EditableListingView } from '../../../../common/components/editable-listing-view/editable-listing-view.interface';
import { SpChipFormFieldComponent } from '../../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { CategoryTypes } from '../../../../utils/constants/category-types';
import { BIAService } from '../../bia.service';
import { BehaviorSubject } from 'rxjs';
import { GlobalConstants } from '../../../../utils/global-constants';
import { CdkDragDrop } from '@angular/cdk/drag-drop';


export interface User {
  count: number;
  employeeType: string;
  location: string;
}

@Component({
  selector: 'app-general-information',
  templateUrl: './general-information.component.html',
  styleUrls: ['./general-information.component.sass'],
})

export class GeneralInformationComponent extends BaseClass implements OnInit {

  iListingView: EditableListingView;
  public filterSelectObj: any = [];
  public tableButtons: any;
  public displayedColumns: any = [];

  hourDiff: number;
  operatingDays = [{ key: "MONDAY", day: "Monday" },
  { key: "TUESDAY", day: "Tuesday" },
  { key: "WEDNESDAY", day: "Wednesday" },
  { key: "THURSDAY", day: "Thursday" },
  { key: "FRIDAY", day: "Friday" },
  { key: "SATURDAY", day: "Saturday" },
  { key: "SUNDAY", day: "Sunday" },
  { key: "PUBLIC_HOLIDAY", day: "Public Holiday" }];

  recurrenceType = [{ key: "ANNUALLY", name: "Yearly" },
  { key: "MONTHLY", name: "Monthly" },
  { key: "LOCALLY", name: "Weekly" }];

  routeParams: any;
  biaRecordId: any;
  locationHeadCount: FormArray = this.fb.array([]);
  generalInformationForm: FormGroup;
  biaRecordObject: any;
  selectedBiaCategory: any;
  biaRecord: any;
  countValue: any;
  countTotal: any = [];
  employeeList: any = [];
  inputLocationHeadCount: any = [];
  @ViewChild('participantContact') participantContact: SpChipFormFieldComponent;
  @ViewChild('realEntity') realEntity: SpChipFormFieldComponent;
  @ViewChild('locationField') locationField: SpChipFormFieldComponent;
  @ViewChild('new_field') new_field: SpChipFormFieldComponent;
  locationEmployee: boolean = false;
  setGeneralComplete: boolean = false;
  ARTArray: any[] = [];
  artTimeScale: any;
  selectedArtTimePoints: any[];
  timeScales: any;
  ARTdurationString: any;
  displayColumns: any = [];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  memberDropped: any;
  globals: GlobalConstants;
  employeeTypes: any = [];
  employeeCount: any;
  columns = [
    { key: 'position', name: 'No.' },
    { key: 'weight', name: 'Weight' },
    { key: 'symbol', name: 'Symbol' },
  ];
  tempChecked: boolean = false;
  tempRecieved: boolean = false;
  emptyTempHolding: boolean = false;
  recordlocationHeadCount: any = [];
  employeeCountSum: number = 0;
  temporaryHoldingLocation: any = [];
  matchItem: boolean;


  constructor(private fb: FormBuilder, private biaService: BIAService, globals: GlobalConstants) {
    super();
    this.globals = globals;

    this.generalInformationForm = this.fb.group({
      description: [''],
      businessPeaks: new FormArray([]),
      operatingHours: new FormArray([]),
      locationHeadCount: this.locationHeadCount,
      headCount: new FormArray([]),
      realEntity: [null],
      participants: [null],
      art: [null],
      status: [0],
    });
    this.createFormArrays();
  }
  employeeCheckId = [];

  ngOnInit(): void {
    this.tableButtons = [];
    this.biaService.getEmployeeHeadCounts(this.organisation.id).subscribe((res) => {
      res.forEach(element => {
        this.employeeCheckId.push(element.id);
        this.employeeTypes.push({ key: element.name, name: element.name, object: element });
      });
      this.displayColumns.push("location");
      this.displayColumns = this.displayColumns.concat(this.employeeTypes.map(x => x.key));
      this.displayColumns.push("actions");
    });
  }

  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.biaRecord = this.routeParams.data;
    this.selectedBiaCategory = this.biaRecord.categoryRecord.category.type;
    if (this.routedPageState != 1) {
      this.biaService.getBiaRecordById(this.biaRecordId).subscribe((res) => {
        this.biaRecordObject = res;
        res.operatingHours.forEach(element => {
          var timeStart = new Date("01/01/2007 " + element.startTime).getHours();
          var timeEnd = new Date("01/01/2007 " + element.endTime).getHours();
          this.hourDiff = timeEnd - timeStart;
          element['hourDiff'] = this.hourDiff;
        });

        if (this.biaRecordObject.headCount.length) {
          this.getCountofBia(this.biaRecordObject.headCount);
        }
        else {
          this.locationEmployee = false;
          this.getEmployeeHeadCounts();
        }
        if (this.biaRecordObject.businessPeaks.length) {
          this.biaRecordObject.businessPeaks.forEach(element => {
            this.createBusinessPeaksArray();
          });
        }
        else {
          this.createBusinessPeaksArray();
        }
        if (this.biaRecordObject.realEntity.length) {
          this.realEntity.patchDataInControls(this.biaRecordObject['realEntity']);
        }
        this.participantContact.patchDataInControls(this.biaRecordObject['participants']);

        this.artTimeScale = this.biaRecordObject.categoryRecord.category['artTimeScale'];
        if (this.artTimeScale) {
          this.getArtTimeScales();
        }
        if (this.biaRecordObject.locationHeadCount.length) {
          this.recordlocationHeadCount = this.biaRecordObject.locationHeadCount;
          this.biaRecordObject.locationHeadCount.forEach(element => {
            element.employeeType['count'] = element.count;
            // delete element.count;
          });
          const clubArray = (arr) => {
            return arr.reduce((acc, val, ind) => {
              const index = acc.findIndex(el => el.location.id === val.location.id);
              if (index !== -1) {
                const key = Object.keys(val)[1];
                acc[index][key] = val[key];
              } else {
                acc.push(val);
              };
              return acc;
            }, []);
          };
          var result = clubArray(this.biaRecordObject.locationHeadCount);

          result.forEach(employee => {
            this.addRow();
            employee['employees'] = [];
          });
          result.forEach(duplicate => {
            this.biaRecordObject.locationHeadCount.forEach(locationRow => {
              if (duplicate.location.id === locationRow.location.id) {
                duplicate.employees.push(locationRow.employeeType)
                //  delete (duplicate.employeeType)
              }
            });
            if (duplicate.employees.length < this.employeeTypes.length) {
              this.employeeTypes.forEach(element => {
                duplicate.employees.push(element)
              });
            }
          });
          this.generalInformationForm.patchValue(this.biaRecordObject);
        }
        else {
          this.generalInformationForm.patchValue(this.biaRecordObject);
          this.addRow();
        }
        function mapOrder(array, order, key) {

          array.sort(function (a, b) {
            var A = a[key], B = b[key];

            if (order.indexOf(A) > order.indexOf(B)) {
              return 1;
            } else {
              return -1;
            }

          });

          return array;
        };
        var item_order = [];
        this.employeeTypes.forEach(element => {
          item_order.push(element.name)
        });
        console.log(item_order);
        console.log(result);
        result.forEach(element => {
          element['name'] = element.employeeType.name;
        });

        var a = mapOrder(result, item_order, 'name')
        console.log(a);


        if (result) {
          console.log(this.locationHeadCount);
          this.locationHeadCount.patchValue(result);
          this.temporaryHoldingLocation = result;
        }

        if (this.temporaryHoldingLocation.length) {
          this.tempRecieved = true;
        }
      }, err => {
        console.log(err);
      });
    }
    else {
      this.getEmployeeHeadCounts();
    }
  }

  clicked(countValue, column, locationGet, rowValue, i, j) {
    console.log(countValue);
    console.log(column);
    console.log(locationGet);
    console.log(rowValue);
    console.log(i);
    console.log(j);


    this.matchItem = false;
    var tempHoldingForTemp = [];
    if (this.tempRecieved) {
      this.temporaryHoldingLocation.forEach(employeeCheck => {
        if (employeeCheck.employees) {
          if (employeeCheck.employees.length) {
            if (employeeCheck.employees != null && employeeCheck.employees.length)
              employeeCheck.employees.forEach(element => {
                if (element.id) {
                  var object: any = {
                    id: null,
                    version: null,
                    location: employeeCheck.location,
                    employeeType: element,
                    count: element.count
                  };
                  tempHoldingForTemp.push(object);
                }
              });
          }
        }
      });
      this.tempRecieved = false;
      this.tempChecked = true;
      this.temporaryHoldingLocation = tempHoldingForTemp;
    }
    var object: any = {
      id: null,
      version: null,
      location: locationGet,
      employeeType: column.object,
      count: countValue
    };
    if (this.temporaryHoldingLocation.length === 0) {
      this.temporaryHoldingLocation.push(object);
    }
    else {
      this.temporaryHoldingLocation.forEach((item) => {
        if (item.location.length && object.location.length) {
          if (item.employeeType.id === object.employeeType.id && item.location[0].id === object.location[0].id) {
            this.matchItem = true;
            const index = this.temporaryHoldingLocation.findIndex(item => item.employeeType.id === object.employeeType.id && item.location[0].id === object.location[0].id)
            this.temporaryHoldingLocation[index] = object;
          }
        }
        else {
          if (item.employeeType.id === object.employeeType.id && item.location.id === object.location.id) {
            this.matchItem = true;
            const index = this.temporaryHoldingLocation.findIndex(item => item.employeeType.id === object.employeeType.id && item.location.id === object.location.id)
            this.temporaryHoldingLocation[index] = object;
          }
        }
      });
      if (!this.matchItem) {
        this.temporaryHoldingLocation.push(object);
      }
    }
  }
  addRow(noUpdate?: boolean, droppedElement = null, objectToReplace = null) {
    this.globals.DROPPED_ID_ARRAY = [];
    if (objectToReplace != null && objectToReplace.key === 2) {
      var row = this.fb.group({
        id: [null],
        count: [null],
        version: [null],
        location: [objectToReplace.memberDropped, Validators.required],
        employeeType: [null],
        employees: [null]
      });
      this.locationHeadCount.insert(objectToReplace.index, row);
    }
    else {
      // if (this.locationHeadCount.controls[this.locationHeadCount.controls.length - 1] != undefined) {
      //   if (this.locationHeadCount.controls[this.locationHeadCount.controls.length - 1]['controls'].location.invalid) {
      //     this.locationHeadCount.controls[this.locationHeadCount.controls.length - 1]['controls'].location.markAsTouched();
      //     return
      //   }
      // }
      var row = this.fb.group({
        id: [null],
        count: [null],
        version: [null],
        location: [null],
        employeeType: [null],
        employees: [null],
      });
      this.locationHeadCount.push(row);
    }
    if (!noUpdate) { this.updateView(); }
    if (droppedElement != null) {
      row.controls.location.patchValue(droppedElement);
    }
    for (var i = 0; i < this.locationHeadCount.controls.length; i++) {
      this.globals.DROPPED_ID_ARRAY.push('list-' + i)
    }
  }

  updateView() {
    this.dataSource.next(this.locationHeadCount.controls);
  }

  dropFromSearch(event: CdkDragDrop<string[]>, businessAreaRow) {
    this.memberDropped = event.previousContainer.data;

    if (this.memberDropped[0].category.type != CategoryTypes.LOCATION) {
      return
    }

    if (businessAreaRow.value.location === null) {
      if (this.memberDropped.length === 1 && this.locationHeadCount.value[0].location === null) {
        this.locationHeadCount.controls[0]['controls'].location.patchValue(this.memberDropped[0]);
        this.locationField.patchDataInControls(this.locationHeadCount.controls[0]['controls'].location.value);
      }
      else if (this.memberDropped.length === 1 && this.locationHeadCount.value[this.locationHeadCount.value.length - 1].location === null) {
        this.locationHeadCount.controls.pop();
        this.addRow(false, this.memberDropped[0]);
      }
      else if (this.memberDropped.length > 1 && this.locationHeadCount.value[0].location === null) {
        this.locationHeadCount.controls[0]['controls'].location.patchValue(this.memberDropped[0]);
        this.locationField.patchDataInControls(this.locationHeadCount.controls[0]['controls'].location.value);
        for (var i = 1; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else if (this.memberDropped.length > 1 && this.locationHeadCount.value[this.locationHeadCount.value.length - 1].location === null) {
        this.locationHeadCount.controls.pop();
        for (var i = 0; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else {
        this.memberDropped.forEach(droppedElement => {
          if (droppedElement['dragged']) {
            this.addRow(false, droppedElement);
          }
        });
      }
    }

    else {
      if (this.memberDropped.length > 1) {
        this.alertService.error("You can replace single record at a time");
        return
      }
      const index = this.locationHeadCount.controls.indexOf(businessAreaRow);
      var row = this.locationHeadCount.controls[index];
      if (row.value.id != null) {
        this.businessAreaService.deleteBusinessAreaRow([row.value.id]).subscribe((res) => { });
      }
      this.locationHeadCount.removeAt(index);
      var memberObject = { key: 2, index: index, memberDropped: this.memberDropped[0], rowDropped: businessAreaRow };
      this.addRow(false, this.memberDropped[0], memberObject);
    }
  }

  getEmployeeHeadCounts() {
    var itemsProcessed = 0;
    this.biaService.getEmployeeHeadCounts(this.organisation.id).subscribe((res) => {
      res.forEach((element) => {
        if (!this.locationEmployee) {
          this.createNewHeadCountArray(element);
        }
        this.employeeList.push(element);
        itemsProcessed++;
        this.displayedColumns.push(element.name);
        if (itemsProcessed === res.length) {
          this.displayedColumns.unshift('name')
        }
      });
    }, err => {
      console.log(err);
    });
  }
  deleteRow(index: number, row) {
    const control = this.generalInformationForm.get('locationHeadCount') as FormArray;
    control.removeAt(index);
    this.biaRecordObject.locationHeadCount = this.generalInformationForm.get('locationHeadCount') as FormArray;
    this.tempChecked = false;
    this.biaRecordObject.locationHeadCount.value.forEach(element => {
      if (element.employees && element.employees.length) {
        this.emptyTempHolding = true;
      }
    });
    this.updateView();
    if (this.locationHeadCount.controls.length === 0) {
      this.addRow();
    }
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: "",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: false,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ImpactCategoriesChevronMenu,
      listObject: new Object
    }
    this.EditablelistingViewService.sendListingView(this.iListingView);
  }
  createFormArrays() {
    this.createOperatingHoursArray();
  }
  get operatingHour() {
    return this.generalInformationForm.controls["operatingHours"] as FormArray;
  }
  hours(): FormArray {
    return this.generalInformationForm.controls["operatingHours"] as FormArray;
  }
  createOperatingHoursArray() {
    for (let i = 0; i < this.operatingDays.length; i++) {
      const operatingHoursForm = this.fb.group({
        id: null,
        type: [this.operatingDays[i].key],
        startTime: ["", Validators.required],
        endTime: ["", Validators.required],
        hourDiff: [""],
        name: [this.operatingDays[i].day],
        version: null
      });
      this.operatingHour.push(operatingHoursForm);
    }
  }
  get businessPeaks() {
    return this.generalInformationForm.controls["businessPeaks"] as FormArray;
  }
  peaks(): FormArray {
    return this.generalInformationForm.controls["businessPeaks"] as FormArray;
  }
  createBusinessPeaksArray() {
    const businessPeaksForm = this.fb.group({
      id: [null],
      dateFrom: ['', Validators.required],
      dateTo: [''],
      recurrence: ['', Validators.required],
      version: [null]
    });
    this.businessPeaks.push(businessPeaksForm);
  }
  get locationHeadCounts() {
    return this.generalInformationForm.controls["locationHeadCount"] as FormArray;
  }
  locationCounts(): FormArray {
    return this.generalInformationForm.controls["locationHeadCount"] as FormArray;
  }
  createLocationHeadCountsNewArray(param) {
    const businessPeaksForm = this.fb.group({
      id: [null],
      name: [param.name],
      count: [null],
      version: [null],
      location: [param],
      employeeType: [null],
    });
    this.locationHeadCounts.push(businessPeaksForm);
  }
  get headCounts() {
    return this.generalInformationForm.controls["headCount"] as FormArray;
  }
  headCount(): FormArray {
    return this.generalInformationForm.controls["headCount"] as FormArray;
  }
  createHeadCountArray(param) {
    const headCount = this.fb.group({
      id: [null],
      count: [param.count],
      version: [null],
      employeeType: [param.employeeType],
    });
    this.headCounts.push(headCount);
  }
  createNewHeadCountArray(param) {
    const headCount = this.fb.group({
      id: [null],
      count: [null],
      version: [null],
      employeeType: [param],
    });
    this.headCounts.push(headCount);
  }
  removeBusinessPeaksRow(index) {
    const control = <FormArray>this.generalInformationForm.controls['businessPeaks'];
    control.removeAt(index);
    if (control.controls.length == 0) {
      this.createBusinessPeaksArray();
    }
  }
  getCountofBia(biaCount) {

    function mapOrder(array, order, key) {

      array.sort(function (a, b) {
        var A = a[key], B = b[key];

        if (order.indexOf(A) > order.indexOf(B)) {
          return 1;
        } else {
          return -1;
        }

      });

      return array;
    };
    var item_order = [];
    this.employeeTypes.forEach(element => {
      item_order.push(element.name)
    });
    biaCount.forEach(element => {
      element['name'] = element.employeeType.name;
    });
    var a = mapOrder(biaCount, item_order, 'name')
    biaCount.forEach(counts => {
      this.employeeCountSum = counts.count + this.employeeCountSum;
      this.createHeadCountArray(counts);
    });
  }
  clickedEmployee() {
    this.employeeCountSum = 0;
    this.generalInformationForm.value.headCount.forEach(element => {
      this.employeeCountSum = element.count + this.employeeCountSum;
    });
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.id === f2.id;
  }
  compareFnForRecurrence: ((f1: any, f2: any) => boolean) | null = this.compareByValueForRecurrence;
  compareByValueForRecurrence(f1: any, f2: any) {
    return f1 && f2 && f1 === f2;
  }
  setTime(selectedDay, diff) {
    if (selectedDay.controls.hourDiff.value === 23) {
      selectedDay.controls.startTime.reset();
      selectedDay.controls.endTime.reset();
      if (this.hourDiff > 0) {
        this.hourDiff = 24 - this.hourDiff;
      }
    }
    else {
      selectedDay.controls.startTime.setValue("00:00");
      selectedDay.controls.endTime.setValue("23:59");
      var timeStart = new Date("01/01/2007 " + selectedDay.controls.startTime.value).getHours();
      var timeEnd = new Date("01/01/2007 " + selectedDay.controls.endTime.value).getHours();
      this.hourDiff = timeEnd - timeStart;
      if (this.hourDiff < 0) {
        this.hourDiff = 24 + this.hourDiff;
      }
    }
    selectedDay.controls.hourDiff.setValue(this.hourDiff);
  }
  mergeRecordGeneralValues() {
    this.biaRecordObject['businessPeaks'] = this.generalInformationForm.value.businessPeaks;
    this.biaRecordObject['description'] = this.generalInformationForm.value.description;
    this.biaRecordObject['headCount'] = this.generalInformationForm.value.headCount;
    this.biaRecordObject['locationHeadCount'] = this.generalInformationForm.value.locationHeadCount;
    this.biaRecordObject['operatingHours'] = this.generalInformationForm.value.operatingHours;
    this.biaRecordObject['participants'] = this.generalInformationForm.value.participants;
    this.biaRecordObject['realEntity'] = this.generalInformationForm.value.realEntity;
    this.biaRecordObject['recoveryPolicy'] = this.biaRecord.recoveryPolicy;
    this.biaRecordObject['status'] = this.generalInformationForm.value.status;
    this.biaRecordObject['art'] = this.generalInformationForm.value.art;
    if (this.setGeneralComplete) {
      this.biaRecordObject['generalComplete'] = true;
    }
  }
  clickComplete(btnAction: ButtonActions) {
    this.biaRecordObject['generalComplete'] = true;
    this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('General Information Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      this.biaRecord = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
      console.log(err);
    })
  }
  goBackToMainPage(btnAction: ButtonActions) {
    // this.checkFormChange(this.generalInformationForm);
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams,this.generalInformationForm);
  }
  getArtTimeScales() {
    this.showLoader
    this.timeScalesService.getTimeScalesListById(this.artTimeScale['id']).subscribe((res) => {
      this.hideLoader();
      this.timeScales = res;
      if (this.timeScales.timePoints) {
        this.timeScales.timePoints.forEach(element => {
          this.ARTdurationString = this.timePointDurationbyMeasure(element.measure, element.duration);
          element['durationString'] = this.ARTdurationString;
          this.ARTArray.push(element);
        });
      }
    }, err => {
      this.hideLoader();
    });
  }

  onSubmit(btnAction: ButtonActions) {
    this.mergeRecordGeneralValues();

    if (!this.tempChecked) {
      if (this.emptyTempHolding) {
        this.temporaryHoldingLocation = [];
      }
      this.biaRecordObject.locationHeadCount.forEach(rowCheck => {
        if (rowCheck.employees != null && rowCheck.employees.length)
          rowCheck.employees.forEach(element => {
            if (element.id) {
              var object: any = {
                id: null,
                version: null,
                location: rowCheck.location,
                employeeType: element,
                count: element.count
              };
            }
            this.temporaryHoldingLocation.push(object);
          });
      });
    }

    this.biaRecordObject.locationHeadCount = this.temporaryHoldingLocation;
    this.biaRecordObject.locationHeadCount.forEach(locationCheck => {
      if (locationCheck && locationCheck.location && locationCheck.location.length) {
        locationCheck.location = locationCheck.location[0];
      }
    });

    switch (this.selectedBiaCategory) {

      case CategoryTypes.PRODUCT:
        this.biaRecordObject.locationHeadCount = [];
        this.biaRecordObject.headCount = [];
        this.biaRecordObject.realEntity = [];
        this.biaRecordObject.businessPeaks = [];
        this.biaRecordObject.operatingHours = [];
        this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
          this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
          this.hideLoader();
          if (this.routedPageState === 1) {
            this.alertService.success("Successfully Created");
          }
          else {
            this.alertService.success("Successfully Updated")
          }
        }, err => {
          this.hideLoader();
          console.log(err);
        })
        break;
      case CategoryTypes.SUPPLIER:
        this.biaRecordObject.locationHeadCount = [];
        this.biaRecordObject.headCount = [];
        this.biaRecordObject.realEntity = [];
        this.biaRecordObject.businessPeaks = [];
        this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
          this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
          this.hideLoader();
          if (this.routedPageState === 1) {
            this.alertService.success("Successfully Created");
          }
          else {
            this.alertService.success("Successfully Updated")
          }
        }, err => {
          this.hideLoader();
          console.log(err);
        })
        break;
      case CategoryTypes.IT:
        this.biaRecordObject.locationHeadCount = [];
        this.biaRecordObject.headCount = [];
        this.biaRecordObject.realEntity = [];
        this.biaRecordObject.businessPeaks = [];
        this.biaRecordObject.operatingHours = [];
        this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
          this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
          this.hideLoader();
          if (this.routedPageState === 1) {
            this.alertService.success("Successfully Created");
          }
          else {
            this.alertService.success("Successfully Updated")
          }
        }, err => {
          this.hideLoader();
          console.log(err);
        })
        break;
      case CategoryTypes.BUSINESS_AREA:
        this.biaRecordObject.realEntity = [];
        this.biaRecordObject.locationHeadCount = this.filterSummaryEntries(this.biaRecordObject);
        this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
          this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
          this.hideLoader();
          if (this.routedPageState === 1) {
            this.alertService.success("Successfully Created");
          }
          else {
            this.alertService.success("Successfully Updated")
          }
        }, err => {
          this.hideLoader();
          console.log(err);
        });
        break;
      case CategoryTypes.RESOURCE:
        this.biaRecordObject.locationHeadCount = [];
        this.biaRecordObject.headCount = [];
        this.biaRecordObject.realEntity = [];
        this.biaRecordObject.businessPeaks = [];
        this.biaRecordObject.operatingHours = [];
        this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
          this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
          this.hideLoader();
          if (this.routedPageState === 1) {
            this.alertService.success("Successfully Created");
          }
          else {
            this.alertService.success("Successfully Updated")
          }
        }, err => {
          this.hideLoader();
          console.log(err);
        })
        break;
      case CategoryTypes.LOCATION:
        this.biaRecordObject.locationHeadCount = [];
        this.biaRecordObject.headCount = [];
        this.biaRecordObject.realEntity = [];
        this.biaRecordObject.businessPeaks = [];
        this.biaService.saveBiaRecord(this.biaRecordObject).subscribe((res) => {
          this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
          this.hideLoader();
          if (this.routedPageState === 1) {
            this.alertService.success("Successfully Created");
          }
          else {
            this.alertService.success("Successfully Updated")
          }
        }, err => {
          this.hideLoader();
          console.log(err);
        })
        break;
    }

  }

  filterSummaryEntries(record) {
    let actualEntries: any = [];
    let toPersistEntries: any = [];
    if (record.locationHeadCount && record.locationHeadCount.length > 0) {
      record.locationHeadCount.forEach(element => {
        if (element.employeeType && element.employees == null) {
          actualEntries.push(element);
        } else if (element.employeeType == null && element.employees) {
          //do nothing
        }
      });
    }

    if (this.recordlocationHeadCount) {
      if (actualEntries && actualEntries.length > 0) {
        actualEntries.forEach(element => {
          toPersistEntries.push(this.findInAlreadyPersisted(element));
        });
      }
    }
    return toPersistEntries;
  }

  findInAlreadyPersisted(entry): number {
    let id: any;
    for (let element of this.recordlocationHeadCount) {
      if (element.employeeType.id == entry.employeeType.id && element.location.id == entry.location.id) {
        id = element.id;
        entry.id = element.id;
        entry.version = element.version;
        break;
      }
    }
    return entry;
  }
}
