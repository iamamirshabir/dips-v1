import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class BusinessAreaService {


  constructor(private router: Router, private httpClient: HttpClient) { }

 
  saveBusinessArea(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_PRODUCT_SERVICE_SAVE}`, data);
  }

  getBusinessAreaLists(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_PRODUCT_SERVICE_LIST_BY_BIA_ID + id);
  }

  getcategoriesLists(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_PRODUCT_SERVICE_CATEGORY_BY_ORGANIZATION_ID + id);
  }

  getBusinessAreaByBiaId(biaId) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_GET_BUSINESS_AREA_BY_BIAID + '/' + biaId);
  }
  saveAllBusinessAreas(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_BUSINESS_AREA_SAVE_ALL}`, data);
  }
  deleteBusinessAreaRow(data){
    return this.httpClient.post(`${environment.baseUrl + Api.DELETE_BUSINESS_AREA_BY_ID}`,data)
  }
  saveBiaRecord(biaRecord): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
}


}