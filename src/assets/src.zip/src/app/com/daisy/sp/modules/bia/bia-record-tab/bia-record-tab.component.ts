import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SpChipFormFieldComponent } from '../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { BaseClass } from '../../../utils/baseclass';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { TimeScalesConstant } from '../../../utils/constants/timeScales-constant';
import { RouteParams } from '../../../utils/model.route-params';
import { BiaRecordComponent } from '../bia-record/bia-record.component';



@Component({
    selector: 'app-bia-record-tab',
    templateUrl: './bia-record-tab.component.html',
    styleUrls: ['./bia-record-tab.component.sass']
})
export class BiaRecordTabComponent extends BaseClass implements OnInit {
    biaRecordForm: FormGroup;
    activeLink: any;
    biaRecord: any;
    RTOArray: any = [];
    MTPDArray: any = [];
    dependencyList: any = [];
    routeParams: any;
    biaRecordId: any;
    title: any;
    biaRecordObject: any;
    @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
    timeScales: any;
    RTOdurationString: string;
    MTPDdurationString: string;
    minimisedWindow = false;
    rtoId: any;
    categoryNumber: number;
    biaRecordType: BiaRecordComponent;
    constructor(public formBuilder: FormBuilder) {
        super();
    }
    ngOnInit() {
        this.initializeData();


    }

    openFormByState(params) {
        this.dependencyList = [...params.nextRouterLink]
        this.routeParams = params;
        this.routedPageState = this.routeParams['pageState'];
        this.biaRecordId = this.routeParams.id;
        this.biaRecordObject = params.data;
        let category = this.routeParams.data.category;
        if (this.biaRecordObject) {
            this.patchFormValue();
            this.timePointType(this.biaRecordObject);
        }
        this.title = params.title;
        this.activeLink = params.routerLink;
    }

    initializeData() {
        this.biaRecordForm = this.formBuilder.group({
            id: [null],
            name: ['', Validators.required],
            description: ['', Validators.required],
            recoveryTimeObject: [null],
            mtpd: [null],
            lastUpdateDate: [null],
            lastReviewDate: [null],
            nextReviewDate: [null],
            reviewDate: [null],
            type: [1],
            generalComplete: [''],
            owner: [null, Validators.required],
            organisation: [this.organisation],
            realEntity: [null],
            category: [null],
            status: [''],
            version: [null],
            updatedBy: [null],
            updatedByName: [""]
        });
    }
    patchFormValue() {
        this.ownerContact.patchDataInControls(this.biaRecordObject['owner'])
        this.timePointType(this.biaRecordObject);
        if (this.biaRecordObject.updatedBy != null) {
            this.biaRecordObject.updatedByName = this.biaRecordObject.updatedBy.firstName + " " + this.biaRecordObject.updatedBy.lastName;
        } ``
        this.biaRecordForm.patchValue(this.biaRecordObject);
    }
    timePointType(obj) {
        if (obj.recoveryTimeObject != null) {
            this.RTOdurationString = this.timePointDurationbyMeasure(obj.recoveryTimeObject.measure, obj.recoveryTimeObject.duration);
            obj.recoveryTimeObject['durationString'] = this.RTOdurationString;
            this.RTOArray.push(obj.recoveryTimeObject);
        }
        if (obj.mtpd != null) {
            this.MTPDdurationString = this.timePointDurationbyMeasure(obj.mtpd.measure, obj.mtpd.duration);
            obj.mtpd['durationString'] = this.MTPDdurationString;
            this.MTPDArray.push(obj.mtpd);
        }
    }
    compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
    compareByValue(f1: any, f2: any) {
        return f1 && f2 && f1.name === f2.name;
    }

    biaDependencyClicked(dependecyType) {
        this.openForm(this.biaRecord, this.routedPageState, dependecyType);
    }
    minimiseWindow() {
        this.minimisedWindow = !this.minimisedWindow;
        if (this.minimisedWindow) {
            if (document.querySelector('.fx-height-general') as HTMLElement !== null) {
                (document.querySelector('.fx-height-general') as HTMLElement).style.height = 'calc(100% + 418px)';
            }
        }
        else {
            (document.querySelector('.fx-height-general') as HTMLElement).style.height = 'calc(100% + 215px)';
        }
    }
    openForm(biaRecord, routedPageState, dependencyType) {
        let routeParams: RouteParams = new RouteParams();
        routeParams = this.pageParams;
        routeParams.id = this.pageParams.data['id'];

        if (biaRecord) {
            routeParams.data = biaRecord;
        }
        routeParams.nextRouterLink = this.dependencyList;
        routeParams.routerLink = dependencyType.route;
        routeParams.title = dependencyType.key;

        this.routingService.openPage(routeParams.routerLink, routeParams);
    }
}
