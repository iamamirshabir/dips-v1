import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from '../../../../../../../app.material.module';
import { CategoryBusinessAreaComponent } from './category-business-area.component';
import { CategoryBusinessAreaFormComponent } from './category-business-area-form/category-business-area-form.component';
import { CategoryBusinessAreaListComponent } from './category-business-area-list/category-business-area-list.component';
const routes: Routes = [
  {
    path: '', component: CategoryBusinessAreaComponent,
    children: [
      { path: 'category-business-area-list', component: CategoryBusinessAreaListComponent },
      { path: 'category-business-area-form', component: CategoryBusinessAreaFormComponent }
    ]
  }
];

@NgModule({
  declarations: [CategoryBusinessAreaListComponent, CategoryBusinessAreaFormComponent, CategoryBusinessAreaComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [CategoryBusinessAreaFormComponent]
})
export class CategoryBusinessAreaModule { }
