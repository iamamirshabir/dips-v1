import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BaseClass } from '../../../utils/baseclass';
import { CategoryTypes } from '../../../utils/constants/category-types';
import {
  trigger,
  style,
  animate,
  transition,
  query,
  animateChild
} from '@angular/animations';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { BIAService } from '../bia.service';
import { RouteConstants } from '../../../utils/constants/route-constants';

declare var LeaderLine: any;

@Component({
  selector: 'app-dependency-map',
  templateUrl: './dependency-map.component.html',
  styleUrls: ['./dependency-map.component.sass'],
  animations: [
    trigger('ngIfAnimation', [
      transition(':enter, :leave', [
        query('@*', animateChild())
      ])
    ]),
    trigger('easeInOut', [
      transition('void => *', [
        style({
          opacity: 0
        }),
        animate("500ms ease-in", style({
          opacity: 1
        }))
      ]),
      transition('* => void', [
        style({
          opacity: 1
        }),
        animate("500ms ease-in", style({
          opacity: 0
        }))
      ])
    ])
  ]
})
export class DependencyMapComponent extends BaseClass implements OnInit {

  routeParams: any;
  categoryType: any;
  showRightChilds: boolean = false;
  showSubRightChilds: boolean = false;
  showLeftParents: boolean = false;
  showRightSubChild: boolean = true;
  isSingleClick: Boolean;
  dependencyMap: any;
  showRelevantDataForBusinessAreaChild: boolean = true;
  showRelevantDataForProductChild: boolean = true;
  showRelevantDataForSupplierChild: boolean = true;
  showRelevantDataForItChild: boolean = true;
  showRelevantDataForLocationChild: boolean = true;
  showRelevantDataForResourceChild: boolean = true;
  parentRecordShow: boolean = true;

  bia = { id: "", name: "", rto: "", art: "" }

  constructor(private changeDetect: ChangeDetectorRef, private biaService: BIAService) {
    super();
  }

  ngOnInit(): void {
    this.categoryType = CategoryTypes;
    this.showLoader();
  }

  openFormByState(routeParams) {
    this.showLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.bia.id = routeParams.data.id;
    this.bia.name = routeParams.data.name;
    this.bia.rto = routeParams.data.recoveryTimeObject;
    this.bia.art = routeParams.data.art;
    if (this.bia.id) {
      this.biaService.getDependencyMapbyBiaId(this.bia.id).subscribe((res) => {
        this.dependencyMap = res;
        if (this.bia.rto) { this.bia.rto = this.timePointDurationbyMeasure(this.bia.rto['measure'], this.bia.rto['duration']) }
        if (this.bia.art) { this.bia.art = this.timePointDurationbyMeasure(this.bia.art['measure'], this.bia.art['duration']) }
        this.childrenShow('from');
      }, err => {
        this.hideLoader();
        console.log(err);
      })
    }
  }
  childrenShow(id) {
    var parentId = id;
    if (!this.showLeftParents && !this.showRightChilds) {
      this.showLeftParents = true;
      this.showRightChilds = true;
      this.clickedChild(this.dependencyMap.reliedOn.businessArea)
      this.clickedChild(this.dependencyMap.reliedOn.itServices)
      this.clickedChild(this.dependencyMap.reliedOn.locations)
      this.clickedChild(this.dependencyMap.reliedOn.productsAndServices)
      this.clickedChild(this.dependencyMap.reliedOn.resources)
      this.clickedChild(this.dependencyMap.reliedOn.suppliers)
      this.showRelevantDataForBusinessAreaChild = true;
      this.showRelevantDataForProductChild = true;
      this.showRelevantDataForSupplierChild = true;
      this.showRelevantDataForItChild = true;
      this.showRelevantDataForLocationChild = true;
      this.showRelevantDataForResourceChild = true;
      this.dependencyMap.reliedBy.forEach(relied => {
        setTimeout(() => {
          let e1El = document.getElementById(parentId)
          let e2El = document.getElementById(relied.id)
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);
      });
      if (this.dependencyMap.reliedOn.businessArea && this.dependencyMap.reliedOn.businessArea.length) {
        setTimeout(() => {
          let e1El = document.getElementById(parentId);
          let e2El = document.getElementById('business' + this.dependencyMap.reliedOn.businessArea[0].id);
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);
      }
      if (this.dependencyMap.reliedOn.itServices && this.dependencyMap.reliedOn.itServices.length) {
        setTimeout(() => {
          let e1El = document.getElementById(parentId);
          let e2El = document.getElementById('itServices' + this.dependencyMap.reliedOn.itServices[0].id);
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);
      }
      if (this.dependencyMap.reliedOn.locations && this.dependencyMap.reliedOn.locations.length) {
        setTimeout(() => {
          let e1El = document.getElementById(parentId);
          let e2El = document.getElementById('locations' + this.dependencyMap.reliedOn.locations[0].id);
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);
      }
      if (this.dependencyMap.reliedOn.productsAndServices && this.dependencyMap.reliedOn.productsAndServices.length) {
        setTimeout(() => {
          let e1El = document.getElementById(parentId);
          let e2El = document.getElementById('productsAndServices' + this.dependencyMap.reliedOn.productsAndServices[0].id);
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);
      }
      if (this.dependencyMap.reliedOn.resources && this.dependencyMap.reliedOn.resources.length) {
        setTimeout(() => {
          let e1El = document.getElementById(parentId);
          let e2El = document.getElementById('resources' + this.dependencyMap.reliedOn.resources[0].id);
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);
      }
      if (this.dependencyMap.reliedOn.suppliers.length) {
        setTimeout(() => {
          let e1El = document.getElementById(parentId);
          let e2El = document.getElementById('suppliers' + this.dependencyMap.reliedOn.suppliers[0].id);
          var line = new LeaderLine(
            e1El,
            e2El,
            {
              color: 'black',
            }
          );
          line.size--;
          line.size--;
          line.size--;
        }, 100);

      }
      setTimeout(() => {
        let myElements = document.querySelectorAll(".leader-line");
        for (let i = 0; i < myElements.length; i++) {
          myElements[i]['style'].marginLeft = -150;
          myElements[i]['style'].marginTop = -100;
        }
      }, 150);
      setTimeout(() => {
        let myElements = document.querySelectorAll(".leader-line");
        for (let i = 0; i < myElements.length; i++) {
          document.querySelector('.fx-dependency').appendChild(myElements[i]);
        }
      }, 100);
      setTimeout(() => {
        var section = document.querySelector(".fx-dependency")
        section["style"].opacity = 1;
        this.hideLoader();

      }, 200);
    }
    else {
      this.showLeftParents = false;
      this.showRightChilds = false;
      this.showRelevantDataForBusinessAreaChild = false;
      this.showRelevantDataForProductChild = false;
      this.showRelevantDataForSupplierChild = false;
      this.showRelevantDataForItChild = false;
      this.showRelevantDataForLocationChild = false;
      this.showRelevantDataForResourceChild = false;
      let myElements = document.querySelectorAll(".leader-line");
      for (let i = 0; i < myElements.length; i++) {
        myElements[i]['style'].display = "none";
      }
    }
    this.showRightSubChild = !this.showRightSubChild;
  }

  clickedChild(biaClicked) {
    this.isSingleClick = true;
    if (this.isSingleClick) {
      if (biaClicked && biaClicked.length && biaClicked[0].businessArea && biaClicked[0].businessArea.category.type === this.categoryType.BUSINESS_AREA) {
        biaClicked.forEach(child => {
          if (child != undefined) {
            setTimeout(() => {
              let e1El = document.getElementById('business' + biaClicked[0].id)
              let e2El = document.getElementById('businessChild' + child.id);
              var line = new LeaderLine(
                e1El,
                e2El,
                {
                  color: 'black'
                }
              );
              line.size--;
              line.size--;
              line.size--;
            }, 100);
          }
        });
      }
      if (biaClicked && biaClicked.length && biaClicked[0].productService && biaClicked[0].productService.category.type === this.categoryType.PRODUCT) {
        biaClicked.forEach(child => {
          if (child != undefined) {
            setTimeout(() => {
              let e1El = document.getElementById('productsAndServices' + biaClicked[0].id)
              let e2El = document.getElementById('productsAndServicesChild' + child.id);
              var line = new LeaderLine(
                e1El,
                e2El,
                {
                  color: 'black'
                }
              );
              line.size--;
              line.size--;
              line.size--;
            }, 100);
          }

        });
      }
      if (biaClicked && biaClicked.length && biaClicked[0].supplierCategory && biaClicked[0].supplierCategory.category.type === this.categoryType.SUPPLIER) {
        biaClicked.forEach(child => {
          if (child != undefined) {
            setTimeout(() => {
              let e1El = document.getElementById('suppliers' + biaClicked[0].id)
              let e2El = document.getElementById('suppliersChild' + child.id);
              var line = new LeaderLine(
                e1El,
                e2El,
                {
                  color: 'black'
                }
              );
              line.size--;
              line.size--;
              line.size--;
            }, 100);
          }

        });
      }
      if (biaClicked && biaClicked.length && biaClicked[0].resource && biaClicked[0].resource.category.type === this.categoryType.RESOURCE) {
        biaClicked.forEach(child => {
          if (child != undefined) {
            setTimeout(() => {
              let e1El = document.getElementById('resources' + biaClicked[0].id)
              let e2El = document.getElementById('resourcesChild' + child.id);
              var line = new LeaderLine(
                e1El,
                e2El,
                {
                  color: 'black'
                }
              );
              line.size--;
              line.size--;
              line.size--;
            }, 100);
          }

        });
      }
      if (biaClicked && biaClicked.length && biaClicked[0].itService && biaClicked[0].itService.category.type === this.categoryType.IT) {
        biaClicked.forEach(child => {
          if (child != undefined) {
            setTimeout(() => {
              let e1El = document.getElementById('itServices' + biaClicked[0].id)
              let e2El = document.getElementById('itServicesChild' + child.id);
              var line = new LeaderLine(
                e1El,
                e2El,
                {
                  color: 'black'
                }
              );
              line.size--;
              line.size--;
              line.size--;
            }, 100);
          }

        });
      }
      if (biaClicked && biaClicked.length && biaClicked[0].location && biaClicked[0].location.category.type === this.categoryType.LOCATION) {
        biaClicked.forEach(child => {
          if (child != undefined) {
            setTimeout(() => {
              let e1El = document.getElementById('locations' + biaClicked[0].id)
              let e2El = document.getElementById('locationsChild' + child.id);
              var line = new LeaderLine(
                e1El,
                e2El,
                {
                  color: 'black'
                }
              );
              line.size--;
              line.size--;
              line.size--;
            }, 100);
          }

        });
      }
      this.clickSubChilds(biaClicked);
      this.hideLoader();
    }
  }
  clickSubChilds(biaClicked) {
    if (biaClicked && biaClicked.length && biaClicked[0].businessArea && biaClicked[0].businessArea.category.type === this.categoryType.BUSINESS_AREA) {
      biaClicked.forEach(child => {
        if (child != undefined) {
          setTimeout(() => {
            let businessChild = document.getElementById('businessChild' + child.id);
            let businessSubChild = document.getElementById('businessSubChild' + child.id);
            var line = new LeaderLine(
              businessChild,
              businessSubChild,
              {
                color: 'black'
              }
            );
            line.size--;
            line.size--;
            line.size--;
          }, 100);
        }
      });
    }
    if (biaClicked && biaClicked.length && biaClicked[0].productService && biaClicked[0].productService.category.type === this.categoryType.PRODUCT) {
      biaClicked.forEach(child => {
        if (child != undefined) {
          setTimeout(() => {
            let productChild = document.getElementById('productsAndServicesChild' + child.id);
            let productSubChild = document.getElementById('productsAndServicesSubChild' + child.id);
            var line = new LeaderLine(
              productChild,
              productSubChild,
              {
                color: 'black'
              }
            );
            line.size--;
            line.size--;
            line.size--;
          }, 100);
        }

      });
    }
    if (biaClicked && biaClicked.length && biaClicked[0].supplierCategory && biaClicked[0].supplierCategory.category.type === this.categoryType.SUPPLIER) {
      biaClicked.forEach(child => {
        if (child != undefined) {
          setTimeout(() => {
            let supplierChild = document.getElementById('suppliersChild' + child.id);
            let supplierSubChild = document.getElementById('suppliersSubChild' + child.id);
            var line = new LeaderLine(
              supplierChild,
              supplierSubChild,
              {
                color: 'black'
              }
            );
            line.size--;
            line.size--;
            line.size--;
          }, 100);
        }

      });
    }
    if (biaClicked && biaClicked.length && biaClicked[0].resource && biaClicked[0].resource.category.type === this.categoryType.RESOURCE) {
      biaClicked.forEach(child => {
        if (child != undefined) {
          setTimeout(() => {
            let resourceChild = document.getElementById('resourcesChild' + child.id);
            let resourceSubChild = document.getElementById('resourcesSubChild' + child.id);
            var line = new LeaderLine(
              resourceChild,
              resourceSubChild,
              {
                color: 'black'
              }
            );
            line.size--;
            line.size--;
            line.size--;
          }, 100);
        }

      });
    }
    if (biaClicked && biaClicked.length && biaClicked[0].itService && biaClicked[0].itService.category.type === this.categoryType.IT) {
      biaClicked.forEach(child => {
        if (child != undefined) {
          setTimeout(() => {
            let itServiceChild = document.getElementById('itServicesChild' + child.id);
            let itServiceSubChild = document.getElementById('itServiceSubChild' + child.id);
            var line = new LeaderLine(
              itServiceChild,
              itServiceSubChild,
              {
                color: 'black'
              }
            );
            line.size--;
            line.size--;
            line.size--;
          }, 100);
        }

      });
    }
    if (biaClicked && biaClicked.length && biaClicked[0].location && biaClicked[0].location.category.type === this.categoryType.LOCATION) {
      biaClicked.forEach(child => {
        if (child != undefined) {
          setTimeout(() => {
            let locationChild = document.getElementById('locationsChild' + child.id);
            let locationSubChild = document.getElementById('locationSubChild' + child.id);
            var line = new LeaderLine(
              locationChild,
              locationSubChild,
              {
                color: 'black'
              }
            );
            line.size--;
            line.size--;
            line.size--;
          }, 100);
        }

      });
    }
  }
  setParent(ev) {
    this.isSingleClick = false;
    this.changeStates(ev);
  }
  changeStates(ev) {
    this.showLoader();
    this.hideLoader();
  }
  goBackToMainPage(btnAction: ButtonActions) {
    if (btnAction === ButtonActions.CANCEL) {
      let myElements = document.querySelectorAll(".leader-line");
      for (let i = 0; i < myElements.length; i++) {
        myElements[i]['style'].display = "none";
      }
      this.parentRecordShow = false;
      this.showRightChilds = false;
      this.showLeftParents = false;
      this.showRelevantDataForBusinessAreaChild = false;
      this.showRelevantDataForProductChild = false;
      this.showRelevantDataForSupplierChild = false;
      this.showRelevantDataForItChild = false;
      this.showRelevantDataForLocationChild = false;
      this.showRelevantDataForResourceChild = false;
      this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
    }
  }
}
