import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { FileHandle } from 'src/app/com/daisy/sp/common/directives/drag-drop.directive';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';

@Component({
  selector: 'app-category-supplier-form',
  templateUrl: './category-supplier-form.component.html',
  styleUrls: ['./category-supplier-form.component.sass']
})
export class CategorySupplierFormComponent extends BaseClass implements OnInit {
  categorySupplierForm: FormGroup;
  submitted = false;
  ButtonActions = ButtonActions;
  routeParams: any;
  subCategories: any;
  categorySupplier: any;
  realEntities: any;
  selectedART: any;
  @ViewChild('itServiceCat') itServiceCat: SpChipFormFieldComponent;
  @ViewChild('managerContact') managerContact: SpChipFormFieldComponent;
  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  // @ViewChild('realEntity') realEntity: SpChipFormFieldComponent;
  @ViewChild('additionalContact') additionalContact: SpChipFormFieldComponent;
  @ViewChild('perspectiveDepartmental') perspectiveDepartmental: SpChipFormFieldComponent;
  @ViewChild('perspectiveLocational') perspectiveLocational: SpChipFormFieldComponent;

  @ViewChild('fileInput') fileInput;
  categoryObject: any;
  addState: boolean = true;
  cat_Supplier_Id: any;
  categorySupplierObj: any;
  // categorySupplierRealEntityObj: any;
  categorySupplierOwnerObj: any;
  categorySupplierAccountManagerObj: any;
  categorySupplieradditionalContact: any;
  public RTOdurationString: any = [];
  public ARTdurationString: any = [];
  public RTOArray: any = [];
  public ARTArray: any = [];
  timeScales: any = [];
  flagUploaded: boolean = true;
  fileType;
  uploadedUrl = [];
  uploadedData; uploadRawData: any
  uploadBinaryData;
  documentModel = {};
  uploadFile = [];
  bcstatusList: string[] = ['Approved', 'At Risk', 'Under Review'];
  perspectiveLocationalObj: any;
  perspectiveDepartmentalObj: any;
  cat_Supplier_type: any;
  cat_Supplier_data: any;
  artTimeScale: any;
  rtoTimeScale: any;
  categoryTypeName:any;
  hierarchy:any;
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.categorySupplierForm.controls; }
  ngOnInit(): void {

    this.categorySupplierForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: ['', [Validators.required]],
      description: [''],
      category: [null],
      categoryName: [null],
      // realEntity: [null],
      rto: [null],
      accountManager: [null],
      operatingHours: [null],
      art: [null],
      bcpLastTest: [null],
      owner: [null],
      sla: [null],
      address: [''],
      version: [null],
      primaryContactName: [null],
      primaryContactWorkNumber: ['', [Validators.pattern("^[+-]?[0-9]*$")]],
      primaryContactWorkMobile: ['', [Validators.pattern("^[+-]?[0-9]*$")]],
      primaryContactEmail: ['', [Validators.email]],
      primaryContactJobTitle: [null],
      itServices: [null],
      productServices: [null],
      bcStatus: [null],
      additionalContact: [[]],
      additionalJobTitle: [null],
      additionalWorkContactNumber: [null],
      additionalWorkMobileNumber: [null],
      additionalWorkEmailAddress: [null],
      perspectiveDepartmental: [null],
      perspectiveLocational: [null],
      document: [null]
    });
    this.loadingService.enableLoading();
    this.getRealEntity();
  }
  openFormByState(routeParams) {
    console.log("reciever");
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_Supplier_Id = this.routeParams['id'];
    this.cat_Supplier_data = this.routeParams['data'];
    if (this.cat_Supplier_Id) {
      this.getCategorySupplierById(this.cat_Supplier_Id);
    }
    if (this.cat_Supplier_data) {
      this.cat_Supplier_type = this.cat_Supplier_data['type'];
      this.artTimeScale = this.cat_Supplier_data['artTimeScale'];
      this.rtoTimeScale = this.cat_Supplier_data['rtoTimeScale'];
      if (this.artTimeScale != null) {
        this.ARTArray = this.setTimeScalesList(this.artTimeScale.id, TimeScalesConstant.ART_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => {
            if (data.type == TimeScalesConstant.ART_TYPE)
              this.ARTArray = data.list;
          });
      }
      if (this.rtoTimeScale != null) {
        this.RTOArray = this.setTimeScalesList(this.rtoTimeScale.id, TimeScalesConstant.RTO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => {
            if (data.type == TimeScalesConstant.RTO_TYPE)
              this.RTOArray = data.list;
          });
      }
      this.getCategoryByOrgId();
      this.hierarchy = this.cat_Supplier_data.hierarchy;
      this.categorySupplierForm.controls['category'].setValue(this.cat_Supplier_data);
      
    }
  }
  getCategorySupplierById(id) {
    this.showLoader();
    this.categorySupplierService.getCategorySupplierById(id).subscribe(data => {
      this.hideLoader();
      this.categoryObject = data;
      this.patchFormData();
    }, error => {
      this.hideLoader();
    })

  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.duration === f2.duration;
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.addState = true;
      this.ownerContact.patchDataInControls(this.categorySupplierForm.controls['owner']);
      this.managerContact.patchDataInControls(this.categorySupplierForm.controls['accountManager']);
      this.itServiceCat.patchDataInControls(this.categorySupplierForm.controls['itServices']);
      // this.realEntity.patchDataInControls(this.categorySupplierForm.controls['realEntity']);
      this.additionalContact.patchDataInControls(this.categorySupplierForm.controls['additionalContact']);
      this.perspectiveLocational.patchDataInControls(this.categorySupplierForm.controls['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categorySupplierForm.controls['perspectiveDepartmental']);

    } else {
      this.addState = false;
      this.ownerContact.patchDataInControls(this.categoryObject['owner']);
      this.managerContact.patchDataInControls(this.categoryObject['accountManager']);
      // this.realEntity.patchDataInControls(this.categoryObject['realEntity']);
      this.itServiceCat.patchDataInControls(this.categoryObject['itServices']);
      this.perspectiveLocational.patchDataInControls(this.categoryObject['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryObject['perspectiveDepartmental']);
      this.additionalContact.patchDataInControls(this.categoryObject['additionalContact']);
      this.bindJsonObjectToFormObject(this.categoryObject, this.categorySupplierForm);
      this.patchDocuments(this.categoryObject);
      this.categorySupplierForm.patchValue({categoryName: this.categoryTypeName}); 
    }
  }
  
 patchDocuments(obj) {
   if(obj.document) {
    obj.document.forEach(element => {
    this.uploadedUrl.push(element)
    this.uploadBinaryData = this.fileSringToBinary(element.document);
    this.documentModel = {
      name: element.name,
      document: this.uploadBinaryData,
      path: ""
    };
    this.uploadFile.push(this.documentModel);
  });
 }
}

  getCategoryByOrgId() {
    this.showLoader();
    this.categorySupplierService.getSubCategories(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.subCategories = data;      
      let SubCatObj = this.subCategories.find(item => (item.type == this.cat_Supplier_type));      
    if(this.hierarchy) {
      this.categorySupplierForm.patchValue({ categoryName: this.hierarchy});
    } else if (SubCatObj != undefined) {
         this.categoryTypeName=SubCatObj.name;
         this.categorySupplierForm.patchValue({ categoryName: SubCatObj.name });
    }
      
    }, error => {
      this.hideLoader();
    })
  }

  getRealEntity() {
    this.showLoader();
    this.categoryItService.getRealEntityByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.realEntities = data;
    }, error => {
      this.hideLoader();
    })
  }


  filesDropped(files: FileHandle[]): void {
    this.flagUploaded = false;
    files.forEach((file => {
      if (file) {
        var reader = new FileReader();
        this.fileType = file.file.type;
        reader.readAsDataURL(file.file);
        reader.onload = (event: any) => {
          this.uploadedData = file;
          this.uploadRawData = event.target.result;
          this.uploadedUrl.push(this.uploadedData);
          let filestring = btoa(this.uploadRawData);
          this.uploadBinaryData = this.fileSringToBinary(filestring);
          this.documentModel = {
            name: file.file.name,
            document: this.uploadBinaryData,
            path: ""
          };
          this.uploadFile.push(this.documentModel);
        };
      }
    }));
  }

  fileSringToBinary(strData: string): any {
    const byteCharacters = atob(strData);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    return byteNumbers;
  }

  onClickFileInputButton(): void {
    this.fileInput.nativeElement.click();
  }


  browseFile(event: { target: { files: any[]; }; }) {
    this.flagUploaded = false;
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      let file = event.target.files[0];
      this.fileType = file.type;
      reader.readAsDataURL(file);
      reader.onload = (event: any) => {
        this.uploadedData = file;
        this.uploadRawData = event.target.result;
        this.uploadedUrl.push(this.uploadedData);

        let filestring = btoa(this.uploadRawData);
        this.uploadBinaryData = this.fileSringToBinary(filestring);
        this.documentModel = {
          name: file.name,
          document: this.uploadBinaryData,
          path: ""
        };
        this.uploadFile.push(this.documentModel);
      };
    }
  }

  deleteImage(file) {
    this.uploadedUrl.forEach((item, index) => {
      if (item === file) {
        this.uploadedUrl.splice(index, 1);
        this.uploadFile.splice(index, 1);
      }
    });

  }

  downloadFile(file) {
    if (file.document) {
      var fileDownlaoded = atob(file.document);
      var link = document.createElement("a");
      link.download = file.name;
      link.href = fileDownlaoded;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    else {
      var reader = new FileReader();
      var result;
      reader.readAsDataURL(file);
      reader.onload = (event: any) => {
        result = event.target.result;
        var link = document.createElement("a");
        link.download = file.name;
        link.href = result;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      };
    }

  }

  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.categorySupplierForm.invalid) {
      return;
    }
    this.categorySupplierForm.controls['document'].setValue(this.uploadFile);
    this.categorySupplierForm.controls['organisation'].setValue(this.organisation);
    this.showLoader();
    this.categorySupplierOwnerObj = Array.isArray(this.categorySupplierForm.value.owner) ? this.categorySupplierForm.value.owner[0] : this.categorySupplierForm.value.internalOwner;
    this.categorySupplierAccountManagerObj = Array.isArray(this.categorySupplierForm.value.accountManager) ? this.categorySupplierForm.value.accountManager[0] : this.categorySupplierForm.value.accountManager;
    this.perspectiveLocationalObj = this.categorySupplierForm.value.perspectiveLocational;
    this.perspectiveDepartmentalObj = this.categorySupplierForm.value.perspectiveDepartmental;

    this.categorySupplierForm.controls['owner'].setValue(this.categorySupplierOwnerObj);
    this.categorySupplierForm.controls['accountManager'].setValue(this.categorySupplierAccountManagerObj);
    this.categorySupplierForm.controls['perspectiveLocational'].setValue(this.perspectiveLocationalObj);
    this.categorySupplierForm.controls['perspectiveDepartmental'].setValue(this.perspectiveDepartmentalObj);

    this.categorySupplierService.saveCategorySupplier(this.categorySupplierForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        }
        // else if (btnType == ButtonActions.SAVE_AND_CONT) {
        //   this.contactObject = res;
        //   this.routedPageState = PageState.EDIT_STATE;
        //   this.patchFormData();
        // }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CATEGORY_supplier_LIST);
  }

}
