import { ChangePasswordComponent } from './change-password/change-password.component';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PasswordService {

  constructor(private httpClient: HttpClient) { }

  savePasswordPolicies(passwordPolicy) {
    return this.httpClient.post(`${environment.baseUrl + Api.PASSWORD_SAVE_PASSWORD_POLICIES}`, passwordPolicy);
  }

  getPasswordPolicies() {
    return this.httpClient.get(`${environment.baseUrl + Api.PASSWORD_FIND_ALL_PASSWORD_POLICIES}`);
  }

  getPasswordPolicyByOrganisationId(organisationId): Observable<any>{
    return this.httpClient.get(`${environment.baseUrl + Api.PASSWORD_PASSWORD_POLICY_BY_ORGANISATION_ID}/`+organisationId);
  }

  updatePassword(changePassword) {
    return this.httpClient.post(`${environment.baseUrl + Api.PASSWORD_UPDATE_PASSWORD}`, changePassword);
  }

}
