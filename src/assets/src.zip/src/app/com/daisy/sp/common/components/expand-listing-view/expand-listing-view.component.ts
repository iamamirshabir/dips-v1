import { Component, AfterViewInit, ViewChild, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { Subscription } from 'rxjs';

import { MatPaginator } from '@angular/material/paginator';
import { SelectionModel } from '@angular/cdk/collections';
import { BtnEvent } from '../../../utils/mode.btnEvent';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { ChevronMenusComponent } from '../chevron-menus/chevron-menus.component';
import { ChevronMenuBase } from '../chevron-menus/chevron-menu-base';
import { ChevronMenuService } from '../chevron-menus/chevron-menu-service';
import { LoaderService } from 'src/app/core-services/loader.service';
import { CdkDragDrop, CdkDragStart, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ExpandListingView } from './expand-listing-view.interface';
import { ExpandListingViewService } from './expand-listing-view.service';
import { MatTableExporterDirective } from 'mat-table-exporter';
import jsPDF from 'jspdf';


@Component({
  selector: 'app-expand',
  templateUrl: './expand-listing-view.component.html',
  styleUrls: ['./expand-listing-view.component.sass'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ExpandListingViewComponent implements  AfterViewInit, OnDestroy {
  listingSubscriptionForExpand: Subscription;
  iListingView: ExpandListingView;
  displayedColumns: any = [];
  listColumns: any = [];
  columns: any = [];
  expandColumns: any = [];
  columnsList: any = [];
  listTitle: any;
  dataSource: MatTableDataSource<any>;
  tableData: any = [];
  selectedAll: any;
  listActionsId: any;
  tableButtons: any;
  selection = new SelectionModel<any>(true, []);
  pageSize = 25;
  ButtonTypes = ButtonActions;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Output() btnClicked = new EventEmitter<any>();
  @Output() btnDoubleClicked = new EventEmitter<any>();
  @Output() chevronMenuEvent = new EventEmitter<any>();
  @Output() showAreaOfScope = new EventEmitter<any>();
  @ViewChild('chevronMenu') chevronMenu: ChevronMenusComponent;
  @ViewChild(MatTableExporterDirective) matTableExporter: MatTableExporterDirective;

  expandable: boolean = false;

  filterSelectObj = [];
  filterValues = {};
  toggleFilterBar: boolean = false;
  showFilters: boolean = true;
  isShowAreaOfScope: boolean = false;
  showExercisingFilter: boolean = true;
  exercisingList: boolean = false;
  chevronMenuClass: any;
  columnsName;
  menuToDisplay = [];
  selectedRowIndex = -1;
  @Input() checked: boolean
  columnsListsArray: any = [];
  printDocument: any;
  previousIndex: number;
  previousIndexChecked: number;
  expandableColumns: any = [];
  expandedElement: any;
  showExpandedRow: boolean = false;
  constructor(private expandlistingViewService: ExpandListingViewService, private chevronMenuService: ChevronMenuService,
    private loaderService: LoaderService) {
      this.listingSubscriptionForExpand = this.expandlistingViewService.onExpandedListingView().subscribe(iListingView => {
      this.iListingView = iListingView;
      this.tableButtons = iListingView.tableButtons;
      this.showFilters = iListingView.showFilters;
      this.filterSelectObj = iListingView.filterSelectObj;
      this.expandable = iListingView.expandable;
      this.isShowAreaOfScope = iListingView.listObject['isShowAreaOfScope'];

      this.populateTableData();
    });
  }

  ngAfterViewInit() { }
  ngOnDestroy() {
    this.listingSubscriptionForExpand.unsubscribe();
  }

  populateTableData() {
    this.selection = new SelectionModel<any>(true, []);
    this.listTitle = this.iListingView.listTitle;
    this.columns = this.iListingView.displayedColumns;
    this.expandColumns = this.iListingView.expandableColumns;

    this.displayedColumns = this.columns.map(c => c.key);
    this.expandableColumns = this.expandColumns.map(c => c.key);
    this.dataSource = new MatTableDataSource(this.iListingView.dataSource);


    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    if (this.showFilters) {
      this.filterColumn();
    }
    this.loaderService.clearLoading();
    this.columnsListsArray = this.displayedColumns;
    this.displayedColumns = [];
    this.columns.forEach(checkedColumn => {
  
      if (checkedColumn.checked) {
        this.displayedColumns.push(checkedColumn.key)
      }
    });
    this.previousIndexChecked = this.displayedColumns.length - 1;
  }
 
  filterColumn() {
    this.dataSource.filterPredicate = this.createFilter();
    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(this.iListingView.dataSource, o.columnProp);
    });
  }
  onOpenMenu(menu: any): void {
    let menusList = this.chevronMenuService.getChevronMenuClass(this.iListingView.chevronMenuClassName, menu, this.iListingView.dataSource);
    this.chevronMenu.data = menu;
    this.chevronMenu.setMenu(menusList);
  }
  applyFilter(event: Event) {
    if (this.showFilters) {
      this.filterValues = {};
      this.filterSelectObj.forEach(element => {
        this.filterValues[element.columnProp] = (event.target as HTMLInputElement).value;
      });
      this.dataSource.filter = JSON.stringify(this.filterValues)
    } else {
      const filterValue = (event.target as HTMLInputElement).value;
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }
  }

  columnClick(colNameString: string = null, colName: string) {
    const colIndex = this.displayedColumns.findIndex(col => col === colName);
    const arrayOfObject = this.filterSelectObj;
    const checkUsername = obj => obj.columnProp === colName;
    var checkElementToFilter = arrayOfObject.some(checkUsername);
    const colIndexFilter = this.filterSelectObj.findIndex(col => col.columnProp === colName);
    if (colIndex > 0) {
      this.previousIndexChecked = colIndex;
      this.displayedColumns.splice(colIndex, 1);
      if (colIndexFilter > 0 && checkElementToFilter) {
        this.filterSelectObj.splice(colIndexFilter, 1);
      }
    }
    else {
      this.columnsListsArray.forEach(element => {
        if (element === colName) {
          const insert = (arr, colIndex, column) => [
            ...arr.slice(0, colIndex),
            column,
            ...arr.slice(colIndex)
          ]
          this.displayedColumns = insert(this.displayedColumns, this.previousIndexChecked, colName);
          if (!checkElementToFilter) {
            var obj = { name: colNameString, columnProp: colName, options: [] }
            this.filterSelectObj.push(obj);
            this.filterColumn();
          }
        }
      });
    }
  }
  highlight(row) {
    this.selectedRowIndex = row.id;
  }
  commonButtonClick(btnType: string) {
    let btnEvent: BtnEvent = new BtnEvent();
    btnEvent.data = this.selection.selected;
    if (btnEvent.data) {
      btnEvent.data = btnEvent.data.filter(item => item != undefined)
    }
    btnEvent.btnAction = btnType;
    this.btnClicked.emit(btnEvent)
  }
  rowDoubleClick(row) {
    this.btnDoubleClicked.emit(row)
  }
  chevronMenuClick(chevronMenuEvent: any) {
    this.chevronMenuEvent.emit(chevronMenuEvent);
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const page = this.dataSource.data.length;
    return numSelected === page;
  }
  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      this.dataSource.data.forEach(row => this.selection.select(row))
    }
  }
  selectRows() {
    for (let index = 0; index < this.dataSource.paginator.pageSize; index++) {
      this.selection.select(this.dataSource.data[index]);
    }
  }
  checkboxLabel(row: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.id + 1}`;
  }

  getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }

  filterChange(filter, event) {
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues)
  }

  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }
      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            if (searchTerms[col]) {
              searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
                if (data[col] && data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                  found = true
                }
              });
            }
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }

  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }
  showAreaOfScopeClick(isShow) {
    this.showAreaOfScope.emit(isShow);
    this.showExercisingFilter = !this.showExercisingFilter;
  }
  mapOrder(array, order, key) {
    array.sort(function (a, b) {
      var A = a[key], B = b[key];
      if (order.indexOf(A) > order.indexOf(B)) {
        return 1;
      } else {
        return -1;
      }
    });
    return array;
  };
  columnDrop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex);
    this.filterSelectObj = this.mapOrder(this.filterSelectObj, this.displayedColumns, 'columnProp');
    this.filterColumn();
  }
  expand(value) {
    if (value == undefined) {
      this.showExpandedRow = false;
    }
    else {
      this.showExpandedRow = true;
    }

  }
  printCSV() {
    this.matTableExporter.exportTable('csv')
  }
  printEXCEL() {
    this.matTableExporter.exportTable('xls')
  }
  printPDF() {
    this.printDocument = new jsPDF();
    let columnData = [];
    let dataPdfFile = [];
    var displayedColumnCopy = [];
    var headNameArray = [];

    displayedColumnCopy = [...this.displayedColumns];

    displayedColumnCopy.shift();
    displayedColumnCopy.pop();

    displayedColumnCopy.forEach(key => {
      this.columns.forEach(colKey => {
        if (key === colKey.key) {
          dataPdfFile.push(colKey)
          headNameArray.push(colKey.name)
        }
      });
    });
    this.dataSource.filteredData.forEach(obj => {
      let arr = [];
      dataPdfFile.forEach(col => {
        arr.push(obj[col.key]);
      });
      columnData.push(arr);
    });
    this.printDocument.autoTable({
      headStyles: { fillColor: [0, 0, 0, 0.54] },
      head: [headNameArray],
      body: columnData,
    });
    this.printDocument.save('Shadow Planner Document');
  }
}
