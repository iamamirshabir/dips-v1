import { NgModule } from '@angular/core';
import { Router, RouterModule, Routes } from '@angular/router';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { ComponentsModule } from '../../../../common/components/components.module';
import { ItServiceTypeListComponent } from './it-service-type-list.component';
import { ItServiceTypeComponent } from './it-service-type-form/it-service-type.component';

const routes:Routes = [{
  path:'' , component: ItServiceTypeListComponent, 
  children:[]
}]

@NgModule({
  declarations: [ItServiceTypeListComponent, ItServiceTypeListComponent, ItServiceTypeComponent],
  imports: [
    ComponentsModule, 
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ],
  entryComponents:[ItServiceTypeListComponent]
})
export class ItServiceTypeModule { }
