import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-impact-assessment-summaryReason',
  templateUrl: './impact-assessment-summaryReason.component.html',
  styleUrls: ['./impact-assessment-summaryReason.component.sass']
})
export class ImpactAssessmentSummaryReasonComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  subscription: any;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ImpactAssessmentSummaryReasonComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
    console.log("modelData", this.modalData);
  }
  get f() { return this.modalFormFroup.controls; }

  public ngOnInit(): void {
    this.hideLoader();
    this.modalFormFroup = this.fb.group({
      id: [null],
      order: [null],
      organisation: [null],
      version: [null],
      summaryReason: [null],
    });
    if (this.modalData) {
      if(this.modalData.impactAssessment != null){
        this.modalFormFroup.patchValue(this.modalData.impactAssessment);
      }
    }
  }
 
  saveFormData(): void {  
    if (this.modalFormFroup.invalid) {
      return;
    } 

    this.modalData = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }
 

}