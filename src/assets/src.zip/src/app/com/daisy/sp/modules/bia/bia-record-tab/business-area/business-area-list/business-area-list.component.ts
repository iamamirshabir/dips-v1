import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Component, ViewChild } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatSort } from '@angular/material/sort';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { CategoryTypes } from '../../../../../utils/constants/category-types'
import { MatTable } from '@angular/material/table';
import { GlobalConstants } from '../../../../../utils/global-constants';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';


@Component({
  selector: 'app-business-area-list',
  templateUrl: './business-area-list.component.html',
  styleUrls: ['./business-area-list.component.sass']
})

export class BusinessAreaListComponent extends BaseClass {

  displayColumns = ['name', 'descriptionOfReliance', 'rto', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  routeParams: any;
  businessArea: FormArray = this.fb.array([]);
  businessAreaForm: FormGroup = this.fb.group({ 'businessArea': this.businessArea });
  @ViewChild(MatSort) sort: MatSort;
  biaRecordId: any;
  biaType: any;
  categoryRecord: any;
  biaRecord: any;
  RtoObject: any;
  rtoList: any = [];
  memberDropped: any;
  globals: GlobalConstants;

  @ViewChild('businessAreaField') businessAreaField: SpChipFormFieldComponent;
  @ViewChild(MatTable) table: MatTable<any>;
  rtoId: any;

  constructor(private fb: FormBuilder, globals: GlobalConstants) {
    super();
    this.globals = globals;
  }

  ngOnInit(): void { }

  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.biaType = this.routeParams.parentParams;
    this.biaRecord = this.routeParams.data;
    let categoryRecord = this.biaRecord['categoryRecord'];
    if (categoryRecord['category']) {
      let categoryData = categoryRecord['category'];
      if (categoryData['rtoTimeScale']) {
        let rtoTimeScale = categoryData['rtoTimeScale'];
        this.rtoId = rtoTimeScale['id'];
        this.rtoList = this.setTimeScalesList(this.rtoId, TimeScalesConstant.RTO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => {
            if (data.type == TimeScalesConstant.RTO_TYPE)
              this.rtoList = data.list;
          });
      }
    }

    this.businessAreaService.getBusinessAreaByBiaId(this.biaRecordId).subscribe((res) => {
      if (res.length >= 1) {
        this.patchBusinessAreaValues(res);
      }
      else {
        this.addRow();
      }
    }, err => {
      console.log(err);
    })
  }
  patchBusinessAreaValues(res) {
    var businessAreaValues = res;

    businessAreaValues.forEach(businessAreaRows => {
      this.addRow();
      this.businessArea.patchValue(res);
      this.updateView();
    });

  }



  emptyTable() {
    while (this.businessArea.length !== 0) {
      this.businessArea.removeAt(0);
    }
  }
  compareObjects(o1: any, o2: any): boolean {
    if (o1.name && o1.id != null && o2.name && o2.id != null) {
      return o1.name === o2.name && o1.id === o2.id;
    }
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.id === f2.id;
  }

  hasChange: boolean = false;

  addRow(noUpdate?: boolean, droppedElement = null, objectToReplace = null) {
    this.globals.DROPPED_ID_ARRAY = [];
    if (objectToReplace != null && objectToReplace.key === 2) {
      var row = this.fb.group({
        id: [null],
        businessArea: [objectToReplace.memberDropped, Validators.required],
        description: ['', Validators.required],
        rto: [null, Validators.required],
        version: [null]
      });
      this.businessArea.insert(objectToReplace.index, row);
    }
    else {
      if (this.businessArea.controls[this.businessArea.controls.length - 1] != undefined) {
        if (this.businessArea.controls[this.businessArea.controls.length - 1]['controls'].businessArea.invalid) {
          this.businessArea.controls[this.businessArea.controls.length - 1]['controls'].businessArea.markAsTouched();
          return
        }
      }
      var row = this.fb.group({
        id: [null],
        businessArea: [null, Validators.required],
        description: ['', Validators.required],
        rto: [null, Validators.required],
        version: [null]
      });
      this.businessArea.push(row);
    }
    if (!noUpdate) { this.updateView(); }
    if (droppedElement != null) {
      row.controls.businessArea.patchValue(droppedElement);
    }
    for (var i = 0; i < this.businessArea.controls.length; i++) {
      this.globals.DROPPED_ID_ARRAY.push('list-' + i)
    }

  }

  updateView() {
    this.dataSource.next(this.businessArea.controls);
  }
  dropFromSearch(event: CdkDragDrop<string[]>, businessAreaRow) {
    this.memberDropped = event.previousContainer.data;

    if (this.memberDropped[0].category.type != CategoryTypes.BUSINESS_AREA) {
      return
    }

    if (businessAreaRow.value.businessArea === null) {
      if (this.memberDropped.length === 1 && this.businessArea.value[0].businessArea === null) {
        this.businessArea.controls[0]['controls'].businessArea.patchValue(this.memberDropped[0]);
        this.businessAreaField.patchDataInControls(this.businessArea.controls[0]['controls'].businessArea.value);
      }
      else if (this.memberDropped.length === 1 && this.businessArea.value[this.businessArea.value.length - 1].businessArea === null) {
        this.businessArea.controls.pop();
        this.addRow(false, this.memberDropped[0]);
      }
      else if (this.memberDropped.length > 1 && this.businessArea.value[0].businessArea === null) {
        this.businessArea.controls[0]['controls'].businessArea.patchValue(this.memberDropped[0]);
        this.businessAreaField.patchDataInControls(this.businessArea.controls[0]['controls'].businessArea.value);
        for (var i = 1; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else if (this.memberDropped.length > 1 && this.businessArea.value[this.businessArea.value.length - 1].businessArea === null) {
        this.businessArea.controls.pop();
        for (var i = 0; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else {
        this.memberDropped.forEach(droppedElement => {
          if (droppedElement['dragged']) {
            this.addRow(false, droppedElement);
          }
        });
      }
    }

    else {
      if (this.memberDropped.length > 1) {
        this.alertService.error("You can replace single record at a time");
        return
      }
      const index = this.businessArea.controls.indexOf(businessAreaRow);
      var row = this.businessArea.controls[index];
      if (row.value.id != null) {
        this.businessAreaService.deleteBusinessAreaRow([row.value.id]).subscribe((res) => { });
      }
      this.businessArea.removeAt(index);
      var memberObject = { key: 2, index: index, memberDropped: this.memberDropped[0], rowDropped: businessAreaRow };
      this.addRow(false, this.memberDropped[0], memberObject);
    }
  }

  deleteRow(index: number, row) {
    const control = this.businessAreaForm.get('businessArea') as FormArray;
    if (this.businessArea.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      let that = this;

      this.alertService.confirmation("deleteListConfirm",
        function () {
          that.productService.deleteAllProducts([row.value.id]).subscribe((res) => {

            control.removeAt(index);
            that.updateView();
            that.alertService.success("Successfully Deleted");
          }, err => {
            console.log(err);
          })
        });
    }
    else if (row.value.id === null) {
      let that = this;
      if (this.businessArea.at(index).dirty) {

        this.alertService.confirmation("deleteListConfirm",
          function () {
            control.removeAt(index);
            that.updateView();

            that.alertService.success("Successfully Deleted");
          });
      }
      else {

        control.removeAt(index);
        that.updateView();
      }
    }

  }
  clickComplete(btnAction: ButtonActions) {
    this.showLoader();
    this.biaRecord['businessAreaComplete'] = true;
    this.businessAreaService.saveBiaRecord(this.biaRecord).subscribe((res) => {
      this.hideLoader();
      this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
      this.alertService.success('Business Area Completed Successfully', true);
      this.biaRecord = res;
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  onSubmit(btnAction: ButtonActions) {
    if (this.businessArea.invalid) {
      return
    }
    else {
      this.showLoader();
      this.businessArea.value.forEach(B_area => {
        B_area['bia'] = this.biaRecord;
        if (Array.isArray(B_area.businessArea)) {
          B_area.businessArea = B_area.businessArea[0];
        }
      });
      this.routeParams.buttonAction = btnAction;
      var arrayControls = [];
      arrayControls.push(this.businessAreaForm.get('businessArea'));
      this.businessAreaService.saveAllBusinessAreas(this.businessArea.value).subscribe((res) => {
        this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
      }, err => {
        this.hideLoader();
        console.log(err);
      });
    }
  }
  goBackToMainPage(btnAction: ButtonActions) {
    this.routeParams.buttonAction = btnAction;
    this.navigationHandlerAfterSave(btnAction, null, RouteConstants.BIA_RECORD, this.routeParams);
  }
}