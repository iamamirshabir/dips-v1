import { Component, OnInit } from '@angular/core'; 
import { RouteConstants } from '../../../utils/constants/route-constants';
import { BaseClass } from '../../../utils/baseclass';
import { RouteParams } from '../../../utils/model.route-params';
@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.sass']
})
export class SettingComponent extends BaseClass implements OnInit {
  RouteConstant = RouteConstants;
  constructor() {
    super();
   }

  ngOnInit(): void {
  }
  onLinkClick(url,pageState = null){
    let routeParams = new RouteParams
          routeParams.routerLink = url
          routeParams.pageState = pageState
    this.routingService.openPage(routeParams.routerLink, routeParams); 
  }
}
