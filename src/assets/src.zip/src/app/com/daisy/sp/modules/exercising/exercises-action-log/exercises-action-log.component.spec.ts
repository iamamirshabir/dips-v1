import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExercisesActionLogComponent } from './exercises-action-log.component';

describe('ExercisesActionLogComponent', () => {
  let component: ExercisesActionLogComponent;
  let fixture: ComponentFixture<ExercisesActionLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExercisesActionLogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExercisesActionLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
