import { NgModule } from '@angular/core';
import { CostCenterComponent } from './cost-center.component';
import { RouterModule, Routes } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { CostCenterFormComponent } from './cost-center-form/cost-center-form.component';

const routes: Routes = [
  {
    path: '', component: CostCenterComponent,
  }
]; 

@NgModule({
  declarations: [CostCenterComponent, CostCenterFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ]
})
export class CostCenterModule { }
