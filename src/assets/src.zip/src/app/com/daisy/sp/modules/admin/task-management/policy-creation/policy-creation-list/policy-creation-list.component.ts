import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';

@Component({
  selector: 'app-policy-creation-list',
  templateUrl: './policy-creation-list.component.html',
  styleUrls: ['./policy-creation-list.component.sass']
})
export class PolicyCreationListComponent extends BaseClass implements OnInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  taskType : any = []; 
  constructor(private router: Router, protected activatedRoute: ActivatedRoute,
    public dialog: MatDialog,) {
    super();
  }

  ngOnInit(): void {
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Policy Name', checked: 'true' },
    {key : 'taskType', name : 'Applies To', checked : 'true'},
    { key: 'escalation', name: 'Escalation', checked: 'true' },
    { key: 'firstApprover', name: '1st Approver', checked: 'true' },
    { key: 'secondApprover', name: '2nd Approver', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', option: [] }]

    this.tableButtons = [{ "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD },
    { "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE }
    ];

    this.setDataTable([]);
    
  }
  ngAfterViewInit() {
    this.getPolicyCreationListByOrgId();
    this.hideLoader();
  }


  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.task.management.policy.creation.title'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.OrganisationListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {

    this.openFormHandler(data, PageState.EDIT_STATE);
  }

  printClick(data, exportType) {

  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();

    if (data) {
      routeParams.id = data['id'];
    }

    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.ADMIN_TASK_MANAGEMENT_POLICY_CREATION_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  getPolicyCreationListByOrgId() {
    this.policyCreationService.getTaskPolicyByOrgId().subscribe(res => {
      this.populateDatatable(res);
    });
  }
  populateDatatable(data) {
     this.tableData = data;
    
    if (this.tableData) {
      this.tableData.forEach(element => {
     
      
          element.taskType.forEach(element => {
            this.taskType.push(element.name)
          });
          element.taskType = this.taskType;
          this.taskType=[];

          if(element.escalation === true)
          {
            element.escalation = this.languageTranslator('admin.task.management.policy.creation.enabled');
          }
          else if(element.escalation === false)
          {
            element.escalation = this.languageTranslator('admin.task.management.policy.creation.disabled');
          }
          if(element.firstApprover!=null)
          {
            if(element.firstApprover===true)
            {
              element.firstApprover = this.languageTranslator('admin.task.management.policy.creation.required');
            }
            else{
              element.firstApprover = this.languageTranslator('admin.task.management.policy.creation.not.required')
            }
          }
          else if(element.firstApprover===null){
            element.firstApprover = this.languageTranslator('admin.task.management.policy.creation.not.required')
          }
          
          if(element.secondApprover!=null)
          {
            if(element.secondApprover===true)
            {
              element.secondApprover = this.languageTranslator('admin.task.management.policy.creation.required');
            }
            else{
              element.secondApprover = this.languageTranslator('admin.task.management.policy.creation.not.required')
            }
          }
          else if(element.secondApprover===null){
            element.secondApprover = this.languageTranslator('admin.task.management.policy.creation.not.required')
          }
        
      });
    }
    this.setDataTable(this.tableData)
    
  }
  deleteAllClick(data) {
    
    this.showLoader();
    this.policyCreationService.deleteTaskkPolicyById(data[0].id).
    subscribe(res => {
      this.alertService.success("deleteOne.successfull", true);
      this.hideLoader();
  this.getPolicyCreationListByOrgId();

    }, error => {
      this.hideLoader();
    })
  this.hideLoader();
  this.getPolicyCreationListByOrgId();

  }


  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE_ALL) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
           that.deleteAllClick(this.policyId);
          this.hideLoader();

        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }
  saveRecord(data, pageState) {
    this.showLoader();
    
    this.organisationService.saveOrganisation(data).subscribe(res => {
      this.hideLoader();
      if (pageState == 1) {
        this.alertService.success("creation.successfull", true);
      }
      else {
        this.alertService.success("updation.successfull", true)
      }
      this.getPolicyCreationListByOrgId();
    }, error => {
      this.tableData = [];
      this.setDataTable(this.tableData);
    })
  }
}
