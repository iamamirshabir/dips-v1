import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-risk-strategies',
  templateUrl: './risk-strategies.component.html',
  styleUrls: ['./risk-strategies.component.sass']
})
export class RiskstrategiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
