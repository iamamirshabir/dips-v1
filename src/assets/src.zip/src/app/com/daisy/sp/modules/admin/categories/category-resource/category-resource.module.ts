import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import {CategoryResourceFormComponent} from './category-resource-form/category-resource-form.component'
import { CategoryResourceComponent } from './category-resource.component';
import { CategoryResourceListComponent } from './category-resource-list/category-resource-list.component';

const routes: Routes = [
  {
    path: '', component: CategoryResourceComponent,
    children: [
      { path: 'category-resource-form', component: CategoryResourceFormComponent },
      { path: 'category-resource-list', component: CategoryResourceListComponent },

    ]
  }
]; 

@NgModule({
  declarations: [CategoryResourceFormComponent,CategoryResourceComponent, CategoryResourceListComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    
    RouterModule.forChild(routes)
  ],
  entryComponents:[CategoryResourceFormComponent]
})
export class CategoryResourceModule { }
