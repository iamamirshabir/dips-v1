import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-group',
  templateUrl: './contact-group.component.html'
})

export class ContactGroupComponent{}