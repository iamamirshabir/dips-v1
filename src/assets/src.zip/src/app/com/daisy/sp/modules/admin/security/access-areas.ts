export class AccessAreas {
    public static HOME:number = 0;
    public static BIA:number = 1;
    public static BCP:number = 2; 
    public static NOTIFICATION:number = 3;
    public static RECOVERY:number = 4; 
    public static EXERCISING:number = 5; 
    public static ADMIN:number = 6; 
}