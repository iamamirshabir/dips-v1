import { NgModule } from '@angular/core';
import { ContactGroupFormComponent } from './contact-group-form/contact-group-form.component';
import { ContactGroupComponent } from './contact-group-component';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule, Routes } from '@angular/router';
import { ContactGroupRolesComponent } from './contact-group-role/contact-group-roles.component';
import { ContactGroupHierarchyComponent } from './contact-group-hierarchy/contact-group-hierarchy.component';
import { SwiperConfigInterface, SwiperModule, SWIPER_CONFIG } from 'ngx-swiper-wrapper';
import { ContactGroupListComponent } from './contact-group-list/contact-group-list.component';
const routes: Routes = [
  {
    path: '', component: ContactGroupComponent,
    children: [
      { path: 'contact-groups-hierarchy', component: ContactGroupHierarchyComponent},
      { path: 'contact-groups-role', component: ContactGroupRolesComponent},
      { path: 'contact-groups-form', component: ContactGroupFormComponent},
      { path: 'contact-groups-listing', component: ContactGroupListComponent}
      
    ]
  }
];
const DEFAULT_SWIPER_CONFIG: SwiperConfigInterface = {
  direction: 'horizontal',
  slidesPerView: 3,
  spaceBetween:0,
  keyboard: true,
  mousewheel: true,
  navigation: true,
  breakpoints: {
    200:{
      slidesPerView:1 
    },
    300:{
      slidesPerView:1    
    },
    400:{
      slidesPerView:1    
    },
    500:{
      slidesPerView:1    
    },
    640: {
      slidesPerView: 1
    },
    768: {
      slidesPerView: 2,
    },
    1024: {
      slidesPerView: 3,
      spaceBetween:0
    },
  }
};
@NgModule({
  declarations: [ContactGroupComponent,
    ContactGroupHierarchyComponent,
    ContactGroupRolesComponent,
    ContactGroupFormComponent,
    ContactGroupListComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes),
    SwiperModule

  ],
  providers: [
    {
      provide: SWIPER_CONFIG,
      useValue: DEFAULT_SWIPER_CONFIG
    }
  ]
})
export class ContactGroupModule { }
