import { NgModule } from '@angular/core';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule } from '@angular/router';
import { SecurityProfilesComponent } from './security-profiles.component';
import { ComponentsModule } from '../../../../common/components/components.module';

export const routes = [
  { path: '', component: SecurityProfilesComponent}
];

@NgModule({
  declarations: [SecurityProfilesComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,    
    RouterModule.forChild(routes)
  ]
})

export class SecurityProfilesModule { }
