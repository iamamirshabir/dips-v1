
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RiskstrategiesComponent } from './risk-strategies.component';
import { RiskstrategiesListComponent } from './risk-strategies-list/risk-strategies-list.component';
import { RiskstratgiesFormComponent } from './risk-strategies-form/risk-strategies-form.component';
const routes: Routes = [
  {
    path: '', component: RiskstrategiesComponent,
    children: [
        { path: 'risk-startegies-list', component: RiskstrategiesListComponent },
        { path: 'risk-startegies-form', component: RiskstratgiesFormComponent },
    ]
  }
]; 

@NgModule({
  declarations: [RiskstrategiesComponent, RiskstrategiesListComponent,RiskstratgiesFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[RiskstratgiesFormComponent]
})
export class RiskStrategiesModule { }
