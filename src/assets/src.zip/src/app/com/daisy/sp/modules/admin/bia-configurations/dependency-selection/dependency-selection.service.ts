import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { environment } from "src/environments/environment";
import { Api } from "../../../../utils/api";

@Injectable({ providedIn:'root' })

export class DependencySelectionService {

    constructor(private router:Router, private http:HttpClient){ }

    saveAll(data){
    return this.http.post(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_DEPENDENCY_SELECTION_SAVE_ALL, data)
    }

    update(data){
        return this.http.post(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_DEPENDENCY_SELECTION_UPDATE, data)
    }

    getByOrganisationId(id){
        return this.http.get(`${environment.baseUrl}`  + Api.BIA_CONFIGURATIONS_DEPENDENCY_SELECTION_FIND_BY_ORGANISATION_ID + id);
    }

}