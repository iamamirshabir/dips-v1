import { Component, OnInit, ViewChild, ViewChildren, ElementRef, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormArray, AbstractControl } from '@angular/forms';
import { LoaderService } from 'src/app/core-services/loader.service';
import { BaseClass } from '../../../utils/baseclass';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from "@angular/cdk/drag-drop";
import { RouteParams } from '../../../utils/model.route-params';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { PageState } from '../../../utils/constants/page-state-constants';
import { FileHandle } from '../../../common/directives/drag-drop.directive';
import { SpChipFormFieldComponent } from '../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { ExercisingService } from '../exercising.service';
import { Location } from "@angular/common";
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { MatTable } from '@angular/material/table';
import { BehaviorSubject } from 'rxjs';


@Component({
  selector: 'app-exercises-planning',
  templateUrl: './exercises-planning.component.html',
  styleUrls: ['./exercises-planning.component.sass']
})
export class ExercisesPlanningComponent extends BaseClass implements OnInit, AfterViewChecked {
  value: any;
  exerciseChart: any;
  @ViewChild('fileInput')
  fileInput;
  file: File | null = null;
  exercisePlanningForm: FormGroup;
  ExercisesForm: FormGroup
  uploadedUrl = [];
  flagUploaded: boolean = true;
  exerciseRecord: any;
  files: FileHandle[] = [];
  parentId: any;
  viewOnly = true;
  exerciseSuccessCriteria;
  exerciseType = [];
  uploadRawData: any
  selectedfileName;
  uploadBinaryData
  uploadFile = [];
  documentModel = {};
  fileType;
  uploadedData;
  routeParams: any;
  selected = "Mandatory";
  exerciseId;
  exercisePlanning;
  exerciseName: string = "Default";
  exerciseOwner: string;
  exerciseLead: string;
  exerciseStartDate: string;
  exerciseEndDate: string;

  @ViewChild('table') table: MatTable<any>;
  @ViewChild('table1') table1: MatTable<any>;
  displayColumns = ['#', 'name', 'description', 'mandatory', 'actions'];
  displayColumnsForSuccessCriteria = ['name', 'description'];
  displayColumnsForRoles = ['#', 'name', 'assignedTo', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  dataSourceForSuccess = new BehaviorSubject<AbstractControl[]>([]);
  dataSourceForRoles = new BehaviorSubject<AbstractControl[]>([]);

  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  @ViewChild('leadContact') leadContact: SpChipFormFieldComponent;
  @ViewChild('areasInScope') areasInScope: SpChipFormFieldComponent;
  @ViewChild('observersChip') observersChip: SpChipFormFieldComponent;
  @ViewChild('participantChip') participantChip: SpChipFormFieldComponent;
  exerciseRecordType: any;

  constructor(private formBuilder: FormBuilder, private loadingService: LoaderService,
    private router: Router, protected activatedRoute: ActivatedRoute, private readonly changeDetectorRef: ChangeDetectorRef,
    private exerciseRecordService: ExercisingService, private location: Location) {
    super();
    this.activateRoute.queryParams.subscribe(val => {
      this.initializePageData();
    })
  }

  ngOnInit(): void {
    this.hideLoader();
    this.exerciseRecordService.getSuccessCriteria(this.organisation.id).subscribe(res => {
      this.exerciseSuccessCriteria = res;
    }, err => { })
  }
  async initializePageData() {
    this.ExercisesForm = this.formBuilder.group({
      name: [null],
      type: [null],
      owner: [null],
      lead: [null],
      startDate: [null],
      endDate: [null]
    });

    this.exercisePlanningForm = this.formBuilder.group({
      description: ['', Validators.required],
      assumption: [''],
      validationObjectives: this.formBuilder.array([]),
      exercisePlanSuccessCriteria: this.formBuilder.array([]),
      roles: this.formBuilder.array([]),
      scope: ['', Validators.required],
      observer: [null, Validators.required],
      areasInScope: [null, Validators.required],
      participants: [null, Validators.required],
      documents: [null],
      version: [null],
      id: [null],
    });
  }
  ngAfterViewChecked(): void {

    this.changeDetectorRef.detectChanges();
  }

  updateView(params = null) {
    if (params === "validation") {
      let validationObjective = this.exercisePlanningForm.get("validationObjectives") as FormArray
      this.dataSource.next(validationObjective.controls);
    }
    if (params === "exercisePlanSuccessCriteria") {
      let successCriteria = this.exercisePlanningForm.get("exercisePlanSuccessCriteria") as FormArray;
      this.dataSourceForSuccess.next(successCriteria.controls);
    }
    if (params === "roles") {
      let rolesObjectives = this.exercisePlanningForm.get("roles") as FormArray;
      this.dataSourceForRoles.next(rolesObjectives.controls);
    }

  }
  openFormByState(routeParams) {
    this.setParentId(routeParams);
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.exerciseId = this.routeParams['id'];
    this.exerciseRecord = this.routeParams.data;
    this.patchFormValues();

    if (this.exerciseRecord) {
      this.exerciseRecordService.findExercisePlanningbyExerciseId(this.exerciseRecord.id).subscribe(planning => {
        this.exercisePlanning = planning;
        this.patchPlanningFormValues()
      }, error => {
        this.addMemberFormGroup('');
        this.patchSuccesCriteria();
      })
    }
  }
  openFormHandler(data = null, pageState, routerLink = null) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.data = data;
    }
    this.setParentId(routeParams);
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.EXERCISING;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  setParentId(pageParams) {
    this.parentId = pageParams.parentParams && pageParams.parentParams.id ? pageParams.parentParams.id : 0;
  }

  patchFormValues() {
    this.ExercisesForm.patchValue(this.exerciseRecord);
    this.exerciseType.push(this.exerciseRecord.type);
    this.ownerContact.patchDataInControls(this.exerciseRecord['owner'], this.viewOnly);
    this.leadContact.patchDataInControls(this.exerciseRecord['lead'], this.viewOnly);
    this.hideLoader();
  }
  patchSuccesCriteria() {
    if (this.exerciseSuccessCriteria != undefined) {
      this.exerciseSuccessCriteria.forEach(element => {
        const successCriteria = <FormArray>this.exercisePlanningForm.controls['exercisePlanSuccessCriteria'];
        successCriteria.push(
          this.formBuilder.group({
            name: element.name,
            planDescription: this.formBuilder.control(null),
          })
        );
      });
      this.updateView("exercisePlanSuccessCriteria");
    }
  }
  patchPlanningFormValues() {
    if (this.exercisePlanning.validationObjectives.length > 0) {
      this.exercisePlanning.validationObjectives.forEach(element => {
        this.addMemberFormGroup("validation");
      });
    }
    else {
      this.addMemberFormGroup("validation");
    }
    if (this.exercisePlanning.roles.length > 0) {
      this.exercisePlanning.roles.forEach(element => {
        this.addMemberFormGroup("roles");
      });
    }
    else {
      this.addMemberFormGroup("roles");
    }
    this.areasInScope.patchDataInControls(this.exercisePlanning['areasInScope']);
    this.observersChip.patchDataInControls(this.exercisePlanning['observer']);
    this.participantChip.patchDataInControls(this.exercisePlanning['participants']);
    if (this.exercisePlanning.exercisePlanSuccessCriteria.length > 0) {
      this.exercisePlanning.exercisePlanSuccessCriteria.forEach(element => {
        this.addMemberFormGroup("exercisePlanSuccessCriteria");
      });
    }
    else {
      this.addMemberFormGroup("exercisePlanSuccessCriteria");
    }
    if (this.exercisePlanning.exercisePlanSuccessCriteria.length) {
      this.exercisePlanning.exercisePlanSuccessCriteria.forEach((entry) => {
        entry['name'] = entry.exerciseSuccessCriteria.name;
      });
    }
    else {
      this.exerciseSuccessCriteria.forEach(element => {
        this.exercisePlanning.exercisePlanSuccessCriteria.push(element)
      });
    }

    this.exercisePlanning.documents.forEach(element => {
      this.uploadedUrl.push(element)
      this.uploadBinaryData = this.fileSringToBinary(element.document);
      this.documentModel = {
        name: element.name,
        document: this.uploadBinaryData,
        path: ""
      };
      this.uploadFile.push(this.documentModel);
    });
    this.exercisePlanningForm.patchValue(this.exercisePlanning);
    if (this.routedPageState === 3) {
      this.exercisePlanningForm.disable();
    }
    this.hideLoader();
  }
  public removeOrClearMemberRow(i: number, params) {
    if (params === 'validation') {
      const control = <FormArray>this.exercisePlanningForm.controls['validationObjectives'];
      control.removeAt(i);
      if (control.controls.length == 0) {
        this.addMemberFormGroup('validation');
      }
    }
    else if (params === 'roles') {
      const control = <FormArray>this.exercisePlanningForm.controls['roles'];
      control.removeAt(i);
      if (control.controls.length == 0) {
        this.addMemberFormGroup('roles');
      }
    }

  }
  public addMemberFormGroup(params, i = null) {
    if (params === 'validation') {
      const validations = <FormArray>this.exercisePlanningForm.controls['validationObjectives'];
      validations.push(this.createValidationFormGroup());
      this.updateView(params);
      return
    }
    else if (params === 'roles') {
      const roles = <FormArray>this.exercisePlanningForm.controls['roles'];
      roles.push(this.createRoleFormGroup());
      this.updateView(params);
      return
    }
    else if (params === 'exercisePlanSuccessCriteria') {
      const participants = <FormArray>this.exercisePlanningForm.controls['exercisePlanSuccessCriteria'];
      participants.push(this.createPlanSuccessCriteriaFormGroup());
      this.updateView("exercisePlanSuccessCriteria");
      return
    }
    const validations = <FormArray>this.exercisePlanningForm.controls['validationObjectives'];
    validations.push(this.createValidationFormGroup());
    this.updateView("validation");
    const roles = <FormArray>this.exercisePlanningForm.controls['roles'];
    roles.push(this.createRoleFormGroup());
    this.updateView("roles");
    this.updateView("exercisePlanSuccessCriteria");
  }
  private createValidationFormGroup(): FormGroup {
    let validationObjectives = this.exercisePlanningForm.get("validationObjectives") as FormArray;
    return this.formBuilder.group({
      id: this.formBuilder.control(null),
      // priority: this.formBuilder.control(validationObjectives.controls.length + 1),
      priority: this.formBuilder.control(null),
      name: ['', Validators.required],
      description: ['', Validators.required],
      mandatory: this.formBuilder.control(null),
      version: this.formBuilder.control(null)
    })
  }
  private createRoleFormGroup(): FormGroup {
    let rolesObjectives = this.exercisePlanningForm.get("roles") as FormArray;
    return this.formBuilder.group({
      assignedTo: [null, Validators.required],
      name: ['', Validators.required],
    })
  }
  private createPlanSuccessCriteriaFormGroup(): FormGroup {
    let rolesObjectives = this.exercisePlanningForm.get("exercisePlanSuccessCriteria") as FormArray;
    return this.formBuilder.group({
      name: this.formBuilder.control(null),
      planDescription: this.formBuilder.control(null),
    })
  }
  roles(params): FormArray {
    if (params === 'validation') {
      return this.exercisePlanningForm.get("validationObjectives") as FormArray
    }
    else if (params === 'roles') {
      return this.exercisePlanningForm.get("roles") as FormArray
    }
    else if (params === 'exercisePlanSuccessCriteria') {
      return this.exercisePlanningForm.get("exercisePlanSuccessCriteria") as FormArray
    }
  }
  dropTable(event: CdkDragDrop<any[]>) {
    let validationObjectives = this.exercisePlanningForm.get("validationObjectives") as FormArray;
    const prevIndex = validationObjectives.controls.findIndex((d) => d === event.item.data);
    moveItemInArray(validationObjectives.controls, prevIndex, event.currentIndex);
    this.table.renderRows();
    this.table1.renderRows();
    this.setSortOrder(validationObjectives.controls, 'priority');
  }
  onClickFileInputButton(): void {
    this.fileInput.nativeElement.click();
  }
  browseFile(event: { target: { files: any[]; }; }) {
    this.flagUploaded = false;
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      let file = event.target.files[0];
      this.fileType = file.type;
      reader.readAsDataURL(file);
      reader.onload = (event: any) => {
        this.uploadedData = file;
        this.uploadRawData = event.target.result;
        this.uploadedUrl.push(this.uploadedData);

        let filestring = btoa(this.uploadRawData);
        this.uploadBinaryData = this.fileSringToBinary(filestring);
        this.documentModel = {
          name: file.name,
          document: this.uploadBinaryData,
          path: ""
        };
        this.uploadFile.push(this.documentModel);
      };
    }
  }
  filesDropped(files: FileHandle[]): void {
    this.flagUploaded = false;
    files.forEach((file => {
      if (file) {
        var reader = new FileReader();
        this.fileType = file.file.type;
        reader.readAsDataURL(file.file);
        reader.onload = (event: any) => {
          this.uploadedData = file;
          this.uploadRawData = event.target.result;
          this.uploadedUrl.push(this.uploadedData);
          let filestring = btoa(this.uploadRawData);
          this.uploadBinaryData = this.fileSringToBinary(filestring);
          this.documentModel = {
            name: file.file.name,
            document: this.uploadBinaryData,
            path: ""
          };
          this.uploadFile.push(this.documentModel);
        };
      }
    }));
  }
  fileSringToBinary(strData: string): any {
    const byteCharacters = atob(strData);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    return byteNumbers;
  }
  deleteImage(file) {
    this.uploadedUrl.forEach((item, index) => {
      if (item === file) {
        this.uploadedUrl.splice(index, 1);
        this.uploadFile.splice(index, 1);
      }
    });

  }
  checkArrays(exercisesRecordPlanning) {
    exercisesRecordPlanning.roles.forEach(role => {
      if (Array.isArray(role.assignedTo)) {
        role.assignedTo.forEach((roleContact) => {
          role.assignedTo = roleContact;
        })
      }
    });
    return
  }
  setImageBinary(file) {
    this.fileSringToBinary(file)
  }
  downloadFile(file) {
    if (file.document) {
      var fileDownlaoded = atob(file.document);
      var link = document.createElement("a");
      link.download = file.name;
      link.href = fileDownlaoded;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    else {
      var reader = new FileReader();
      var result;
      reader.readAsDataURL(file);
      reader.onload = (event: any) => {
        result = event.target.result;
        var link = document.createElement("a");
        link.download = file.name;
        link.href = result;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      };
    }

  }
  exerciseSuccessCriteriaValues(planningForm) {
    if (this.exercisePlanning) {
      this.exercisePlanning.exercisePlanSuccessCriteria.forEach((successPlan) => {
        planningForm.exercisePlanSuccessCriteria.forEach(plan => {
          if (plan.name === successPlan.name) {
            if (successPlan.exerciseSuccessCriteria) {
              return plan['exerciseSuccessCriteria'] = successPlan.exerciseSuccessCriteria;
            }
            else {
              return plan['exerciseSuccessCriteria'] = successPlan;
            }
          }
        });
      });
    }
    else {
      this.exerciseSuccessCriteria.forEach((successPlan) => {
        planningForm.exercisePlanSuccessCriteria.forEach(plan => {
          if (plan.name === successPlan.name) {
            return plan['exerciseSuccessCriteria'] = successPlan;
          }
        });
      });
    }
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  onSubmit(btnType: ButtonActions) {
    if (this.routeParams.pageState != 3) {
      if (this.exercisePlanningForm.invalid || this.exercisePlanningForm.controls.validationObjectives.invalid || this.exercisePlanningForm.controls.roles.invalid) {
        this.alertService.error("Please fill in all the fields");
        Object.keys(this.exercisePlanningForm.controls).forEach(field => {
          const control = this.exercisePlanningForm.get(field);
          control.markAsTouched({ onlySelf: true });
        });
        this.exercisePlanningForm.controls.validationObjectives['controls'].forEach(item => {
          Object.keys(item.controls).forEach((field) => {
            const validationArray = item.get(field);
            validationArray.markAsTouched({ onlySelf: true });
          })
        });
        this.exercisePlanningForm.controls.roles['controls'].forEach(item => {
          Object.keys(item.controls).forEach((field) => {
            const roles = item.get(field);
            roles.markAsTouched({ onlySelf: true });
          })
        });
      }

      else {
        var planningForm = this.exercisePlanningForm.getRawValue();
        planningForm.document = this.exercisePlanningForm.value.document;
        this.checkArrays(planningForm);
        planningForm['exercise'] = this.exerciseRecord;
        this.exerciseSuccessCriteriaValues(planningForm);
        if (this.uploadFile.length) {
          planningForm.documents = this.uploadFile;
        }
        planningForm.documents = this.uploadFile;
        this.showLoader();
        var arrayControls = [];
        arrayControls.push(this.exercisePlanningForm.get('validationObjectives'));
        arrayControls.push(this.exercisePlanningForm.get('exercisePlanSuccessCriteria'));
        arrayControls.push(this.exercisePlanningForm.get('roles'));
        arrayControls.push(this.exercisePlanningForm.get('participants'));
        arrayControls.push(this.exercisePlanningForm.get('observer'));
        arrayControls.push(this.exercisePlanningForm.get('areasInScope'));
        this.checkFormChange(this.exercisePlanningForm, arrayControls, true);
        this.exerciseRecordService.saveExercisePlanning(planningForm).subscribe(planning => {
          this.navigationHandlerAfterSave(btnType, planning);
          if (this.exercisePlanning) {
            this.hideLoader();
            this.alertService.success('Successfully Updated')
          }
          else {
            this.hideLoader();
            this.alertService.success('Successfully Created')
          }
        }, err => {
          this.hideLoader();
        })
      }
    }
  }
  goBackToMainPage() {
    // this.openFormHandler(this.exerciseRecord, PageState.EDIT_STATE)
    var arrayControls = [];
    arrayControls.push(this.exercisePlanningForm.get('validationObjectives'));
    arrayControls.push(this.exercisePlanningForm.get('exercisePlanSuccessCriteria'));
    arrayControls.push(this.exercisePlanningForm.get('roles'));
    arrayControls.push(this.exercisePlanningForm.get('participants'));
    arrayControls.push(this.exercisePlanningForm.get('observer'));
    arrayControls.push(this.exercisePlanningForm.get('areasInScope'));
    this.checkFormChange(this.exercisePlanningForm, arrayControls, false);
    this.routingService.openPage(RouteConstants.EXERCISES_LIST);
    // this.routingService.openPage(RouteConstants.EXERCISING);
    // this.routedPageState = PageState.ADD_STATE;


  }
}
