import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';

@Injectable({
  providedIn: 'root'
})
export class RisksService {

  constructor(private httpClient: HttpClient){}
  
  saveRisk(data): Observable<any>{ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_RISK_SAVE}`,data);
  } 

  getRiskLists(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_RISK_FIND_BY_BIA_ID+id);
  } 

  deleteRiskbyId(id) : Observable<any>{
    return this.httpClient.delete<any>(`${environment.baseUrl}`+Api.BIA_RISK_REMOVE_BY_ID+id);
  }

  getRiskStrategies(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_RISK_STRATEGY_LIST+id);
  }

  getRisklevels(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_RISK_LEVELS_BY_ORG_ID+id);
  }
  
  deleteRiskbyIds(data) : Observable<any>{
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.BIA_RISK_REMOVE , data);
  }
  saveBiaRecord(biaRecord): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
}
}
