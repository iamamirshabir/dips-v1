import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { CustomFieldFormComponent } from '../custom-field-form/custom-field-form.component';
import { RouteParams } from '../../../../utils/model.route-params';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { RecordTypesConstants } from '../../../../utils/constants/record-types-constant';
import { CustomFieldTypesConstants } from '../../../../utils/constants/custom_field_types';


@Component({
  selector: 'app-custom-field-list',
  templateUrl: './custom-field-list.component.html',
  styleUrls: ['./custom-field-list.component.sass']
})
export class CustomFieldListComponent extends BaseClass implements OnInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  public recordTypes: any = [];
  public customFieldTypes : any =[];
  dialogRef: MatDialogRef<CustomFieldFormComponent> | null;
  recId: any;
  constructor(private router: Router, protected activatedRoute: ActivatedRoute,
    public dialog: MatDialog,) {
    super();
  }

  ngOnInit(): void {
    this.recordTypes = RecordTypesConstants.Record_Data;
    this.customFieldTypes = CustomFieldTypesConstants.Custom_Field_Data;

    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Custom Field Name', checked: 'true' },
    { key: 'customFieldName', name: 'Custom Field Type', checked: 'true' },
    { key: 'recordTypeName', name: 'Record Type', checked: 'true' },
    { key: 'description', name: 'Description', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.setDataTable([]);
    this.getCustomFieldList();

  }

  getCustomFieldList() {
    this.showLoader();
    this.customFieldService.getAllCustomFields().
      subscribe(res => {
        this.hideLoader();
        if (res) {
          this.tableData = res;
        } else {
          this.tableData = [];
        }
        if (this.tableData) {
          this.tableData.forEach(element => {
            if (element.customFieldType !== null) {
              let obj = this.customFieldTypes.find(val => val.id == element.customFieldType);
              let translatedNames = this.languageTranslator(obj.name);
              element['customFieldName'] = translatedNames;
            }
            if (element.recordType !== null) {
              let obj = this.recordTypes.find(val => val.id == element.recordType);
              let translatedNames = this.languageTranslator(obj.name);
              element['recordTypeName'] = translatedNames;

            }
          })
        }
        this.setDataTable(this.tableData);
      }, error => {
        this.hideLoader();
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
  }

  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.customeField.title'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: false,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.AnalysisColorsListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, PageState.EDIT_STATE);
  }

  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.BIA_CONFIG_CUSTOM_FIELD_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  printClick(data, exportType) {

  }
  deleteAllClick(data) {
    this.showLoader();
    let Id = this.getIdsFromList(data);
    this.customFieldService.deleteCustomField(Id).
      subscribe(res => {
        this.hideLoader();
        this.getCustomFieldList();
      }, error => {
        this.hideLoader();
      })
  }
  deleteCustomFieldById(data) {
    this.showLoader();
    this.customFieldService.deleteCustomField([data.id]).subscribe((res) => {
      this.hideLoader();
      this.getCustomFieldList();
    }, err => {
      this.hideLoader();
    })

  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteCustomFieldById(data);
        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }
}
