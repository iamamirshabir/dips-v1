import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, ValidationErrors, ValidatorFn, FormControl } from '@angular/forms';
import { PasswordService } from '../password.service';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.sass']
})
export class ChangePasswordComponent extends BaseClass implements OnInit {
  passwordPolicy: any;
  changePassword: FormGroup;
  changePasswordTitle = "Administration: Change Password";
  oldPassword = false;
  newPassword = false;
  confirmPassword = false;
  userId = this.user.id;

  // numberRegExp = new RegExp("^.*\\d.*$");
  // letterRegExp = new RegExp("^.*[a-zA-Z].*$");
  // specialCharacterRequiredRegExp = new RegExp("^.*\\W.*$");

  specialCharacterRequired = false;
  letterRequired = false;
  numberRequired = false;
  minLength = false;

  constructor(private formBuilder: FormBuilder, private passwordService: PasswordService) { super(); }

  ngOnInit(): void {
    this.hideLoader();
    this.getPasswordPolicies(this.organisation.id);  

    this.changePassword = this.formBuilder.group({
      oldPassword: [''],
      newPassword:[''],  
      confirmPassword: [''],
       
    }
    )}


  getPasswordPolicies(id) {
    this.passwordService.getPasswordPolicyByOrganisationId(id).subscribe(data => {
      this.showLoader()
      this.passwordPolicy = data; 
      console.log(this.passwordPolicy);
      
      this.changePassword = this.formBuilder.group({
        oldPassword: [''],
        newPassword:['',this.getPaterns()],  
        confirmPassword: [''],
        
  
      });
    }, errorCode => {
      this.hideLoader();
    });
  }

  getPaterns(){
    let paternsList:any=[];
    if(this.passwordPolicy.specialCharacterRequired){
      paternsList.push(this.regexValidator(new RegExp('^.*\\W.*$'), {'symbols': true}));
    }
    if(this.passwordPolicy.letterRequired){
      paternsList.push(this.regexValidator(new RegExp('^.*[a-zA-Z].*$'), {'letter': true}));
    }
    if(this.passwordPolicy.numberRequired){
      paternsList.push(this.regexValidator(new RegExp('^.*\\d.*$'), {'digit': true}));
    }
    if(this.passwordPolicy.minLength){
      paternsList.push(Validators.minLength(this.passwordPolicy.minLength ));
    }
    return paternsList; 
  }
  regexValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} => {
        if (!control.value) {
            return null;
        }
        const valid = regex.test(control.value);
        return valid ? null : error;
    }
  }
  onSubmit(passwordObject) {
    Object.assign(passwordObject, { userId: this.userId })
    if (this.changePassword.invalid) {
      this.oldPassword = true;
      this.newPassword = true;
      this.confirmPassword = true;
      return;
    }
    if (passwordObject.newPassword != passwordObject.confirmPassword) {
      this.alertService.error('Your New Password and confirm password are not same');
      return;
    }
    else if (this.changePassword && passwordObject.newPassword == passwordObject.confirmPassword) {
      if (passwordObject) {
        this.passwordService.updatePassword(passwordObject).subscribe(res => {
          this.hideLoader();
          this.alertService.success('Successfully Updated');
        }, error => { })

     }
    }
  }
  // validateRegExpression(value: any, regExp: RegExp) {
  //   var founded: Object = regExp.exec(String(value));
  //   return founded ? false : true;
  // }

  goBackToMainPage() {
    this.routingService.navigate(['/shadowplanner'])
  }
}

