import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';

@Component({
  selector: 'app-category-it-form',
  templateUrl: './category-it-form.component.html',
  styleUrls: ['./category-it-form.component.sass']
})
export class CategoryITFormComponent extends BaseClass implements OnInit {
  categoryItForm: FormGroup;
  submitted = false;
  ButtonActions = ButtonActions;
  contactTypes: any[] = [];
  routeParams: any;
  selectedContactType: any = '0';
  subCategories: any;
  RtoObject: any;
  rtoList: any[];
  selectedRTO: any;
  realEntities: any;
  selectedRPO: any;
  selectedART: any;
  selectedARP: any;
  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  @ViewChild('perspectiveDepartmental') perspectiveDepartmental: SpChipFormFieldComponent;
  @ViewChild('perspectiveLocational') perspectiveLocational: SpChipFormFieldComponent;
  @ViewChild('categorySupplier') categorySupplier: SpChipFormFieldComponent;
  cat_IT_Id: any;
  categoryObject: any;
  addState: boolean = true;
  disableRto: boolean = false;
  disableRpo: boolean = false;
  categoryITRealEntityObj: any;
  categoryITOwnerObj: any;
  categorySupplierObj: any;
  public static RPO_TYPE: number = 1;
  public static RTO_TYPE: number = 2;
  public static ART_TYPE: number = 3;
  public RTOdurationString: any = [];
  public ARTdurationString: any = [];
  public RPOdurationString: any = [];
  public ARPdurationString: any = [];
  public RTOArray: any = [];
  public RPOArray: any = [];
  public ARTArray: any = [];
  public ARPArray: any=[];
  timeScales: any = [];
  cat_IT_data: any;
  cat_IT_type: any;
  perspectiveLocationalObj: any;
  perspectiveDepartmentalObj: any;
  artTimeScale: any;
  rtoTimeScale: any;
  arpTimeScale: any;
  rpoTimeScale: any;
  hierarchy:string;
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.categoryItForm.controls; }
  ngOnInit(): void {

    this.categoryItForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: ['', [Validators.required]],
      description: [''],
      category: [null],
      categoryName:[null],
      perspectiveDepartmental : [null],
      perspectiveLocational : [null],
      rto: [null],
      rpo: [null],
      art: [null],
      arp: [null],
      requiredRto: null,
      requiredRpo: null,
      lastTested: [''],
      owner: [null],
      provider: null,
      itServicePriority: [''],
      sla: [''],
      ola: [''],
      version: [null]

    });
    this.loadingService.enableLoading();
    this.getRealEntity();

  }
  openFormByState(routeParams) {
    console.log("reciever");
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_IT_Id = this.routeParams['id'];
    this.cat_IT_data = this.routeParams['data'];
    if (this.cat_IT_Id) {
      this.getCategoryITById(this.cat_IT_Id);
    }
    if( this.cat_IT_data){
      this.cat_IT_type = this.cat_IT_data['type'];
      this.artTimeScale = this.cat_IT_data['artTimeScale'];
      this.rtoTimeScale = this.cat_IT_data['rtoTimeScale'];
      this.arpTimeScale = this.cat_IT_data['arpTimeScale'];
      this.rpoTimeScale = this.cat_IT_data['rpoTimeScale'];
      if (this.artTimeScale != null) {
        this.ARTArray = this.setTimeScalesList(this.artTimeScale.id,TimeScalesConstant.ART_TYPE);
          this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.ART_TYPE)
            this.ARTArray = data.list;
           });
      }
      if (this.rtoTimeScale != null) {
        this.RTOArray = this.setTimeScalesList(this.rtoTimeScale.id,TimeScalesConstant.RTO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.RTO_TYPE)
            this.RTOArray = data.list;
           });
      }
      if (this.rpoTimeScale != null) {
        this.RPOArray = this.setTimeScalesList(this.rpoTimeScale.id,TimeScalesConstant.RPO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.RPO_TYPE)
            this.RPOArray = data.list;
           } );
      }
      if (this.arpTimeScale != null) {
        this.ARPArray = this.setTimeScalesList(this.arpTimeScale.id,TimeScalesConstant.ARP_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.ARP_TYPE)
            this.ARPArray = data.list;
           } );
       }
      this.getCategoryByOrgId();
      this.hierarchy = this.cat_IT_data.hierarchy;
      this.categoryItForm.controls['category'].setValue(this.cat_IT_data);
    }
  }
  getCategoryITById(id) {
    this.showLoader();
    this.categoryItService.getCategoryITById(id).subscribe(data => {
      this.hideLoader();
      this.categoryObject = data;
      this.patchFormData();
    }, error => {
      this.hideLoader();
    })

  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.duration === f2.duration;
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.addState = true;
      this.ownerContact.patchDataInControls(this.categoryItForm.controls['owner']);
      this.perspectiveLocational.patchDataInControls(this.categoryItForm.controls['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryItForm.controls['perspectiveDepartmental']);
      this.categorySupplier.patchDataInControls(this.categoryItForm.controls['provider']);
    } else {
      this.addState = false;
      this.ownerContact.patchDataInControls(this.categoryObject['owner']);
      this.categorySupplier.patchDataInControls(this.categoryObject['provider']);
      this.perspectiveLocational.patchDataInControls(this.categoryObject['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryObject['perspectiveDepartmental']);
 
      this.bindJsonObjectToFormObject(this.categoryObject, this.categoryItForm);
    

    }
  }
  getCategoryByOrgId() {
    this.showLoader();
    this.categoryItService.getSubCategories(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.subCategories = data;
      let SubCatObj =this.subCategories.find(item =>(item.type == this.cat_IT_type));
      if(SubCatObj != undefined){
       this.categoryItForm.controls['categoryName'].setValue(SubCatObj.name);
      }
      if(this.hierarchy){
        this.categoryItForm.controls['categoryName'].setValue(this.hierarchy);
      }
    }, error => {
      this.hideLoader();
    })
  }

  getRealEntity() {
    this.showLoader();
    this.categoryItService.getRealEntityByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.realEntities = data;
    }, error => {
      this.hideLoader();
    })
  }

  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.categoryItForm.invalid) {
      return;
    }
    this.categoryItForm.controls['organisation'].setValue(this.organisation);

    this.showLoader();

    this.categoryITOwnerObj =  Array.isArray(this.categoryItForm.value.owner) ? this.categoryItForm.value.owner[0] : this.categoryItForm.value.owner;
    this.categorySupplierObj =  Array.isArray(this.categoryItForm.value.provider) ? this.categoryItForm.value.provider[0] : this.categoryItForm.value.provider;
    this.perspectiveLocationalObj =   this.categoryItForm.value.perspectiveLocational;
    this.perspectiveDepartmentalObj =  this.categoryItForm.value.perspectiveDepartmental;

    this.categoryItForm.controls['perspectiveLocational'].setValue(this.perspectiveLocationalObj);
    this.categoryItForm.controls['perspectiveDepartmental'].setValue(this.perspectiveDepartmentalObj);
    this.categoryItForm.controls['owner'].setValue(this.categoryITOwnerObj);
    this.categoryItForm.controls['provider'].setValue(this.categorySupplierObj);
    this.categoryItService.saveCategoryIT(this.categoryItForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        } 
        // else if (btnType == ButtonActions.SAVE_AND_CONT) {
        //   this.contactObject = res;
        //   this.routedPageState = PageState.EDIT_STATE;
        //   this.patchFormData();
        // }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CATEGORY_IT_LIST);
  }

}