import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PolicyCreationService {

  constructor(private httpClient: HttpClient) { }
  savePolicyForm(data)
  {    
    return this.httpClient.post(`${environment.baseUrl}`+Api.ADMIN_POLICY_CREATION_SAVE,data);

  }
  saveAllPolicyForm(data)
  {
    return this.httpClient.post(`${environment.baseUrl}`+Api.ADMIN_POLICY_CREATION_SAVE_ALL,data);
    
  }
  getTaskPolicyById(id)
  {
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.ADMIN_POLICY_CREATION_FIND_BY_ID+"/"+id,id);
  }
  getTaskPolicyByOrgId()
  {
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.ADMIN_POLICY_CREATION_FIND_BY_ORG_ID);
  }
  deleteTaskkPolicyById(id)
  {
    return this.httpClient.delete<any>(`${environment.baseUrl}` + Api.ADMIN_POLICY_CREATION_DELETE_BY_ID + "/" + id);
  }
}
