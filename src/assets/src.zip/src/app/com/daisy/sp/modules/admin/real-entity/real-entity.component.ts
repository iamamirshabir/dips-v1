import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-real-entity',
  templateUrl: './real-entity.component.html',
  styleUrls: ['./real-entity.component.sass']
})
export class RealEntityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
