import { routes } from './../../../../../../../login/login.module';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PasswordService } from '../password.service';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-password-policy',
  templateUrl: './password-policy.component.html',
  styleUrls: ['./password-policy.component.sass']
})
export class PasswordPolicyComponent extends BaseClass implements OnInit {

  passwordPolicyForm: FormGroup;
  passwordPolicy: any;

  constructor(private formBuilder: FormBuilder, private passwordService: PasswordService) {
    super();
  }

  ngOnInit(): void {
    this.passwordPolicyForm = this.formBuilder.group({
      minLength: [''],
      passwordExpiry: [''],
      passwordHistory: [''],
      letterRequired: [false],
      numberRequired: [false],
      specialCharacterRequired: [false],
      id: [null],
      version: [null]
    });
    this.getPageData();
  }
  getPageData() {
    this.showLoader()
    this.passwordService.getPasswordPolicyByOrganisationId(this.organisation.id).
      subscribe(policy => {
        this.hideLoader();
        this.passwordPolicy = policy;
        this.bindJsonObjectToFormObject(this.passwordPolicy, this.passwordPolicyForm)
      })
  }

  onSubmit() {
    if (this.passwordPolicyForm.invalid) {
      return;
    }
    if (this.passwordPolicy) {
      this.passwordPolicyForm.value['organisation'] = this.organisation;
      this.passwordService.savePasswordPolicies(this.passwordPolicyForm.value).
        subscribe(res => {
          this.hideLoader();
          this.alertService.success('Successfully Updated');
          this.getPageData();
        }, error => { })
    }
    else {
      this.passwordPolicyForm.value['organisation'] = this.organisation;
      this.passwordService.savePasswordPolicies(this.passwordPolicyForm.value).
        subscribe(res => {
          this.hideLoader();
          this.alertService.success('Successfully Saved');
          this.getPageData();
        }, error => { })
    }
  }

  goBackToMainPage(){
    this.routingService.navigate(['/shadowplanner']);
  }
}

