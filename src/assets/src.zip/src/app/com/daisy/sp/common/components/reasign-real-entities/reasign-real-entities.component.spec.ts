import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasignRealEntitiesComponent } from './reasign-real-entities.component';

describe('ReasignRealEntitiesComponent', () => {
  let component: ReasignRealEntitiesComponent;
  let fixture: ComponentFixture<ReasignRealEntitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReasignRealEntitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasignRealEntitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
