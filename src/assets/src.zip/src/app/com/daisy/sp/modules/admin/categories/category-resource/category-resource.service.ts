import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CategoryResourceService {
  public catResourceDetails: any;
  constructor(private httpClient: HttpClient) { }
  getSubCategories(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategpryResourceByOrgId(orgId) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_RESOURCE_FIND_BY_ORGANIZATION_ID + '/' + orgId);
  }
  saveCategoryResource(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_RESOURCE_SAVE}`, data);
  }
  getCategoryResourceById(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_RESOURCE_FIND_BY_ID + '/' + id);
  }
  deleteCategoryResourceById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_RESOURCE_REMOVE_BY_ID}`, id);
  }
  getCategoryResourceByOrgIdAndCanDoBia(orgId) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_RESOURCE_FIND_BY_ORGANIZATION_ID + '/' + orgId + Api.CAN_DO_BIA);
  }
  getCategpryResourceBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_CATEGORY_RESOURCE, data);
  }
}
