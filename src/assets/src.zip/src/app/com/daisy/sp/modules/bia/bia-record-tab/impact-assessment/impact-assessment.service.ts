import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ImpactAssessmentService {

  constructor(private router: Router, private httpClient: HttpClient) { }


  saveImpactAssessment(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_IMPACT_ASSESSMENT_SAVE}`, data);
  }

  getImpactAssessmentLists(bia_id, recoveryPolicy_id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_IMPACT_ASSESSMENT_BY_BIA_ID_AND_RECOVERY_POLICY_ID + bia_id + '/' + recoveryPolicy_id);
  }
  getRTOLists(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.BIA_RTO_LIST_BY_ID + id);
  }
  saveBiaRecord(biaRecord): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
  }
  getRecoveryPolicyById(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.RECOVERY_POLICY_FIND_BY_ID + '/' + id);
  }

}