import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactGroupService {

  constructor(private httpClient: HttpClient) { }

  getContactGroupHeirarchy():Observable<any> {
    return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_GROUP_HEIRARCHY_FIND_ALL}`);
  }

  saveContactGroup(contactGroup):Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CONTACT_GROUP_SAVE_CONTACT_GROUP}`, contactGroup);
  }

  getContactGroupById(id){
    return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_GROUP_GET_CONTACT_GROUP_BY_ID}/`+id);
  }
  removeContactGroupById(id){
    return this.httpClient.delete(`${environment.baseUrl + Api.CONTACT_GROUP_REMOVE_CONTACT_GROUP_BY_ID}/`+id);
  }
  getContactGroupByParentId(id)
  {
    return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_GROUP_GET_CONTACT_GROUP_BY_PARENT_ID}/`+id)
  }

  removeAllContactGroups(groups){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.CONTACT_GROUP_REMOVE_ALL,groups);
  }

  getContactGroupByOrganisationId(id)
  {
    return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_GROUP_FIND_BY_ORGANISATIO_ID}/`+id)
  }
  
  getdPreviousRecordByParentId(id)
  {
    return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_GROUP_FIND_PREVIOUS_BY_PARENT_ID}/`+id)
  }

  getContactGroupBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_CONTACT_GROUP_BY_SEARCH_CRITERIA, data);
  }
}
