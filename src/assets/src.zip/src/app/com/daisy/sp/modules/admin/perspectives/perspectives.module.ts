import { NgModule } from '@angular/core';
import { PerspectivesComponent } from './perspectives.component';
import { PerspectivesListComponent } from './perspectives-list/perspectives-list.component';
import { PerspectivesFormComponent } from './perspectives-form/perspectives-form.component'; 
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '', component: PerspectivesComponent,
    children: [
      { path: 'perspective-form', component: PerspectivesFormComponent },
      { path: 'perspective-list', component: PerspectivesListComponent }
    ]
  }
];


@NgModule({
  declarations: [PerspectivesComponent, PerspectivesListComponent, PerspectivesFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  providers: [],
  entryComponents: [PerspectivesFormComponent]
}) 
export class PerspectivesModule { }
