import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoveryPoliciesFormComponent } from './recovery-policies-form.component';

describe('RecoveryPoliciesFormComponent', () => {
  let component: RecoveryPoliciesFormComponent;
  let fixture: ComponentFixture<RecoveryPoliciesFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecoveryPoliciesFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoveryPoliciesFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
