import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoveryPoliciesListComponent } from './recovery-policies-list.component';

describe('RecoveryPoliciesListComponent', () => {
  let component: RecoveryPoliciesListComponent;
  let fixture: ComponentFixture<RecoveryPoliciesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecoveryPoliciesListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoveryPoliciesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
