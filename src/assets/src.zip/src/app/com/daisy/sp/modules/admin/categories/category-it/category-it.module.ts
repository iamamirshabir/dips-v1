import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { CategoryITComponent } from './category-it.component';
import { CategoryITFormComponent } from './category-it-form/category-it-form.component';
import { CategoryITListComponent } from './category-it-list/category-it-list.component';
const routes: Routes = [
  {
    path: '', component: CategoryITComponent,
    children: [
      { path: 'category-it-list', component: CategoryITListComponent },
      { path: 'category-it-form', component: CategoryITFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [CategoryITListComponent, CategoryITFormComponent,CategoryITComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[CategoryITFormComponent]
})
export class CategoryITModule { }
