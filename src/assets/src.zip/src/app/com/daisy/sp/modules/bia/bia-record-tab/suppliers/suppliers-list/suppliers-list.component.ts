
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { BehaviorSubject } from 'rxjs';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { GlobalConstants } from '../../../../../utils/global-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { CategoryTypes } from '../../../../../utils/constants/category-types'
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';


@Component({
  selector: 'app-suppliers-list',
  templateUrl: './suppliers-list.component.html',
  styleUrls: ['./suppliers-list.component.sass']
})
export class SuppliersListComponent extends BaseClass implements OnInit {
  displayColumns = ['name', 'descriptionOfReliance', 'rto', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  routeParams: any;
  suppliers: FormArray = this.fb.array([]);
  supplierForm: FormGroup = this.fb.group({ 'suppliers': this.suppliers });
  @ViewChild(MatSort) sort: MatSort;
  biaRecordId: any;
  biaType: any;
  categoryRecord: any;
  biaRecord: any;
  selectedRTO: any;
  RtoObject: any;
  rtoList: any = [];
  memberDropped: any;
  globals: GlobalConstants;
  @ViewChild('supplierField') supplierField: SpChipFormFieldComponent;
  rtoId: any;


  constructor(private fb: FormBuilder, globals: GlobalConstants) {
    super();
    this.globals = globals;

  }

  ngOnInit(): void {
   
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.biaType = this.routeParams.parentParams;
    this.biaRecord = this.routeParams.data;
    let categoryRecord = this.biaRecord['categoryRecord'];
    if (categoryRecord['category']) {
      let categoryData = categoryRecord['category'];
      if (categoryData['rtoTimeScale']) {
        let rtoTimeScale = categoryData['rtoTimeScale'];
        this.rtoId = rtoTimeScale['id'];
        if (categoryData['rtoTimeScale']) {
          let rtoTimeScale = categoryData['rtoTimeScale'];
          this.rtoId = rtoTimeScale['id'];
          this.rtoList = this.setTimeScalesList(this.rtoId, TimeScalesConstant.RTO_TYPE);
          this.getTimeScalesList().subscribe(
            (data) => {
              if (data.type == TimeScalesConstant.RTO_TYPE)
                this.rtoList = data.list;
            });
        }
      }
    }
    this.BIASupplierService.getSupplierByBIA(this.biaRecordId).subscribe((res) => {
      if (res.length >= 1) {

        this.patchSupplierValues(res);
      }
      else {
        this.addRow();
      }
    }, (err) => {
      console.log(err);
    })
  }
  patchSupplierValues(res) {
    var supplierValues = res;
    supplierValues.forEach(Rows => {
      this.addRow();
      this.suppliers.patchValue(res);
      this.updateView();
    });

  }

  emptyTable() {
    while (this.suppliers.length !== 0) {
      this.suppliers.removeAt(0);
    }
  }
  compareObjects(o1: any, o2: any): boolean {
    return o1.name === o2.name && o1.id === o2.id;
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.id === f2.id;
  }

  addRow(noUpdate?: boolean, droppedElement = null, objectToReplace = null) {
    this.globals.DROPPED_ID_ARRAY = [];
    if (objectToReplace != null && objectToReplace.key === 2) {
      var row = this.fb.group({
        id: [null],
        supplierCategory: [null, Validators.required],
        descOfRel: [null, [Validators.required]],
        rto: [null, Validators.required],
        version: [null],
      });
      this.suppliers.insert(objectToReplace.index, row);
    }
    else {
      if (this.suppliers.controls[this.suppliers.controls.length - 1] != undefined) {
        if (this.suppliers.controls[this.suppliers.controls.length - 1]['controls'].supplierCategory.invalid) {
          this.suppliers.controls[this.suppliers.controls.length - 1]['controls'].supplierCategory.markAsTouched();
          return
        }
      }
      var row = this.fb.group({
        id: [null],
        supplierCategory: [null, Validators.required],
        descOfRel: [null, [Validators.required]],
        rto: [null, Validators.required],
        version: [null],
      });
      this.suppliers.push(row);
    }
    if (!noUpdate) { this.updateView(); }
    if (droppedElement != null) {
      row.controls.supplierCategory.patchValue(droppedElement);
    }
    for (var i = 0; i < this.suppliers.controls.length; i++) {
      this.globals.DROPPED_ID_ARRAY.push('list-' + i)
    }

  }

  updateView() {
    this.dataSource.next(this.suppliers.controls);
  }
  dropFromSearch(event: CdkDragDrop<string[]>, businessAreaRow) {
    this.memberDropped = event.previousContainer.data;

    if (this.memberDropped[0].category.type != CategoryTypes.SUPPLIER) {
      return
    }

    if (businessAreaRow.value.supplierCategory === null) {
      if (this.memberDropped.length === 1 && this.suppliers.value[0].supplierCategory === null) {
        this.suppliers.controls[0]['controls'].supplierCategory.patchValue(this.memberDropped[0]);
        this.supplierField.patchDataInControls(this.suppliers.controls[0]['controls'].supplierCategory.value);
      }
      else if (this.memberDropped.length === 1 && this.suppliers.value[this.suppliers.value.length - 1].supplierCategory === null) {
        this.suppliers.controls.pop();
        this.addRow(false, this.memberDropped[0]);
      }
      else if (this.memberDropped.length > 1 && this.suppliers.value[0].supplierCategory === null) {
        this.suppliers.controls[0]['controls'].supplierCategory.patchValue(this.memberDropped[0]);
        this.supplierField.patchDataInControls(this.suppliers.controls[0]['controls'].supplierCategory.value);
        for (var i = 1; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else if (this.memberDropped.length > 1 && this.suppliers.value[this.suppliers.value.length - 1].supplierCategory === null) {
        this.suppliers.controls.pop();
        for (var i = 0; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else {
        this.memberDropped.forEach(droppedElement => {
          if (droppedElement['dragged']) {
            this.addRow(false, droppedElement);
          }
        });
      }
    }

    else {
      if (this.memberDropped.length > 1) {
        this.alertService.error("You can replace single record at a time");
        return
      }
      const index = this.suppliers.controls.indexOf(businessAreaRow);
      var row = this.suppliers.controls[index];
      if (row.value.id != null) {
        this.BIASupplierService.deleteSupplierbyId([row.value.id]).subscribe((res) => { });
      }
      this.suppliers.removeAt(index);
      var memberObject = { key: 2, index: index, memberDropped: this.memberDropped[0], rowDropped: businessAreaRow };
      this.addRow(false, this.memberDropped[0], memberObject);
    }
  }


  deleteRow(index: number, row) {
    const control = this.supplierForm.get('suppliers') as FormArray;
    if (this.suppliers.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      let that = this;
    
        this.alertService.confirmation("deleteListConfirm",
          function () {
            that.BIASupplierService.deleteSupplierbyId([row.value.id]).subscribe((res) => {
            
              control.removeAt(index);
            that.updateView();
            that.alertService.success("Successfully Deleted");
            }, err => {
              console.log(err);
            })
          });
    }
    else if (row.value.id === null) {
      let that = this;
      if (this.suppliers.at(index).dirty) {
      
        this.alertService.confirmation("deleteListConfirm",
          function () {
            control.removeAt(index);
            that.updateView();
          
          this.alertService.success("Successfully Deleted");
          });
      }
      else {
        
        control.removeAt(index);
        that.updateView();
      }
    }

  }
  clickComplete(btnAction: ButtonActions) {
    this.showLoader();
    this.biaRecord['suppliersComplete'] = true;
    this.BIASupplierService.saveBiaRecord(this.biaRecord).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('Suppliers Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      this.biaRecord = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  onSubmit(btnAction: ButtonActions) {
    if (this.suppliers.invalid) {
      return
    }
    this.showLoader();
    this.suppliers.value.forEach(val => {
      val['bia'] = this.biaRecord;
      if (Array.isArray(val.supplierCategory)) {
        val.supplierCategory = val.supplierCategory[0];
      }
    });
    var arrayControls = [];
    arrayControls.push(this.supplierForm.get('suppliers'));
    this.BIASupplierService.saveAllBiaSupplier(this.suppliers.value).subscribe((res) => {
      this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
      this.hideLoader();
      if (this.routedPageState === 1) {
        this.alertService.success("Successfully Created");
      }
      else {
        this.alertService.success("Successfully Updated")
      }
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  goBackToMainPage(btnAction: ButtonActions) {
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
  }
}
