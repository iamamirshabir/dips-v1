import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainLayoutComponent } from './main-layout.component';
import { DashboardComponent } from '../modules/dashboard/dashboard.component';
import { PasswordPolicyComponent } from '../modules/admin/password/password-policy/password-policy.component';
import { ChangePasswordComponent } from '../modules/admin/password/change-password/change-password.component';
import { MyDashboardComponent } from '../modules/my-dashboard/my-dashboard.component';
import { RouteConstants } from '../utils/constants/route-constants';

const routes: Routes = [
  {
    path: '', component: MainLayoutComponent,
    children: [
      { path: '', component: MyDashboardComponent },
      { path: 'dashboard', component: MyDashboardComponent },
      { path: 'my-dashboard', component: DashboardComponent },
      { path: 'contacts-list', loadChildren: () => import('../modules/admin/contacts/contacts-list/contacts-list.module').then(m => m.ContactsListModule) },
      { path: 'contact-form', loadChildren: () => import('../modules/admin/contacts/contact-form/contact-form.module').then(m => m.ContactFormModule) },
      { path: 'contact-group', loadChildren: () => import('../modules/admin/contact-group/contact-group.module').then(m => m.ContactGroupModule) },
      { path: 'real-entity', loadChildren: () => import('../modules/admin/real-entity/real-entity.module').then(m => m.RealEntityModule) },
      { path: 'analysis-colors', loadChildren: () => import('../modules/admin/bia-configurations/analysis-colors/analysis-colors.module').then(m => m.AnalysisColorsModule) },
      { path: 'organisation', loadChildren: () => import('../modules/admin/organisation/organisation.module').then(m => m.OrganisationModule) },
      { path: 'timescales', loadChildren: () => import('../modules/admin/bia-configurations/timescales/timescales.module').then(m => m.TimescalesModule) },
      { path: 'security-profiles', loadChildren: () => import('../modules/admin/security/security-profiles/security-profiles.module').then(m => m.SecurityProfilesModule) },
      { path: 'security-roles', loadChildren: () => import('../modules/admin/security/security-roles/security-roles.module').then(m => m.SecurityRolesModule) },
      { path: 'exercising', loadChildren: () => import('../modules/exercising/exercising.module').then(m => m.ExercisingModule) },
      { path: 'bia', loadChildren: () => import('../modules/bia/bia.module').then(m => m.BIAModule) },
      { path: 'exercises-list', loadChildren: () => import('../modules/exercising/exercises-list/exercises-list.module').then(m => m.ExercisesListModule) },
      { path: 'password-policy-form', component: PasswordPolicyComponent },
      { path: 'change-password', component: ChangePasswordComponent },
      { path: 'riskstrategies', loadChildren: () => import('../modules/admin/bia-configurations/risk-strategies/risk-strategies.module').then(m => m.RiskStrategiesModule) },
      { path: 'impactcategories', loadChildren: () => import('../modules/admin/bia-configurations/impact-categories/impact-categories.module').then(m => m.ImpactCategoriesModule) },
      { path: 'recoverypolicies', loadChildren: () => import('../modules/admin/bia-configurations/recovery-policies/recovery-policies.module').then(m => m.RecoveryPoliciesModule) },
      { path: 'risks', loadChildren: () => import('../modules/admin/bia-configurations/risk/risk.module').then(m => m.RiskModule) },
      { path: 'employee-type-list', loadChildren: () => import('../modules/admin/contacts/employee-type/employee-type-list/employee-type-list.module').then(m => m.EmployeeTypeListModule) },
      { path: 'it-service-type', loadChildren: () => import('../modules/admin/bia-configurations/it-service-type/it-service-type.module').then(m => m.ItServiceTypeModule) },
      { path: 'perspectives', loadChildren: () => import('../modules/admin/perspectives/perspectives.module').then(m => m.PerspectivesModule) },

      { path: 'task-policy', loadChildren: () => import('../modules/admin/task-policy/task-policy.module').then(m => m.TaskPolicyModule) },
      { path: 'cost-center', loadChildren: () => import('../modules/admin/bia-configurations/cost-center/cost-center.module').then(m => m.CostCenterModule) },
      { path: 'business-entity', loadChildren: () => import('../modules/admin/bia-configurations/business-entity/business-entity.module').then(m => m.BusinessEntityModule) },
      { path: 'category-it', loadChildren: () => import('../modules/admin/categories/category-it/category-it.module').then(m => m.CategoryITModule) },
       { path: 'category-location', loadChildren: () => import('../modules/admin/categories/category-location/category-location.module').then(m => m.CategoryLocationModule) },
      { path: 'category-supplier', loadChildren: () => import('../modules/admin/categories/category-supplier/category-supplier.module').then(m => m.CategorySupplierModule) },
      { path: 'category-business-area', loadChildren: () => import('../modules/admin/categories/category-business-area/category-business-area.module').then(m => m.CategoryBusinessAreaModule) },
      { path: 'category-resource', loadChildren: () => import('../modules/admin/categories/category-resource/category-resource.module').then(m => m.CategoryResourceModule) },
      { path: 'category-productService', loadChildren: () => import('../modules/admin/categories/category-productService/category-productService.module').then(m => m.CategoryProductServiceModule) },
      { path: 'categories', loadChildren: () => import('../modules/admin/categories/categories.module').then(m => m.CategoriesModule) },
      { path: 'custom-field', loadChildren: () => import('../modules/admin/custom-field/custom-field.module').then(m => m.CustomFieldModule) },
      { path: 'dependency-selection', loadChildren: () => import('../modules/admin/bia-configurations/dependency-selection/dependency-selection.module').then(m => m.DependencySelectionModule) },
      { path: 'task-management', loadChildren: () => import('../modules/admin/task-management/task-management.module').then(m => m.TaskManagementModule) },
      
      
    ]
  },
  { path: '**', redirectTo: '/login', pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainLayoutRoutingModule { }
