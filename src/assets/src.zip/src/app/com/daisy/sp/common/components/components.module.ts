import { NgModule } from '@angular/core';
import { SpChipFormFieldComponent } from './sp-chip-form-field/sp-chip-form-field.component';
import { AppSharedModule } from 'src/app/app.shared.module';
import { ListingViewComponent } from './listing-view/listing-view.component';
import { ChevronMenusComponent } from './chevron-menus/chevron-menus.component';
import { ChevronPermissionDirective } from '../directives/chevron-permission.directive';
import { DragDropDirective } from '../directives/drag-drop.directive';
import { CalenderDateTimeComponent } from './calender-date-time/calender-date-time.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { JwtInterceptor } from 'src/app/auth-helpers/jwt.interceptor';
import { ErrorInterceptors } from 'src/app/auth-helpers/error.interceptors';
import { ReasignRealEntitiesComponent } from './reasign-real-entities/reasign-real-entities.component';
import { SearchInListFilterPipe } from '../pipes/search-in-list-filter.pipe';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { ExpandListingViewComponent } from './expand-listing-view/expand-listing-view.component';
import { EditableListingViewComponent } from './editable-listing-view/editable-listing-view.component';
import { SearchModalComponent } from './search-modal/search-modal.component';
import { ConfirmationComponentComponent } from './confirm-leave-form/confirmation-component.component';



@NgModule({
  declarations: [
    ListingViewComponent,
    SpChipFormFieldComponent,
    ChevronMenusComponent,
    ChevronPermissionDirective,
    DragDropDirective,
    CalenderDateTimeComponent,
    ReasignRealEntitiesComponent,
    SearchInListFilterPipe,
    ConfirmationComponent,
    ExpandListingViewComponent,
    EditableListingViewComponent,
    SearchModalComponent,
    ConfirmationComponentComponent
  ],
  imports: [
    AppSharedModule
  ],
  exports: [
    AppSharedModule,
    ListingViewComponent,
    SpChipFormFieldComponent,
    ChevronMenusComponent,
    ChevronPermissionDirective,
    DragDropDirective,
    CalenderDateTimeComponent,
    SearchInListFilterPipe,
    ExpandListingViewComponent,
    EditableListingViewComponent,
    SearchModalComponent,
    ConfirmationComponentComponent
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptors, multi: true }
  ],
  entryComponents: [ReasignRealEntitiesComponent,
    ConfirmationComponent]
})
export class ComponentsModule { }
