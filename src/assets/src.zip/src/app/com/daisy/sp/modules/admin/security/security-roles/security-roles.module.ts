import { NgModule } from '@angular/core';
import { SecurityRolesComponent } from './security-roles.component';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule } from '@angular/router';

export const routes = [
  { path: '', component: SecurityRolesComponent}
];

@NgModule({
  declarations: [SecurityRolesComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,    
    RouterModule.forChild(routes)
  ]
})
export class SecurityRolesModule { }
