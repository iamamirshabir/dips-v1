import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChevronMenusComponent } from './chevron-menus.component';

describe('ChevronMenusComponent', () => {
  let component: ChevronMenusComponent;
  let fixture: ComponentFixture<ChevronMenusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChevronMenusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChevronMenusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
