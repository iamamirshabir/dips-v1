import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, RouterEvent } from '@angular/router';
import { Chart } from 'chart.js';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { RouteParams } from '../../../utils/model.route-params';
import { BaseClass } from '../../../utils/baseclass';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ExercisingService } from '../../exercising/exercising.service'
import { SpChipFormFieldComponent } from '../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { PageState } from '../../../utils/constants/page-state-constants';
import { ChangeDetectorRef } from '@angular/core';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
// import { DirtyComponent } from 'src/app/models/dirty-component';

@Component({
  selector: 'app-exercises',
  templateUrl: './exercises.component.html',
  styleUrls: ['./exercises.component.sass']
})
export class ExercisesComponent extends BaseClass implements OnInit {
  exerciseChart: any;
  exerciseType: any = [];
  ExercisesForm: FormGroup;

  options = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      display: true
    },
    tooltips: {
      enabled: true
    }
  }
  exerciseRecord;
  exercisePlanning;
  viewOnly = true;
  parentParams;
  exerciseTypeSelected;
  addState: boolean = true;
  exerciseSuccessCriteria;
  routeParams: any;
  exerciseId;
  routedState = 1;
  selectedExerciseRecord;
  action = "pending_actions";
  exerciseButtonsObject = [{ icon: "pending_actions", name: "Planning" },
  { icon: "query_builder", name: "Observation" },
  { icon: "link", name: "Exercise Reporting" }];

  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  @ViewChild('leadContact') leadContact: SpChipFormFieldComponent;

  constructor(private formBuilder: FormBuilder, private router: Router, private activatedRoute: ActivatedRoute, private exerciseRecordService: ExercisingService, private detectChangeRef: ChangeDetectorRef) {
    super();

    this.exerciseRecordService.getExerciseType(this.organisation.id).subscribe(res => {
      this.exerciseType = res;
    }, err => { })
  }
  ngOnInit(): void {
    this.ExercisesForm = this.formBuilder.group({
      name: ['', Validators.required],
      type: [null, Validators.required],
      owner: ['', Validators.required],
      lead: ['', Validators.required],
      startDate: [null, Validators.required],
      endDate: [null, Validators.required]
    });
    this.hideLoader();
    this.ExercisesForm.get('type').valueChanges.subscribe(value => {
      this.exerciseTypeSelected = value;
    });
  }

  ngAfterViewChecked(): void {

    this.detectChangeRef.detectChanges();
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedState = this.routeParams.pageState;
    this.routedPageState = this.routeParams['pageState'];
    this.exerciseId = this.routeParams['id'];
    if (this.exerciseId) {
      this.getExerciseById(this.exerciseId);
    }
    if (this.routeParams.data.id !== undefined) {
      this.exerciseRecord = this.routeParams.data;
      this.patchFormValues();
    }
  }
  openFormHandler(data = null, pageState, routerLink = null) {
    let routeParams: RouteParams = new RouteParams();
    routeParams.parentParams = this.pageParams;
    if (data) {
      routeParams.data = data;
    }
    routeParams.pageState = pageState;
    if (routerLink === 'Planning') {
      routeParams.routerLink = RouteConstants.EXERCISES_PLANNING;

    } else if (routerLink === 'Observation') {
      routeParams.routerLink = RouteConstants.EXERCISES_OBSERVATION;

    } else if (routerLink === 'Exercise Reporting') {
      routeParams.routerLink = RouteConstants.EXERCISES_REPORTING;
    }
    else if (routerLink === 'actionLogs') {
      routeParams.routerLink = RouteConstants.EXERCISES_ACTION_LOGS;
    }
    this.showLoader();
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }

  getExerciseById(id) {
    this.showLoader();
    this.exercisingService.findExerciseRecordbyId(id).subscribe(data => {
      this.hideLoader();
      this.exerciseRecord = data;
      this.addState = false;
      this.ExercisesForm.patchValue(this.exerciseRecord);
      if (this.routedPageState != 1) {
        this.patchFormValues();
      }
      this.selectedExerciseRecord = this.exerciseRecord.name;
    }, error => {
      this.hideLoader();
    })
  }

  patchFormValues() {
    this.ownerContact.patchDataInControls(this.exerciseRecord['owner']);
    this.leadContact.patchDataInControls(this.exerciseRecord['lead']);
    this.ExercisesForm.patchValue(this.exerciseRecord);
    this.dataStatistics();
    if (this.routedPageState === 3) {
      this.ExercisesForm.disable();
    }
    this.hideLoader();
    this.detectChangeRef.detectChanges();
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  dataStatistics() {
    if (this.exerciseRecord === undefined) {
      this.exerciseChart = new Chart('canvas', {
        type: 'pie',
        data: {
          labels: ['Action Count', 'Observation Count', 'Critical Issues Count', 'Non Critical Issues Count'],
          datasets: [{
            data: [0, 0, 0, 0],
            backgroundColor: ["rgba(232, 195, 185, 1)", "rgba(62, 149, 205, 1)", "rgba(142, 94, 162, 1)"],
            borderColor: "#fff",
          }]
        },
        options: this.options
      });
    }
    else {
      if (this.exerciseRecord.actionCount != undefined ||
        this.exerciseRecord.observationCount != undefined ||
        this.exerciseRecord.criticalIssuesCount != undefined ||
        this.exerciseRecord.nonCriticalIssuesCount != undefined) {

        this.exerciseChart = new Chart('canvas', {
          type: 'pie',
          data: {
            labels: ['Action Count', 'Observation Count', 'Critical Issues Count', 'Non Critical Issues Count'],
            datasets: [{
              data: [this.exerciseRecord.actionCount, this.exerciseRecord.observationCount, this.exerciseRecord.criticalIssuesCount, this.exerciseRecord.nonCriticalIssuesCount],
              backgroundColor: ["rgba(232, 195, 185, 1)", "rgba(62, 149, 205, 1)", "rgba(142, 94, 162, 1)"],
              borderColor: "#fff",
            }]
          },
          options: this.options
        });
      }
    }
  }

  exercisingOperations(param) {
    this.openFormHandler(this.exerciseRecord, this.routedPageState, param);
  }
  checkArrays(exercisesRecord) {
    if (Array.isArray(exercisesRecord.owner)) {
      exercisesRecord.owner.forEach((owners) => {
        exercisesRecord.owner = owners;
      })
    }
    if (Array.isArray(exercisesRecord.lead)) {
      exercisesRecord.lead.forEach((leads) => {
        exercisesRecord.lead = leads;
      })
    }
  }
  onSubmit(btnType: ButtonActions) {
    if (this.ExercisesForm.invalid) {
      Object.keys(this.ExercisesForm.controls).forEach(field => {
        const control = this.ExercisesForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    }
    else {
      var exercisesRecord = this.ExercisesForm.value;
      this.checkArrays(exercisesRecord);

      exercisesRecord['organisation'] = this.organisation;
      if (this.exerciseRecord !== undefined) {
        exercisesRecord['id'] = this.exerciseRecord.id;
        exercisesRecord['version'] = this.exerciseRecord.version;
      }
      this.showLoader();

      this.exerciseRecordService.saveExercisingRecord(exercisesRecord).subscribe(record => {
        this.addState = false;
        this.exerciseRecord = record;
        if (this.exerciseId) {
          this.hideLoader();
          this.alertService.success('Successfully Updated')

        }
        else {
          this.hideLoader();
          this.alertService.success('Successfully Created')

        }
        if (btnType == ButtonActions.SAVE_AND_CONT) {
          this.routedPageState = PageState.EDIT_STATE;
        }
        else {
          this.goBackToMainPage();
        }
      }, error => { })
    }

  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.EXERCISES_LIST);
  }

}
