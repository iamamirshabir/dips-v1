import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessEntityFormComponent } from './business-entity-form/business-entity-form.component';
import { RouterModule, Routes } from '@angular/router';
import { BusinessEntityComponent } from './business-entity.component';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';

const routes: Routes = [
  {
    path: '', component: BusinessEntityComponent,
  }
]; 

@NgModule({
  declarations: [BusinessEntityComponent, BusinessEntityFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ]
})
export class BusinessEntityModule { }
