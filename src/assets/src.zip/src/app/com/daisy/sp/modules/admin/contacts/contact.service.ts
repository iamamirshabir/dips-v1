import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';
import { Observable, forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ContactService {

  constructor(private router: Router, private httpClient: HttpClient) { }

  saveContact(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.CONTACT_SAVE_CONTACT}`, data);
  }

  saveAllContacts(contacts) {
    return this.httpClient.post(`${environment.baseUrl + Api.CONTACT_SAVE_ALL_CONTACT}`, contacts);
  }

  logout() {
    window.localStorage.clear();
    this.router.navigate(['/login']);
  }

  getContactList(listRequestParams) {
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.CONTACT_FIND_ALL_CONTACTS, listRequestParams);
  }

  getContactById(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CONTACT_FIND_CONTACT_BY_ID + "/" + id);
  }

  getFullContactList() {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CONTACT_FIND_ALL_CONTACTS);
  }

  getSecurityRoles() {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.SECURITY_FIND_SECURITY_ROLES);
  }

  getOrganisationList() {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ORGANISATION_FIND_ALL_ORGANISATION);
  }

  getContactFormPreLoadingData(organisationId): Observable<any[]> {
    let employeeTypes = this.httpClient.get<any>(`${environment.baseUrl}` + Api.EMPLOYEE_TYPE_FIND_BY_CONTACT_TYPE_AND_ORGANISATION+organisationId);
    return forkJoin([employeeTypes]);
  }

  deleteAllContacts(contacts) {
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.CONTACT_DELETE_BY_IDS, contacts);
  }

  deleteContactById(id) {
    return this.httpClient.delete<any>(`${environment.baseUrl}` + Api.CONTACT_DELETE_CONTACTS_BY_ID + "/" + id);
  }

  getSpchipRecords(url, reqType, data = null) {
    if (reqType == 'get') {
      return this.httpClient.get<any>(`${environment.baseUrl}` + url);
    }
    if (reqType == 'post') {
      return this.httpClient.post<any>(`${environment.baseUrl}` + url, data);
    }
  }

  getBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_CONTACT_BY_SEARCH_CRITERIA, data);
  }

}