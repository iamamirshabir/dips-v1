import { Component, OnInit, ViewChild, ViewChildren, ElementRef, ChangeDetectorRef, AfterViewChecked, Input } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { BaseClass } from '../../../utils/baseclass';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { RouteParams } from '../../../utils/model.route-params';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { PageState } from '../../../utils/constants/page-state-constants';
import { AfterViewInit } from '@angular/core';
import { ListRequest } from '../../../utils/mode.listRequest';
import { ButtonActions } from '../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../utils/constants/mat-icons-constants';
import { IListingView } from '../../../common/components/listing-view/listing-view.interface';
import { ChevronMenuClassName } from '../../../common/components/chevron-menus/chevron-menu-class-names';

@Component({
  selector: 'app-exercises-action-log',
  templateUrl: './exercises-action-log.component.html',
  styleUrls: ['./exercises-action-log.component.sass']
})
export class ExercisesActionLogComponent extends BaseClass implements OnInit, AfterViewInit {
  @Input() exercise;
  iListingView: IListingView;
  public tableData: any;
  public displayedColumns: any;
  public tableButtons: any;
  form: FormGroup;
  public filterSelectObj: any = [];
  exerciseId;
  routedState;
  routeParams;
  constructor(private router: Router, protected activatedRoute: ActivatedRoute, private planningForm: FormBuilder) {
    super();
    this.form = this.planningForm.group({});
  }


  ngOnInit(): void {
    this.displayedColumns = [
      { key: 'actionRef', name: 'Act Ref' ,checked: 'true'},
      { key: 'actionDetail', name: 'Action Detail' ,checked: 'true'},
      { key: 'name', name: 'Owner' ,checked: 'true'},
      { key: 'dateLogged', name: 'Date Logged' ,checked: 'true'},
      { key: 'impact', name: 'Impact',checked: 'true' }
    ];


    this.filterSelectObj = [{ name: 'Impact', columnProp: 'impact', options: [] }];
    this.setDataTable([]);
  }
  ngAfterContentInit(): void {
    if (this.exercise) {
      this.exerciseId = this.exercise.id;
      this.getExerciseActionLogs();
    }
    this.hideLoader();
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedState = this.routeParams.pageState;
    this.routedPageState = this.routeParams['pageState'];
    this.exerciseId = this.routeParams.data.id;

    if (this.exerciseId) {
      this.exercise = this.routeParams.data;
      this.getExerciseActionLogs();
    }
  }
  getExerciseActionLogs() {
    let listParams = new ListRequest();
    listParams.pageNumber = 0;
    listParams.recordPerPage = 500;
    listParams.sortDirection = 'asc'
    listParams.sortField = 'firstName'
    this.exercisingService.getExerciseActionByExID(this.exerciseId).subscribe(contacts => {
      this.tableData = contacts;
      if (this.tableData) {
        this.tableData.forEach(element => {
          element.name = element.owner.firstName + " " + element.owner.lastName;
          element.impact = element.impact.name;
        });

      }
      this.setDataTable(this.tableData);
    }, error => {
      this.tableData = [];
      this.setDataTable(this.tableData);
    })
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: "",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ContactListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  // btnDoubleClicked(data) {
  //   this.editClick(data);

  // }
  // addClick(data) {
  //   let routeParams: RouteParams = new RouteParams();
  //   routeParams.pageState = PageState.ADD_STATE;
  //   routeParams.routerLink = RouteConstants.CONTACT_FORM;
  //   this.routingService.openPage(routeParams.routerLink, routeParams);
  //   // this.routingService.openRelativePage(routeParams);
  // }
  // editClick(data) {
  //   let routeParams: RouteParams = new RouteParams();
  //   routeParams.id = data['id'];
  //   routeParams.pageState = PageState.EDIT_STATE;
  //   routeParams.routerLink = RouteConstants.CONTACT_FORM;
  //   this.routingService.openPage(routeParams.routerLink, routeParams);
  //   // this.routingService.openRelativePage(routeParams);
  // }
  // viewClick(data) {
  //   let routeParams: RouteParams = new RouteParams();
  //   routeParams.id = data['id'];
  //   routeParams.pageState = PageState.VIEW_STATE;
  //   routeParams.routerLink = RouteConstants.CONTACT_FORM;
  //   this.routingService.openPage(routeParams.routerLink, routeParams);
  //   // this.routingService.openRelativePage(routeParams);
  // }
  printClick(data,exportType) {

  }
  deleteAllClick(data) {
    this.contactService.deleteContactById(data[0].id)
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.EXERCISING);
  }
  // chevronMenuClick(chevronMenu: any) {
  //   let btnAction = chevronMenu.btnAction;
  //   let data = chevronMenu.data;
  //   if (btnAction == ButtonActions.EDIT) {
  //     this.editClick(data);
  //   }
  //   if (btnAction == ButtonActions.DELETE) {
  //     this.deleteClick(data);
  //   }
  //   if (btnAction == ButtonActions.VIEW) {
  //     this.viewClick(data);
  //   }
  // }

}
