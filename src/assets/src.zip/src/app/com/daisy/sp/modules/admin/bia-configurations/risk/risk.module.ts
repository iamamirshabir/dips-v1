import { RiskLevelComponent } from './risk-level/risk-level.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule, Routes } from '@angular/router';
import { RiskComponent } from './risk.component';
import { RiskAssessmentMatrixComponent } from './risk-assessment-matrix/risk-assessment-matrix.component';
const routes: Routes = [
  {
    path: '', component: RiskComponent,
    children: [
      { path: 'risk-levels', component: RiskLevelComponent },
      { path: 'risk-assessment-matrix', component:RiskAssessmentMatrixComponent}
      
    ]
  }
]; 

@NgModule({
  declarations: [RiskLevelComponent, RiskComponent, RiskAssessmentMatrixComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
})
export class RiskModule { }
