import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { ChevronMenuItem } from './chevron-menu-item.model'; 
import { BtnEvent } from '../../../utils/mode.btnEvent'; 

@Component({
  selector: 'app-chevron-menus',
  templateUrl: './chevron-menus.component.html',
  styleUrls: ['./chevron-menus.component.sass']
})
export class ChevronMenusComponent implements OnInit {
  @Input() data:any;
  @ViewChild('childMenu', {static: true}) public childMenu: any;
  @Output() chevronMenuClick = new EventEmitter<any>();  
  
  menusList:ChevronMenuItem[]=[];
  constructor() { 
  } 
  ngOnInit(): void { 
  } 
  setMenu(menusList:any){
    this.menusList = menusList;
  } 
  chevronMenuClickHandler(menu:ChevronMenuItem){
    if(menu.disabled){
      return;
    }else{
      let btnEvent:BtnEvent = new BtnEvent();
      btnEvent.data = this.data;
      btnEvent.btnAction = menu.key;
      this.chevronMenuClick.emit(btnEvent);
    }
  } 
}
