
import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { BehaviorSubject } from 'rxjs';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { CategoryTypes } from '../../../../../utils/constants/category-types'
import { GlobalConstants } from 'src/app/com/daisy/sp/utils/global-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';

@Component({
  selector: 'app-resources-list',
  templateUrl: './resources-list.component.html',
  styleUrls: ['./resources-list.component.sass']
})
export class ResourcesListComponent extends BaseClass implements OnInit {

  displayColumns = ['name', 'resourceDescription', 'descriptionOfReliance', 'businessAsUsual', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  routeParams: any;
  resources: FormArray = this.fb.array([]);
  resourcesForm: FormGroup = this.fb.group({ 'resources': this.resources });
  @ViewChild(MatSort) sort: MatSort;
  biaRecordId: any;
  biaType: any;
  categoryRecord: any;
  biaRecord: any;
  memberDropped: any;
  globals: GlobalConstants;

  @ViewChild('resourceField') resourceField: SpChipFormFieldComponent;

  constructor(private fb: FormBuilder, globals: GlobalConstants) {
    super();
    this.globals = globals;

  }

  ngOnInit(): void {
  
  }
  patchDescription(ev) {
    console.log(ev);
    var rowSelected = ev;
    if (rowSelected.value.resource != null) {
      if (rowSelected.controls) {
        rowSelected.controls.description.patchValue(rowSelected.value.resource[0].description)
      }
    }
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.biaRecordId = this.routeParams.data.id;
    this.routedPageState = this.routeParams['pageState'];
    this.biaType = this.routeParams.parentParams;
    this.biaRecord = this.routeParams.data;
    this.showLoader();
    this.resourcesService.getBIAResourceLists(this.biaRecordId).subscribe((res) => {
      this.hideLoader();
      if (res.length >= 1) {
        this.patchResourcesValues(res);
      }
      else {
        this.addRow();
      }
    }, err => {
      this.hideLoader();
    })
  }
  patchResourcesValues(res) {
    var ResourcesValues = res;
    let i = 0;
    ResourcesValues.forEach(resourcesRows => {
      this.addRow();
      this.resources.patchValue(res);
      this.resources['controls'][i]['controls'].description.patchValue(resourcesRows.resource.description);
      i++;
      this.updateView();
    });

  }

  emptyTable() {
    while (this.resources.length !== 0) {
      this.resources.removeAt(0);
    }
  }
  compareObjects(o1: any, o2: any): boolean {
    return o1.name === o2.name && o1.id === o2.id;
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.id === f2.id;
  }

  addRow(noUpdate?: boolean, droppedElement = null, objectToReplace = null) {
    this.globals.DROPPED_ID_ARRAY = [];
    if (objectToReplace != null && objectToReplace.key === 2) {
      var row = this.fb.group({
        id: [null],
      description: [null],
      descriptionOfReliance: ['', Validators.required],
      version: [null],
      resource: [null],
      businessAsUsual: ['', Validators.required],
      });
      this.resources.insert(objectToReplace.index, row);
    }
    else {
      if (this.resources.controls[this.resources.controls.length - 1] != undefined) {
        if (this.resources.controls[this.resources.controls.length - 1]['controls'].resource.invalid) {
          this.resources.controls[this.resources.controls.length - 1]['controls'].resource.markAsTouched();
          return
        }
      }
      var row = this.fb.group({
        id: [null],
        description: [null],
        descriptionOfReliance: ['', Validators.required],
        version: [null],
        resource: [null],
        businessAsUsual: ['', Validators.required],
      });
      this.resources.push(row);
    }
    if (!noUpdate) { this.updateView(); }
    if (droppedElement != null) {
      row.controls.resource.patchValue(droppedElement);
    }
    for (var i = 0; i < this.resources.controls.length; i++) {
      this.globals.DROPPED_ID_ARRAY.push('list-' + i)
    }

  }

  updateView() {
    this.dataSource.next(this.resources.controls);
  }
  dropFromSearch(event: CdkDragDrop<string[]>, businessAreaRow) {
    this.memberDropped = event.previousContainer.data;

    if (this.memberDropped[0].category.type != CategoryTypes.RESOURCE) {
      return
    }

    if (businessAreaRow.value.resource === null) {
      if (this.memberDropped.length === 1 && this.resources.value[0].resource === null) {
        this.resources.controls[0]['controls'].resource.patchValue(this.memberDropped[0]);
        this.resourceField.patchDataInControls(this.resources.controls[0]['controls'].resource.value);
      }
      else if (this.memberDropped.length === 1 && this.resources.value[this.resources.value.length - 1].resource === null) {
        this.resources.controls.pop();
        this.addRow(false, this.memberDropped[0]);
      }
      else if (this.memberDropped.length > 1 && this.resources.value[0].resource === null) {
        this.resources.controls[0]['controls'].resource.patchValue(this.memberDropped[0]);
        this.resourceField.patchDataInControls(this.resources.controls[0]['controls'].resource.value);
        for (var i = 1; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else if (this.memberDropped.length > 1 && this.resources.value[this.resources.value.length - 1].resource === null) {
        this.resources.controls.pop();
        for (var i = 0; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else {
        this.memberDropped.forEach(droppedElement => {
          if (droppedElement['dragged']) {
            this.addRow(false, droppedElement);
          }
        });
      }
    }

    else {
      if (this.memberDropped.length > 1) {
        this.alertService.error("You can replace single record at a time");
        return
      }
      const index = this.resources.controls.indexOf(businessAreaRow);
      var row = this.resources.controls[index];
      if (row.value.id != null) {
        this.resourcesService.deleteResourcebyId([row.value.id]).subscribe((res) => { });
      }
      this.resources.removeAt(index);
      var memberObject = { key: 2, index: index, memberDropped: this.memberDropped[0], rowDropped: businessAreaRow };
      this.addRow(false, this.memberDropped[0], memberObject);
    }
  }

  deleteRow(index: number, row) {
    const control = this.resourcesForm.get('resources') as FormArray;
    if (this.resources.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      let that = this;
      this.alertService.confirmation("deleteListConfirm",
      function () {
        that.resourcesService.deleteResourcebyId([row.value.id]).subscribe((res) => {
        control.removeAt(index);
        that.updateView();
        that.alertService.success("Successfully Deleted");
      }, err => {
      })
    });

    }
    else if (row.value.id === null) {
      let that = this;
      if (this.resources.at(index).dirty) {
      
        this.alertService.confirmation("deleteListConfirm",
          function () {
            control.removeAt(index);
            that.updateView();
          
            that.alertService.success("Successfully Deleted");
          });
      }
      else {
       
        control.removeAt(index);
        that.updateView();
      }
    }
  }
  clickComplete(btnAction: ButtonActions) {
    this.showLoader();
    this.biaRecord['resourcesComplete'] = true;
    this.resourcesService.saveBiaRecord(this.biaRecord).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('Resource Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      this.biaRecord = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
    });
  }
  onSubmit(btnAction: ButtonActions) {

    if (this.resources.invalid) {
      return
    }
    this.showLoader();

    this.resources.value.forEach(reso => {
      reso['bia'] = this.biaRecord;
      if (Array.isArray(reso.resource)) {
        reso.resource = reso.resource[0];
      }


    });

    this.resourcesService.saveAllBiaResources(this.resources.value).subscribe((res) => {
      this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
      this.hideLoader();
      if (this.routedPageState === 1) {
        this.alertService.success("Successfully Created");
      }
      else {
        this.alertService.success("Successfully Updated")
      }
    }, err => {
      this.hideLoader();
    });
  }
  goBackToMainPage(btnAction: ButtonActions) {
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
  }
}
