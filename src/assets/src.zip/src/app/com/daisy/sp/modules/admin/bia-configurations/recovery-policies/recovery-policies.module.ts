import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RecoveryPoliciesListComponent } from '../recovery-policies/recovery-policies-list/recovery-policies-list.component'
import { RecoveryPoliciesComponent } from './recovery-policies.component';
import { ComponentsModule } from '../../../../common/components/components.module';
import { RecoveryPoliciesFormComponent } from './recovery-policies-form/recovery-policies-form.component';


const routes: Routes = [
  {
    path: '', component: RecoveryPoliciesComponent,
    children: [
      { path: 'recovery-policies-list', component: RecoveryPoliciesListComponent },
      { path: 'recovery-policies-form', component: RecoveryPoliciesFormComponent },

    ]
  }
];
@NgModule({
  declarations: [RecoveryPoliciesComponent, RecoveryPoliciesListComponent, RecoveryPoliciesFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [RecoveryPoliciesComponent]
})
export class RecoveryPoliciesModule { }
