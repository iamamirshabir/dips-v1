import { Component, OnInit } from '@angular/core';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants';
import { PageState } from '../../../../utils/constants/page-state-constants';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { RouteParams } from '../../../../utils/model.route-params';

@Component({
  selector: 'app-contact-group-list',
  templateUrl: './contact-group-list.component.html',
  styleUrls: ['./contact-group-list.component.sass']
})
export class ContactGroupListComponent extends BaseClass implements OnInit {

  private displayedColumns: any;
  private tableButtons: any;
  private filterSelectObj: any = [];
  iListingView: IListingView;
  private contactGroupList: any = [];
  private selectedContactGroupId: number = null;
  private parentGroupId: number = null;
  private displayDeputies: string = '';

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'description', name: 'Description', checked: 'true' },
    { key: 'updatedOn', name: 'Last Updated', checked: 'true' },
    { key: 'rolesString', name: 'Roles' },
    { key: 'deputiesString', name: 'Deputies' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.filterSelectObj = [
      { name: 'Name', columnProp: 'name', options: [] },
      { name: 'Description', columnProp: 'description', options: [] },
      { name: 'Last Updated', columnProp: 'updatedOn', options: [] }];

    let pageParams = this.currentNavigation.extras.state as RouteParams;
    if (pageParams && pageParams.id) {
      this.selectedContactGroupId = pageParams.id;
    }
    this.getContactGroupList(this.selectedContactGroupId);
  }

  setDataTable(tableData) {
    this.iListingView = {
      listTitle: "Contact Group",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ContactListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }

  async getContactGroupList(parent) {
    this.showLoader()
    if (parent) {
      await this.contactGroupService.getContactGroupByParentId(parent).
        subscribe(contactGroupList => {
          if (contactGroupList) {
            this.contactGroupList = contactGroupList;
            this.prepareCommaSepratedValuesNset();
            this.contactGroupList.forEach(element => {
              element.updatedOn = this.setShortDateFormat(element.updatedOn);
            });
            this.setDataTable(this.contactGroupList)
          }
          this.hideLoader();
        }, error => { });
    } else {
      await this.contactGroupService.getContactGroupByParentId(0).
        subscribe(contactGroupList => {
          if (contactGroupList) {
            this.contactGroupList = contactGroupList;
            this.prepareCommaSepratedValuesNset();
            this.contactGroupList.forEach(element => {
              element.updatedOn = this.setShortDateFormat(element.updatedOn);
            });
            this.setDataTable(this.contactGroupList)
          }
          this.hideLoader();
        }, error => { });
    }

  }

  removeContactGroupById(id) {
    this.showLoader()
    this.contactGroupService.removeContactGroupById(id).subscribe(contactgroupheirarchy => {
      this.hideLoader();
      this.alertService.success("Successfully Removed");
      this.getContactGroupList(this.selectedContactGroupId);
    }, error => { this.hideLoader(); });
  }

  chevronMenuClick(chevronMenu: any) {
    if (chevronMenu.btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.removeContactGroupById(chevronMenu.data.id);
        });
    }
    else {
      let routeParams: RouteParams = new RouteParams();
      routeParams.id = chevronMenu.data.id;
      routeParams.parentParams = this.pageParams;
      routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
      if (chevronMenu.btnAction == ButtonActions.VIEW) {
        routeParams.pageState = PageState.VIEW_STATE;
      } else if (chevronMenu.btnAction == ButtonActions.ADD) {
        routeParams.pageState = PageState.ADD_STATE;
      } else if (chevronMenu.btnAction == ButtonActions.EDIT) {
        routeParams.pageState = PageState.EDIT_STATE;
      }
      this.routingService.openPage(routeParams.routerLink, routeParams);
    }
  }

  prepareCommaSepratedValuesNset() {
    var updatedListGroups: any[] = [];
    for (var element of this.contactGroupList) {
      var roles: String = '';
      var deputies: String = '';
      var countRoles: number = 0;
      var countDeputies: number = 0;
      if (element.deputies) {
        for (var deputy of element.deputies) {
          if (countDeputies > 0) {
            deputies = deputies + ", "
          }
          countDeputies = countDeputies + 1;
          deputies = deputies + deputy.firstName + " " + deputy.lastName;
        }
      }
      if (element.contactGroupRoles) {
        for (var role of element.contactGroupRoles) {
          if (countRoles > 0) {
            roles = roles + ", "
          }
          countRoles = countRoles + 1;
          roles = roles + role.name;
        }
      }
      element.rolesString = roles;
      element.deputiesString = deputies;
      updatedListGroups.push(element);
    }
    this.contactGroupList = updatedListGroups;
  }

  deleteAllClick(data) {
    this.showLoader();
    this.contactGroupService.removeAllContactGroups(data).
      subscribe(res => {
        this.hideLoader();
        this.getContactGroupList(this.selectedContactGroupId);
      }, error => {
        this.hideLoader();
      })
  }

  btnDoubleClicked(data) {
    this.selectedContactGroupId = data.id;
    this.getContactGroupList(this.selectedContactGroupId);
  }

  closePage() {
    if (this.selectedContactGroupId && this.selectedContactGroupId > 0) {
      this.getdPreviousRecordByParentId(this.selectedContactGroupId);
    }
  }

  async getdPreviousRecordByParentId(patentID) {
    await this.contactGroupService.getdPreviousRecordByParentId(patentID).
      subscribe(contactGroupList => {
        if (contactGroupList) {
          this.contactGroupList = contactGroupList;
          this.prepareCommaSepratedValuesNset();
          this.setDataTable(this.contactGroupList);
          this.selectedContactGroupId = this.contactGroupList[0].parentId;
        }
        this.hideLoader();
      }, error => { });
  }

  hirarchyView() {
    let routeParams: RouteParams = new RouteParams();
    routeParams.routerLink = RouteConstants.CONTACT_GROUPS_HEIRARCHY
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }

  // for add new contact Group - overrided for base class method
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
    }
    let parentParams: RouteParams = new RouteParams();
    parentParams.id = this.selectedContactGroupId;
    parentParams.routerLink = RouteConstants.CONTACT_GROUPS_LISTING;
    routeParams.parentParams = parentParams;
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }

}