import { NgModule } from '@angular/core'; 
import { ExercisesListComponent } from './exercises-list.component';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule } from '@angular/router';

export const routes = [
  { path: '', component: ExercisesListComponent, pathMatch: 'full' }
];

@NgModule({
  declarations: [ExercisesListComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,    
    RouterModule.forChild(routes)
  ]
})
export class ExercisesListModule { }
