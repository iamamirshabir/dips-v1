import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExercisesPlanningComponent } from './exercises-planning.component';

describe('ExercisesPlanningComponent', () => {
  let component: ExercisesPlanningComponent;
  let fixture: ComponentFixture<ExercisesPlanningComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExercisesPlanningComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExercisesPlanningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
