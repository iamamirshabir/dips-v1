import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { data } from 'dom7';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { RiskstratgiesFormComponent } from '../risk-strategies-form/risk-strategies-form.component';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-risk-strategies-list',
    templateUrl: './risk-strategies-list.component.html',
    styleUrls: ['./risk-strategies-list.component.sass']
})
export class RiskstrategiesListComponent extends BaseClass implements OnInit, AfterViewInit {
    iListingView: IListingView;
    public tableData: any[] = [];
    public displayedColumns: any;
    public tableButtons: any;
    public filterSelectObj: any = [];
    dialogRef: MatDialogRef<RiskstratgiesFormComponent> | null;
    constructor(private router: Router, protected activatedRoute: ActivatedRoute,
        public dialog: MatDialog,) {
        super();
    }

    ngOnInit(): void {
        this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
        { key: 'name', name: 'Strategy Name', checked: 'true' },
        { key: 'description', name: 'Description', checked: 'true' },
        { key: 'action', name: '', checked: 'true' }];

        this.filterSelectObj = [
          {name : 'Strategy Name', columnProp : 'name', option : []},
          {name : 'Description', columnProp : 'description', option : []}  
        ];

        this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
        { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

        this.setDataTable([]);
    }
    ngAfterViewInit() {
        this.getRiskStrategyList();
        this.hideLoader();
    }
    getRiskStrategyList() {
        this.showLoader();
        this.riskStrategiesService.getsaverRiskStrategyLists(this.organisation.id).
            subscribe(res => {
                this.hideLoader();
                this.tableData = res;
                this.setDataTable(this.tableData);
            }, error => {
                this.hideLoader();
                this.tableData = [];
                this.setDataTable(this.tableData);
            })
           
            
    }

    setDataTable(tableData) {
        this.iListingView = {
            listTitle: this.languageTranslator('admin.bia.riskstrategies.title'), 
            displayedColumns: this.displayedColumns,
            dataSource: tableData,
            tableButtons: this.tableButtons,
            pagination: true,
            search: true,
            recordsPerpage: true,
            showSelectAll: true,
            showFilters: true,
            filterSelectObj: this.filterSelectObj,
            chevronMenuClassName: ChevronMenuClassName.RiskStrategiesChevronMenu,
            listObject: new Object
        }
        this.listingViewService.sendListingView(this.iListingView);
    }
    btnDoubleClicked(data) {
        this.openFormHandler(data, PageState.EDIT_STATE);
    }
    openFormHandler(record, pageState) {
        console.log(pageState);
        let data = { "data": record, "pageState": pageState }
        this.dialogRef = this.dialog.open(RiskstratgiesFormComponent, {
            width: '50%',
            disableClose: true,
            hasBackdrop: true,
            data: data
        });
        this.dialogRef.afterClosed().subscribe((result: any) => {
            if (result != null) {
                if (result && result.pageState == this.PageState.ADD_STATE || result.pageState == this.PageState.EDIT_STATE) {
                    this.saveRecord(result.data, result.pageState);
                }
            }
            this.dialogRef = null;
        });
    }
    printClick(data, exportType) {

    }
    chevronMenuClick(chevronMenu: any) {
        let btnAction = chevronMenu.btnAction;
        let data = chevronMenu.data;
        if (btnAction == ButtonActions.EDIT) {
            this.openFormHandler(data, PageState.EDIT_STATE);
        }
        if (btnAction == ButtonActions.DELETE) {
            this.deleteRiskStrategyById(data.id);
        }
        if (btnAction == ButtonActions.VIEW) {
            this.openFormHandler(data, PageState.VIEW_STATE);
        }
    }
    saveRecord(data, pageState) {
        this.showLoader();
        this.riskStrategiesService.saverRiskStrategy(data).subscribe(res => {
            this.hideLoader();
            if (pageState == 1) {
                this.alertService.success("creation.successfull", true);
            }
            else {
                this.alertService.success("updation.successfull", true)
            }
            this.getRiskStrategyList();
        }, error => {
            this.tableData = [];
            this.setDataTable(this.tableData);
        })
    }
    deleteRiskStrategyById(id) {
        this.showLoader();
        let that = this;
        this.alertService.confirmation("deleteListConfirm",
            function () {
                that.riskStrategiesService.deleteRiskStrategyId(id).
                    subscribe(res => {
                        that.hideLoader();
                        that.getRiskStrategyList();
                    }, error => {
                        this.hideLoader();
                    });
            });
    }

    deleteAllClick(data) {
        this.showLoader();
        this.riskStrategiesService.deleteAllRiskStrategy(data).
            subscribe(res => {
                this.hideLoader();
                this.getRiskStrategyList();
            }, error => {
                this.hideLoader();
            })
    }
}
