import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';


@Component({
  selector: 'app-category-business-area-form',
  templateUrl: './category-business-area-form.component.html',
  styleUrls: ['./category-business-area-form.component.sass']
})
export class CategoryBusinessAreaFormComponent extends BaseClass implements OnInit {
  categoryBusinessAreaForm: FormGroup;
  submitted = false;
  securityRoles: any[] = [];
  ButtonActions = ButtonActions;
  routeParams: any;
  subCategories: any;
  categorySupplier: any;
  realEntities: any;
  businessEntitiesObj: any;
  costCentersObj: any;
  @ViewChild('managerContact') managerContact: SpChipFormFieldComponent;
  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  @ViewChild('perspectiveDepartmental') perspectiveDepartmental: SpChipFormFieldComponent;
  @ViewChild('perspectiveLocational') perspectiveLocational: SpChipFormFieldComponent;
  @ViewChild('businessEntities') businessEntities: SpChipFormFieldComponent;
  @ViewChild('costCenters') costCenters: SpChipFormFieldComponent;
  categoryObject: any;
  cat_Supplier_Id: any;
  categoryBusinessAreaObj: any;
  categoryBusinessAreaRealEntityObj: any;
  categoryBusinessAreaInternalOwnerObj: any;
  categoryBusinessAreaAccountManagerObj: any;
  public ARTArray: any;
  public RTOArray: any = [];
  cat_Business_Area_data: any;
  cat_Business_Area_Type: any;
  perspectiveLocationalObj: any;
  perspectiveDepartmentalObj: any;
  artTimeScale: any;
  rtoTimeScale: any;
  hierarchy:string;
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.categoryBusinessAreaForm.controls; }
  ngOnInit(): void {

    this.categoryBusinessAreaForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: [null, [Validators.required]],
      description: [null],
      category: [null],
      categoryName:[null],
      perspectiveDepartmental : [null],
      perspectiveLocational : [null] ,
      rto: [null],
      art: [null],
      owner: [null],
      businessEntities: [null],
      costCenters: [null],
      version: [null]
    });
    this.loadingService.enableLoading();
    this.getRealEntity();
  }
  openFormByState(routeParams) {
    console.log("reciever");
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_Supplier_Id = this.routeParams['id'];
    this.cat_Business_Area_data = this.routeParams['data'];
    if (this.cat_Supplier_Id) {
      this.getCategoryBusinessAreaById(this.cat_Supplier_Id);
    }
    if (this.cat_Business_Area_data) {
      this.cat_Business_Area_Type = this.cat_Business_Area_data['type'];
      this.artTimeScale = this.cat_Business_Area_data['artTimeScale'];
      this.rtoTimeScale = this.cat_Business_Area_data['rtoTimeScale'];
      if (this.artTimeScale != null) {
        this.ARTArray = this.setTimeScalesList(this.artTimeScale.id,TimeScalesConstant.ART_TYPE);
          this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.ART_TYPE)
            this.ARTArray = data.list;
           });
      }
      if (this.rtoTimeScale != null) {
        this.RTOArray = this.setTimeScalesList(this.rtoTimeScale.id,TimeScalesConstant.RTO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.RTO_TYPE)
            this.RTOArray = data.list;
           });
      }
      this.getCategoryByOrgId();
      this.hierarchy = this.cat_Business_Area_data.hierarchy;
      this.categoryBusinessAreaForm.patchValue({ categoryName: this.cat_Business_Area_data.hierarchy });
      this.categoryBusinessAreaForm.controls['category'].setValue(this.cat_Business_Area_data);
    }
  }
  getCategoryBusinessAreaById(id) {
    this.showLoader();
    this.categoryBusinessAreaService.getCategoryBusinessAreaById(id).subscribe(data => {
      this.hideLoader();
      this.categoryObject = data;
      this.patchFormData();
    }, error => {
      this.hideLoader();
    })
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.duration === f2.duration;
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.ownerContact.patchDataInControls(this.categoryBusinessAreaForm.controls['owner']);
      this.businessEntities.patchDataInControls(this.categoryBusinessAreaForm.controls['businessEntities']);
      this.costCenters.patchDataInControls(this.categoryBusinessAreaForm.controls['costCenters']);
      this.perspectiveLocational.patchDataInControls(this.categoryBusinessAreaForm.controls['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryBusinessAreaForm.controls['perspectiveDepartmental']);
    } else {
      this.costCenters.patchDataInControls(this.categoryObject['costCenters']);
      this.businessEntities.patchDataInControls(this.categoryObject['businessEntities']);
      this.ownerContact.patchDataInControls(this.categoryObject['owner']);
      this.perspectiveLocational.patchDataInControls(this.categoryObject['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryObject['perspectiveDepartmental']);
      this.bindJsonObjectToFormObject(this.categoryObject, this.categoryBusinessAreaForm);
    }
  }
  getCategoryByOrgId() {
    this.showLoader();
    this.categoryBusinessAreaService.getSubCategories(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.subCategories = data;
      let SubCatObj = this.subCategories.find(item => (item.type == this.cat_Business_Area_Type));
      if (SubCatObj != undefined) {
        this.categoryBusinessAreaForm.controls['categoryName'].setValue(SubCatObj.name);
      }
    }, error => {
      this.hideLoader();
    })
  }


  getCategoryBusinessAreaByOrgId() {
    this.showLoader();
    this.categoryBusinessAreaService.getCategoryBuisnessAreaByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.categorySupplier = data;
    }, error => {
      this.hideLoader();
    })
  }
  getRealEntity() {
    this.showLoader();
    this.categoryBusinessAreaService.getRealEntityByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.realEntities = data;
    }, error => {
      this.hideLoader();
    })
  }

  getBusinessEntityByOrgId() {
    this.showLoader();
    this.categoryBusinessAreaService.getBusinessEntityByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.businessEntitiesObj = data;
    }, error => {
      this.hideLoader();
    })
  }


  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.categoryBusinessAreaForm.invalid) {
      return;
    }
    this.categoryBusinessAreaForm.controls['organisation'].setValue(this.organisation);
    this.showLoader();
    this.categoryBusinessAreaInternalOwnerObj = Array.isArray(this.categoryBusinessAreaForm.value.owner) ? this.categoryBusinessAreaForm.value.owner[0] : this.categoryBusinessAreaForm.value.owner;
    this.perspectiveLocationalObj =  this.categoryBusinessAreaForm.value.perspectiveLocational;
    this.perspectiveDepartmentalObj = this.categoryBusinessAreaForm.value.perspectiveDepartmental; 

    this.categoryBusinessAreaForm.controls['perspectiveLocational'].setValue(this.perspectiveLocationalObj);
    this.categoryBusinessAreaForm.controls['perspectiveDepartmental'].setValue(this.perspectiveDepartmentalObj);
    this.categoryBusinessAreaForm.controls['owner'].setValue(this.categoryBusinessAreaInternalOwnerObj);
    this.categoryBusinessAreaService.saveCategoryBusinessArea(this.categoryBusinessAreaForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        }
        // else if (btnType == ButtonActions.SAVE_AND_CONT) {
        //   this.contactObject = res;
        //   this.routedPageState = PageState.EDIT_STATE;
        //   this.patchFormData();
        // }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CATEGORY_BUSINESS_AREA_LIST);
  }

}
