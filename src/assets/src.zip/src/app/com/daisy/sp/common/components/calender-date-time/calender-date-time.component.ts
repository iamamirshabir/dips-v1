import { Component, Input, OnInit } from '@angular/core';
import { DateAdapter } from '@angular/material/core';
import { BaseClass } from '../../../utils/baseclass';

@Component({
  selector: 'app-calender-date-time',
  templateUrl: './calender-date-time.component.html',
  styleUrls: ['./calender-date-time.component.sass']
})
export class CalenderDateTimeComponent extends BaseClass implements OnInit {
  @Input() formControlCalender;
  @Input() formGroupCalender;
  @Input() label: string;

  constructor(private dateAdapter: DateAdapter<Date>) {
    super();
    const localeName = this.organisation.language.localeName;
    this.dateAdapter.setLocale(localeName);
  }

  ngOnInit(): void { }

}
