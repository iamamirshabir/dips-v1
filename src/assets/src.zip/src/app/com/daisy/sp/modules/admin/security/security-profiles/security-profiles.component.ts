import { Component, OnInit } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-security-profiles',
  templateUrl: './security-profiles.component.html',
  styleUrls: ['./security-profiles.component.sass']
})

export class SecurityProfilesComponent extends BaseClass implements OnInit {

  constructor() {
    super();
   }

  ngOnInit(): void {}

}
