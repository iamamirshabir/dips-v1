import { AfterViewInit, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { EmployeeTypeFormComponent } from '../employee-type-form/employee-type-form.component';

@Component({
  selector: 'app-employee-type-list',
  templateUrl: './employee-type-list.component.html',
  styleUrls: ['./employee-type-list.component.sass']
})
export class EmployeeTypeListComponent extends BaseClass implements OnInit, AfterViewInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  dialogRef: MatDialogRef<EmployeeTypeFormComponent> | null;


  constructor(private router: Router, protected activatedRoute: ActivatedRoute, private cd: ChangeDetectorRef, public dialog: MatDialog) {
    super();
  }
  ngOnInit(): void {

    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'type', name: 'Type', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [
      { "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
      { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', options: [] },
    { name: 'Type', columnProp: 'type', options: [] }]

    this.setDataTable([]);

  }
  ngAfterViewInit() {
    this.getEmployeeTypeList();
    this.hideLoader();
  }
  getEmployeeTypeList() {
    this.showLoader();
    this.employeeTypeService.getEmployeeTypeList(this.organisation.id).
      subscribe(employeeType => {
        if (employeeType) {
          employeeType.forEach(element => {
            if (element.biaType == true && element.contactType == true) {
              element.type = "Contact/BIA"
            } else {
              if (element.biaType == true) {
                element.type = "BIA"
              } else if (element.contactType == true) {
                element.type = "Contact"
              } else {
                element.type = "None"
              }
            }
          });
          this.tableData = employeeType;
        } else {
          this.tableData = [];
        }
        this.hideLoader();

        this.setDataTable(this.tableData);
      }, error => {
        this.hideLoader();
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.configurations.contacts.employee.type'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.EmployeeTypeListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, PageState.EDIT_STATE);
  }
  openFormHandler(record, pageState) {
    let data = { "data": record, "pageState": pageState }
    this.dialogRef = this.dialog.open(EmployeeTypeFormComponent, {
      width: '600px',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });

    this.dialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.pageState == this.PageState.ADD_STATE || result.pageState == this.PageState.EDIT_STATE) {
        this.saveRecord(result.data);
      }
      this.dialogRef = null;
    });
  }

  saveRecord(data) {
    this.showLoader();
    data.organisation = this.organisation;
    data.contactType = data.typeGroup.contactType;
    data.biaType = data.typeGroup.biaType;
    this.employeeTypeService.saveEmployeeType(data).subscribe(res => {
      this.hideLoader();
      this.alertService.success('Successfully Updated');
      this.getEmployeeTypeList();
    }, error => {
      this.hideLoader();
    })
  }

  printClick(data) {

  }
  deleteAllClick(data) {
    this.showLoader();
    this.employeeTypeService.deleteAllEmployeeType(data).
      subscribe(res => {
        this.alertService.success("deleteOne.successfull", true);
        this.hideLoader();
        this.getEmployeeTypeList();
      }, error => {
        this.hideLoader();
      })
  }
  deleteEmployeeTypeById(id) {
    this.showLoader();
    this.employeeTypeService.deleteEmployeeTypeById(id).
      subscribe(res => {
        this.alertService.success("deleteOne.successfull", true);
        this.hideLoader();
        this.getEmployeeTypeList();
      }, error => {
        this.hideLoader();
      })
  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteEmployeeTypeById(data.id);
        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }
}
