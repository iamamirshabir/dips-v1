import { Component, OnInit, Inject } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';

@Component({
  selector: 'app-analysis-colors-form',
  templateUrl: './analysis-colors-form.component.html',
  styleUrls: ['./analysis-colors-form.component.sass']
})
export class AnalysisColorsFormComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RealEntityFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
  }
  public ngOnInit(): void {
    this.modalFormFroup = this.fb.group({
      id: [null],
      name: [null, [Validators.required]],
      colour: ["#000000", [Validators.required]],
      order: [null],
      organisation: [this.organisation],
      version: [null]
    });
    if (this.modalData) {
      if (this.modalData) {
        this.modalFormFroup.patchValue(this.modalData.data);
        if (this.modalData.pageState === this.PageState.VIEW_STATE) {
          this.modalFormFroup.disable();
        }
      }
    }
  }

  saveFormData(): void {
    if (this.modalFormFroup.invalid) {
      return;
    }
    this.modalData.data = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }
}