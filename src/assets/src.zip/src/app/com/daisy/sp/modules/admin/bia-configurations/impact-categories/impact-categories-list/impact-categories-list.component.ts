
import { Component, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { RouteParams } from '../../../../../utils/model.route-params';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { ImpactcategoriesFormComponent } from '../impact-categories-form/impact-categories-form.component';
import { TranslateService } from '@ngx-translate/core';


@Component({
    selector: 'app-impact-categories-list',
    templateUrl: './impact-categories-list.component.html',
    styleUrls: ['./impact-categories-list.component.sass']
})
export class ImpactcategoriesListComponent extends BaseClass implements OnInit, AfterViewInit {
    iListingView: IListingView;
    public tableData: any[] = [];
    public displayedColumns: any;
    public tableButtons: any;
    public filterSelectObj: any = [];
    dialogRef: MatDialogRef<ImpactcategoriesFormComponent> | null;
    myOrganisation: any;
    constructor(private router: Router, protected activatedRoute: ActivatedRoute,
        public dialog: MatDialog) {
        super();
    }

    ngOnInit(): void {
        this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
        { key: 'name', name: 'Name', checked: 'true' },
        { key: 'description', name: 'Description', checked: 'true' },
        { key: 'action', name: '', checked: 'true' }];
        
        this.filterSelectObj = [{name : 'Name', columnProp : 'name', option : []},
        {name : 'Description', columnProp : 'description', option : []},

    ];
        this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
        { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

        this.setDataTable([]);
    }
    ngAfterViewInit() {

        this.getImpactcategoryList();
        this.hideLoader();

    }
    getImpactcategoryList() {
        this.showLoader();
        this.impactcategoriesService.getsavedImpactCategoryLists(this.organisation.id).
            subscribe(res => {
                this.hideLoader();
                this.tableData = res;
                this.setDataTable(this.tableData);
            }, error => {
                this.hideLoader();
                this.tableData = [];
                this.setDataTable(this.tableData);
            })
    }

    setDataTable(tableData) {
        this.iListingView = {
            listTitle: this.languageTranslator('admin.bia.impactcategories.title'),
            displayedColumns: this.displayedColumns,
            dataSource: tableData,
            tableButtons: this.tableButtons,
            pagination: true,
            search: true,
            recordsPerpage: true,
            showSelectAll: true,
            showFilters: true,
            filterSelectObj: this.filterSelectObj,
            chevronMenuClassName: ChevronMenuClassName.ImpactCategoriesChevronMenu,
            listObject: new Object
        }
        this.listingViewService.sendListingView(this.iListingView);
    }
    btnDoubleClicked(data) {
        this.openFormHandlerForImpactLevel(data, PageState.EDIT_STATE);
    }
    openFormHandlerForImpactLevel(data = null, pageState) {
        let routeParams: RouteParams = new RouteParams();
        if (data) {
            routeParams.id = data['id'];
        }
        routeParams.pageState = pageState;
        routeParams.routerLink = RouteConstants.BIA_CONFIG_IMPACT_LEVELS_LIST;
        this.routingService.openPage(routeParams.routerLink, routeParams);
    }
    openFormHandler(record, pageState) {
        let data = { "data": record, "pageState": pageState }
        this.dialogRef = this.dialog.open(ImpactcategoriesFormComponent, {
            width: '50%',
            disableClose: true,
            hasBackdrop: true,
            data: data
        });
        this.dialogRef.afterClosed().subscribe((result: any) => {
            if (result == null) {
                return
            }
            let resultData = result.data;
            if (result && result.pageState == this.PageState.ADD_STATE) {
                resultData.organisation = this.organisation;
                resultData.order = 0;
                this.saveRecord(resultData);
            } else if (result && result.pageState == this.PageState.EDIT_STATE) {
                this.saveRecord(resultData);
            }
            this.dialogRef = null;
        });
    }
    printClick(data, exportType) {

    }
    chevronMenuClick(chevronMenu: any) {
        let btnAction = chevronMenu.btnAction;
        let data = chevronMenu.data;
        if (btnAction == ButtonActions.EDIT) {
            this.openFormHandler(data, PageState.EDIT_STATE);
        }
        if (btnAction == ButtonActions.DELETE) {
            let that = this;
            this.alertService.confirmation("deleteOneConfirm",
                function () {
                    that.deleteImpactcategoryById(data.id);
                });

        }
        if (btnAction == ButtonActions.VIEW) {
            this.openFormHandler(data, PageState.VIEW_STATE);
        }
        if (btnAction == ButtonActions.OPEN_IMPACT_LEVELS) {
            this.openFormHandlerForImpactLevel(data, PageState.EDIT_STATE);

        }
    }

    saveRecord(data) {
        this.showLoader();
        if (data.id) {
            this.impactcategoriesService.saverImpactCategory(data).subscribe(res => {
                this.hideLoader();
                this.alertService.success('updation.successfull', true);
                this.getImpactcategoryList();
            }, error => {
                this.hideLoader();
            })
        } else {
            this.impactcategoriesService.saverImpactCategory(data).subscribe(res => {
                this.hideLoader();
                this.alertService.success('creation.successfull', true);
                this.getImpactcategoryList();
            }, error => {
                this.hideLoader();
            })
        }
    }

    deleteImpactcategoryById(id) {
        this.showLoader();
        this.impactcategoriesService.deleteImpactCategoryId(id).
            subscribe(res => {
                this.hideLoader();
                this.getImpactcategoryList();
            }, error => {
                this.hideLoader();
            })
    }

    deleteAllClick(data) {
        console.log("data", data)
        this.showLoader();
        this.impactcategoriesService.deleteAllImpactCategory(data).
            subscribe(res => {
                this.hideLoader();
                this.getImpactcategoryList();
            }, error => {
                this.hideLoader();
            })
    }
}
