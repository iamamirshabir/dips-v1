import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ProcessesService {

  constructor(private router : Router,private httpClient: HttpClient){}

  saveProcess(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_PROCESS_SAVE}`,data);
  } 

  getProcessLists(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_PROCESS_LIST_BY_ID+id);
  } 

  deleteProcessbyId(id){
    return this.httpClient.delete<any>(`${environment.baseUrl}`+Api.BIA_PROCESS_REMOVE_BY_ID+id);
  }
  deleteAllProcess(id): Observable<any> {
    return this.httpClient.post<any>(`${environment.baseUrl+Api.BIA_PROCESS_REMOVE_ALL}`, id);
  }
  saveBiaRecord(biaRecord): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
}
}