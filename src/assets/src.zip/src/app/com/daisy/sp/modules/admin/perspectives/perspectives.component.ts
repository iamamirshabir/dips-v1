import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perspectives',
  templateUrl: './perspectives.component.html',
  styleUrls: ['./perspectives.component.sass']
})
export class PerspectivesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
