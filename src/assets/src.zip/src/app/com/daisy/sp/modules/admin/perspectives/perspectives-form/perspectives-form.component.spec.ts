import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerspectivesFormComponent } from './perspectives-form.component';

describe('PerspectivesFormComponent', () => {
  let component: PerspectivesFormComponent;
  let fixture: ComponentFixture<PerspectivesFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PerspectivesFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PerspectivesFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
