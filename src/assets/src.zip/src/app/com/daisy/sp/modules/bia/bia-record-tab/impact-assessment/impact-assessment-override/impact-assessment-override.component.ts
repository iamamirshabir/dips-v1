import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';


@Component({
  selector: 'app-impact-assessment-override',
  templateUrl: './impact-assessment-override.component.html',
  styleUrls: ['./impact-assessment-override.component.sass']
})
export class ImpactAssessmentOverrideComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  selectedRTO: any;
  public RTOTimeScales: String = "";
  RtoObject: any;
  public timeScalesRTOArray: any = [];
  rtoList: any = [];
  mtpdList:any =[];
  rtoId: any;
  mtpdValidator:boolean = false;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ImpactAssessmentOverrideComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
    console.log("modelData", this.modalData);
  }
  get f() { return this.modalFormFroup.controls; }

  public ngOnInit(): void {
    this.modalFormFroup = this.fb.group({
      id: [null],
      order: [null],
      organisation: [null],
      version: [null],
      override_reason: [null],
      rto: [null],
      mtpd:[null],
      manualOverride:[null]


    });

    if (this.modalData) {
      let categoryRecord = this.modalData.bia['categoryRecord'];
      if (categoryRecord['category']) {
        let categoryData = categoryRecord['category'];
        if (categoryData['rtoTimeScale']) {
          let rtoTimeScale = categoryData['rtoTimeScale'];
          this.rtoId = rtoTimeScale['id'];
          this.rtoList = this.setTimeScalesList(this.rtoId, TimeScalesConstant.RTO_TYPE);
          this.getTimeScalesList().subscribe(
            (data) => {
              if(data){
                if (data.type == TimeScalesConstant.RTO_TYPE)
                this.rtoList = data.list;
              }
              
            });
        }
      }
      this.modalFormFroup.controls['manualOverride'].setValue(false);
     if(this.modalData.impactAssessment != null){
      this.modalFormFroup.patchValue(this.modalData.impactAssessment);
      if(this.modalData.impactAssessment['manualOverride'] ==  null){
        this.modalFormFroup.controls['manualOverride'].setValue(false);
      }
     }
  
    }

    this.modalFormFroup.get("rto").valueChanges.subscribe(x => {
      this.selectMTPD( this.modalFormFroup['controls']['mtpd'].value);
   })
  }


  saveFormData(): void {
    if (this.modalFormFroup.invalid) {
      return;
    }
    if(  this.mtpdValidator == true){
      return
    }
    this.modalData = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }


  compareObjects(o1: any, o2: any): boolean {
    return o1.name === o2.name && o1.id === o2.id;
  }
  selectMTPD(value){
    if(value !== null ){
      if(value['timeInMinutes'] <= this.modalFormFroup.controls['rto'].value['timeInMinutes']){
        this.mtpdValidator = true;
      }
      else{
       this.mtpdValidator = false;
      }
    }
  }

}