
import { Component, OnInit, ViewChild, ViewChildren, ElementRef } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormArray, AbstractControl } from '@angular/forms';
import { LoaderService } from 'src/app/core-services/loader.service';
import { BaseClass } from '../../../../utils/baseclass';
import { ActivatedRoute, Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { SpChipFormFieldComponent } from '../../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { PageState } from '../../../../utils/constants/page-state-constants';
import { Location } from '@angular/common';
import { BehaviorSubject } from 'rxjs';
import { MatTable } from '@angular/material/table';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { RouteConstants } from '../../../../utils/constants/route-constants';


@Component({
  selector: 'app-contact-group-form',
  templateUrl: './contact-group-form.component.html',
  styleUrls: ['./contact-group-form.component.sass']
})

export class ContactGroupFormComponent extends BaseClass implements OnInit {

  value: any;
  contactgroupForm: FormGroup;
  contactGroup: any;
  parentId: any;
  @ViewChild('deputies') deputies: SpChipFormFieldComponent;
  @ViewChild('owner') owner: SpChipFormFieldComponent;
  @ViewChild('table') table: MatTable<any>;
  displayColumns = ['#', 'name', 'members', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);

  constructor(private formBuilder: FormBuilder, private loadingService: LoaderService,
    private router: Router, protected activatedRoute: ActivatedRoute,
    private location: Location) {
    super();
    this.activateRoute.queryParams.subscribe(val => {
      this.initializePageData();
    })
  }
  get f() { return this.contactgroupForm.controls; }
  initializePageData() {
    this.contactgroupForm = this.formBuilder.group({
      id: [null],
      name: ['', Validators.required],
      description: [''],
      contactGroupRoles: this.formBuilder.array([]),
      deputies: [null, Validators.required],
      owner: [null, Validators.required],
      version: [null],
      parentId: [0],
      organisation: [null],
    });
  }

  ngOnInit(): void { }

  openPageInAddState(pageParams) {
    this.routedPageState = this.pageParams['pageState'];
    this.setParentId(pageParams);
    this.addMemberFormGroup();
    this.hideLoader();
  }

  openPageInEditState(pageParams) {
    this.routedPageState = this.pageParams['pageState'];
    this.setParentId(pageParams)
    this.loadPageData(pageParams);
  }

  openPageInViewState(pageParams) {
    this.setParentId(pageParams)
    this.loadPageData(pageParams);
  }

  setParentId(pageParams) {
    this.parentId = pageParams.parentParams && pageParams.parentParams.id ? pageParams.parentParams.id : 0;
  }

  loadPageData(data) {
    this.contactGroupService.getContactGroupById(data.id).
      subscribe(data => {
        this.contactGroup = data;
        if (this.contactGroup.contactGroupRoles && this.contactGroup.contactGroupRoles.length > 0) {
          this.contactGroup.contactGroupRoles.sort((a, b) => a.priority - b.priority);
        }
        // this.contactGroup.contactGroupRoles = this.contactGroup.contactGroupRoles.sort((a, b) => a.priority - b.priority);
        this.owner.patchDataInControls(this.contactGroup['owner']);
        this.deputies.patchDataInControls(this.contactGroup['deputies']);
        this.patchFormValues()
      }, error => { })
  }

  patchFormValues() {
    if (this.contactGroup.contactGroupRoles.length > 0) {
      this.contactGroup.contactGroupRoles.forEach(element => {
        this.addMemberFormGroup();
      });
    }
    else {
      this.addMemberFormGroup();
    }
    this.contactgroupForm.patchValue(this.contactGroup);
    this.hideLoader();
  }
  public addMemberFormGroup() {
    const members = <FormArray>this.contactgroupForm.controls['contactGroupRoles'];
    members.push(this.createMemberFormGroup());
    this.updateView();
  }
  roles(): FormArray {
    return this.contactgroupForm.get("contactGroupRoles") as FormArray
  }

  public createMemberFormGroup(): FormGroup {
    let contactGroupRoles = this.contactgroupForm.get("contactGroupRoles") as FormArray;
    return this.formBuilder.group({
      id: [null],
      priority: [contactGroupRoles.controls.length + 1],
      name: ['', Validators.required],
      members: [null, Validators.required],
    })

  }

  dropTable(event: CdkDragDrop<any[]>) {
    let contactGroupRoles = this.contactgroupForm.get("contactGroupRoles") as FormArray;
    const prevIndex = contactGroupRoles.controls.findIndex((d) => d === event.item.data);
    moveItemInArray(contactGroupRoles.controls, prevIndex, event.currentIndex);
    this.table.renderRows();
    this.setSortOrder(contactGroupRoles.controls, 'priority');
  }
  updateView() {
    let contactGroupRoles = this.contactgroupForm.get("contactGroupRoles") as FormArray
    this.dataSource.next(contactGroupRoles.controls);
  }

  deleteRow(index: number, row) {
    const control = this.contactgroupForm.get('contactGroupRoles') as FormArray;
    if (control.length === 0) {
      this.addMemberFormGroup();
    }
    if (row.value.id != null) {
      control.removeAt(index);
      this.updateView();
      this.alertService.success("Successfully Deleted");
    }
    else {
      control.removeAt(index);
      this.updateView();
    }
  }
  onSubmit(buttonAction) {
    if (this.contactgroupForm.invalid) {
      return;
    }
    let formData = this.contactgroupForm.value;
    formData.owner = this.owner.members ? this.owner.members[0] : null
    if (this.pageParams.pageState == PageState.ADD_STATE) {
      formData['organisation'] = this.organisation;
      formData['parentId'] = this.parentId;
    }
    this.contactGroupService.saveContactGroup(formData).
      subscribe(data => {
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (buttonAction == ButtonActions.SAVE) {
          this.goBackToMainPage();
        }
        else if (buttonAction == ButtonActions.SAVE_AND_CONT) {
         // this.routedPageState = PageState.EDIT_STATE;
          this.navigationHandlerAfterSave(buttonAction, data);
        }
    
      }, error => {
        console.log(error)
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CONTACT_GROUPS_LISTING);
  }

}