export interface ExpandListingView {
  listTitle: string;
  pagination: boolean;
  search: boolean;
  recordsPerpage: boolean;
  displayedColumns: Array<Object>;
  expandableColumns: Array<Object>;
  dataSource: Array<Object>;
  tableButtons: Array<any>;
  showSelectAll: boolean;
  showFilters: boolean;
  filterSelectObj: Array<any>;
  chevronMenuClassName: any;
  listObject: Object;
  expandable:boolean;


}