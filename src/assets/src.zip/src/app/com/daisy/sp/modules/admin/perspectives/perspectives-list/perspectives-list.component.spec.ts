import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerspectivesListComponent } from './perspectives-list.component';

describe('PerspectivesListComponent', () => {
  let component: PerspectivesListComponent;
  let fixture: ComponentFixture<PerspectivesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PerspectivesListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PerspectivesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
