import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RealEntityFormComponent } from './real-entity-form.component';

describe('RealEntityFormComponent', () => {
  let component: RealEntityFormComponent;
  let fixture: ComponentFixture<RealEntityFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RealEntityFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealEntityFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
