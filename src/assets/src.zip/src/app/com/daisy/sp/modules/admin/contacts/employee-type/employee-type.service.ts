import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class EmployeeTypeService {

  constructor(private router : Router,private httpClient: HttpClient) { }
  
  saveEmployeeType(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.EMPLOYEE_TYPE_SAVE}`,data);
  }

  saveAllEmployeeType(employeTypes){
    return this.httpClient.post(`${environment.baseUrl+Api.EMPLOYEE_TYPE_SAVE_ALL}`,employeTypes);
  }

  getEmployeeTypeById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.EMPLOYEE_TYPE_FIND_BY_ID+"/"+id);
  }

  getEmployeeTypeList(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.EMPLOYEE_TYPE_FIND_BY_ORGANISATION_ID+id);
  }
  
  deleteAllEmployeeType(employeTypes){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.EMPLOYEE_TYPE_DELETE,employeTypes);
  }

  deleteEmployeeTypeById(id){
    return this.httpClient.delete<any>(`${environment.baseUrl}`+Api.EMPLOYEE_TYPE_DELETE_BY_ID+id);
  }

}
