import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysisColorsFormComponent } from './analysis-colors-form.component';

describe('AnalysisColorsFormComponent', () => {
  let component: AnalysisColorsFormComponent;
  let fixture: ComponentFixture<AnalysisColorsFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnalysisColorsFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalysisColorsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
