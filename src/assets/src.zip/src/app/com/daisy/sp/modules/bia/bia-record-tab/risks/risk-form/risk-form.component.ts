import { CONTROL } from '@angular/cdk/keycodes';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';

@Component({
  selector: 'app-risk-form',
  templateUrl: './risk-form.component.html',
  styleUrls: ['./risk-form.component.sass']
})
export class RiskFormComponent extends BaseClass implements OnInit, OnDestroy {
  public riskForm: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  riskStrategies: any;
  risklevelsImpacts: any;
  risklevelsLikelihood: any;
  likelihoods: any;
  riskObj: any;


  constructor(private fb: FormBuilder, public dialog: MatDialog, public dialogRef: MatDialogRef<RiskFormComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.initialiseFormData();
    this.getPrePopulatedDataByOrganisationId();
    this.modalData = data;
  }
  get f() { return this.riskForm.controls; }

  ngOnInit() {

    if (this.modalData) {
      this.riskForm.controls['ref'].disable();
      this.riskForm.controls['closedDate'].disable();
      this.riskForm.patchValue(this.modalData.data);
    }

  }
  initialiseFormData() {
    this.riskForm = this.fb.group({
      id: [null],
      name: [null, Validators.required],
      description: [null],
      dateLogged: [new Date(), Validators.required],
      riskStrategy: [null, Validators.required],
      riskScore: [null],
      status: [false],
      owner: [null],
      controls: [null],
      targetDate: [null],
      impact: [null],
      likelihood: [null],
      remedialAction: [null],
      comments: [null],
      version: [null],
      bia: [null],
      closedDate: [null],
      ref: ['']
    });
  }

  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  compareFnCategory: ((f1: any, f2: any) => boolean) | null = this.compareByValueCategory;
  compareByValueCategory(f1: any, f2: any) {
    return f1 && f2 && f1.category === f2.category;
  }
  formChanged() {
    this.wasFormChanged = true;
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  saveFormData(): void {
    if (this.riskForm.invalid) {
      Object.keys(this.riskForm.controls).forEach(field => {
        const control = this.riskForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      return;
    }

    this.modalData.data = this.riskForm.value;
    this.dialogRef.close(this.modalData);
  }

  getPrePopulatedDataByOrganisationId() {
    this.showLoader();

    this.biaRiskService.getRiskStrategies(this.organisation.id).subscribe(data => {
      this.riskStrategies = data;
    }, error => { });

    this.biaRiskService.getRisklevels(this.organisation.id).subscribe(data => {
      
      this.risklevelsImpacts = data.riskLevel.filter(level => level.levelType === 1);
      this.risklevelsLikelihood = data.riskLevel.filter(level => level.levelType === 2);
    }, error => { });

    this.hideLoader();
  }
  selectImpact(impValue) {
    if (this.riskForm.controls['likelihood'].value == null) {
      this.riskForm.controls['riskScore'].setValue(impValue.value * 0);
    }
    else {
      this.riskForm.controls['riskScore'].setValue(impValue.value * this.riskForm.controls['likelihood'].value.value);
    }
  }
  selectLikelihood(likValue) {
    if (this.riskForm.controls['impact'].value == null) {
      this.riskForm.controls['riskScore'].setValue(likValue.value * 0);
    }
    else {
      this.riskForm.controls['riskScore'].setValue(likValue.value * this.riskForm.controls['impact'].value.value);
    }

  }
}
