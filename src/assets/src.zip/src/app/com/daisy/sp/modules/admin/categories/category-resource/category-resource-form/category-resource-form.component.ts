import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { isArray } from 'rxjs/internal-compatibility';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';

@Component({
  selector: 'app-category-resource-form',
  templateUrl: './category-resource-form.component.html',
  styleUrls: ['./category-resource-form.component.sass']
})
export class CategoryResourceFormComponent extends BaseClass implements OnInit {
  categoryResourceForm: FormGroup;
  submitted = false;
  securityRoles: any[] = [];
  ButtonActions = ButtonActions;
  routeParams: any;
  categoryResId: any;
  subCategories: any;
  rtoList: any[];
  public categoryResourceObject: any;
  categorySupplier: any;
  realEntities: any;
  public ARTdurationString: any = [];
  public ARPdurationString: any = [];
  public ARTArray: any = [];
  public ARPArray: any = [];
  timeScales: any = [];
  isPooledYes:boolean = false;
  isPooledNo:boolean = false;
  value = null;
  @ViewChild('perspectiveDepartmental') perspectiveDepartmental: SpChipFormFieldComponent;
  @ViewChild('perspectiveLocational') perspectiveLocational: SpChipFormFieldComponent;
  cat_Resource_data: any;
  cat_Resource_type: any;
  perspectiveLocationalObj: any;
  perspectiveDepartmentalObj: any;
  artTimeScale: any;
  arpTimeScale: any;
  hierarchy:string;
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.categoryResourceForm.controls; }
  ngOnInit(): void {
    
    this.categoryResourceForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: [null, [Validators.required]],
      description: [null],
      rto:[null],
      categoryName:[null],
      category: [null],
      pooled: [null],
      perspectiveDepartmental : [null],
      perspectiveLocational : [null],
      art: [null],
      arp: [null],
      version: [null]
    });

    this.loadingService.enableLoading();
    this.getRealEntity();
  }
  openFormByState(routeParams) {
    let that = this;
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.categoryResId = this.routeParams.id;
    this.cat_Resource_data = this.routeParams['data'];
    if (this.categoryResId) {
      that.getCategoryResById();
    }
    if( this.cat_Resource_data){
      this.cat_Resource_type = this.cat_Resource_data['type'];
      this.artTimeScale = this.cat_Resource_data['artTimeScale'];
      this.arpTimeScale = this.cat_Resource_data['arpTimeScale'];
      if (this.artTimeScale != null) {
        this.ARTArray = this.setTimeScalesList(this.artTimeScale.id,TimeScalesConstant.ART_TYPE);
          this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.ART_TYPE)
            this.ARTArray = data.list;
           }
      );
      }
      if (this.arpTimeScale != null) {
        this.ARPArray = this.setTimeScalesList(this.arpTimeScale.id,TimeScalesConstant.ARP_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.ARP_TYPE)
            this.ARPArray = data.list;
           } );
       }
      this.getCategoryByOrgId();
      this.hierarchy = this.cat_Resource_data.hierarchy;
      this.categoryResourceForm.controls['category'].setValue(this.cat_Resource_data.hierarchy);
    }
  }
  getCategoryResById() {
    this.showLoader();
    this.categoryResourceService.getCategoryResourceById(this.categoryResId).subscribe((res) => {
      this.categoryResourceObject = res;
            this.categoryResourceForm.patchValue(this.categoryResourceObject);
      this.patchFormData();
      this.hideLoader();
          }, err => {
    })
  }

  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.duration === f2.duration;
  }

  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.perspectiveLocational.patchDataInControls(this.categoryResourceForm.controls['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryResourceForm.controls['perspectiveDepartmental']);
     
    } else {
      this.perspectiveLocational.patchDataInControls(this.categoryResourceObject['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryResourceObject['perspectiveDepartmental']);
      this.bindJsonObjectToFormObject(this.categoryResourceObject, this.categoryResourceForm);
    }
  }   
  getCategoryByOrgId() {
    this.showLoader();
    this.categoryResourceService.getSubCategories(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.subCategories = data;
      let SubCatObj =this.subCategories.find(item =>(item.type == this.cat_Resource_type));
     if(SubCatObj != undefined){
      this.categoryResourceForm.controls['categoryName'].setValue(SubCatObj.name);
     }
    }, error => {
      this.hideLoader();
    })
  }

  getRealEntity() {
    this.showLoader();
    this.realEntityService.getPerspectivesListByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      let real = data['children'];
      this.realEntities = data;
    }, error => {
      this.hideLoader();
    })
  }

  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.categoryResourceForm.invalid) {
      return;
    }
  
    this.perspectiveLocationalObj =  this.categoryResourceForm.value.perspectiveLocational;
    this.perspectiveDepartmentalObj =  this.categoryResourceForm.value.perspectiveDepartmental;

    this.categoryResourceForm.controls['perspectiveLocational'].setValue(this.perspectiveLocationalObj);
    this.categoryResourceForm.controls['perspectiveDepartmental'].setValue(this.perspectiveDepartmentalObj);
    this.categoryResourceForm.value['organisation'] = this.organisation;
    this.showLoader();
    this.categoryResourceService.saveCategoryResource(this.categoryResourceForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        }
        
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CATEGORY_RESOURCE_LIST);
  }
}
