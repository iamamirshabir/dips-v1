import { Component, OnInit } from '@angular/core';
import { BaseClass } from '../../utils/baseclass'

@Component({
  selector: 'app-bia',
  templateUrl: './bia.component.html',
  styleUrls: ['./bia.component.sass']
})
export class BIAComponent extends BaseClass implements OnInit {

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.hideLoader();
  }

}
