import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExercisesReportingComponent } from './exercises-reporting.component';

describe('ExercisesReportingComponent', () => {
  let component: ExercisesReportingComponent;
  let fixture: ComponentFixture<ExercisesReportingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExercisesReportingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExercisesReportingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
