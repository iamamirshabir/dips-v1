import { Component, OnInit, Inject } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { formatDate } from '@angular/common';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';




@Component({
  selector: 'app-processes-form',
  templateUrl: './processes-form.component.html',
  styleUrls: ['./processes-form.component.sass']
})
export class ProcessesFormComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  selectedRTO: any;
  selectedPeakperiod: any;
  public RTOTimeScales: String = "";
  RtoObject: any;
  public timeScalesRTOArray: any = [];
  rtoList: any = [];
  subscription: any;
  processObj: any;
  businessPeaksList: any = [];
  bia0bj: any;
  rtoId: any;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ProcessesFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
    console.log("modelData", this.modalData);
  }
  get f() { return this.modalFormFroup.controls; }

  public ngOnInit(): void {

    this.modalFormFroup = this.fb.group({
      id: [null],
      name: [null, Validators.required],
      description: [null],
      order: [null],
      organisation: [null],
      version: [null],
      sla: [null],
      biaBusinessPeaks: [null],
      head_count: [null],
      rtoReason: [null],
      rto: [null, Validators.required],
      bia: [null],
      strategy: [null]

    });

    if (this.modalData) {
      if (this.modalData.bia != null) {
        this.getBiaBusinessPeaks(this.modalData.bia);
        let categoryRecord = this.modalData.bia['categoryRecord'];
        if (categoryRecord['category']) {
          let categoryData = categoryRecord['category'];
          if (categoryData['rtoTimeScale']) {
            let rtoTimeScale = categoryData['rtoTimeScale'];
            this.rtoId = rtoTimeScale['id'];
            this.rtoList = this.setTimeScalesList(this.rtoId, TimeScalesConstant.RTO_TYPE);
            this.getTimeScalesList().subscribe(
              (data) => {
                if (data.type == TimeScalesConstant.RTO_TYPE)
                  this.rtoList = data.list;
              });
          }
        }
      }
      this.modalFormFroup.patchValue(this.modalData.data);
    }
  }


  saveFormData(): void {
    if (this.modalFormFroup.invalid) {
      Object.keys(this.modalFormFroup.controls).forEach(field => {
        const control = this.modalFormFroup.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      return;
    }
    this.modalFormFroup.get('bia').setValue(this.modalData.bia);
    this.modalData.data = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  compareObjects(o1: any, o2: any): boolean {
    return o1.name === o2.name && o1.id === o2.id;
  }



  getBiaBusinessPeaks(bia) {
    this.businessPeaksList = bia.businessPeaks;
    this.businessPeaksList.forEach(element => {
      let dateFrom = this.setShortDateFormat(element.dateFrom);
      let dateTo = this.setShortDateFormat(element.dateTo);
      if (dateFrom == "") {
        element.businessPeaks = dateTo + " | " + element.recurrence;
      }
      if (dateTo == "") {
        element.businessPeaks = dateFrom + " | " + element.recurrence;
      }
      if (element.recurrence == null) {
        element.businessPeaks = dateFrom + ' - ' + dateTo;
      }
      if (dateTo !== "" && dateFrom !== "" && element.recurrence !== null) {
        element.businessPeaks = dateFrom + ' - ' + dateTo + " | " + element.recurrence;
      }

    });
  }



}