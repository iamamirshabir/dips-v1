import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryLocationService {

  constructor(private httpClient: HttpClient) { }
  public catLocationDetails: any;

  getRealEntityByOrgId(id){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_BY_ORG_ID+"/"+id,id);
  }
  getCategoryByOrgId(orgID){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_LOCATION_SERVICE_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategoryById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_LOCATION_SERVICE_FIND_BY_ID + '/' + id);
  }
  saveCategory(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_LOCATION_SERVICE_SAVE}`, data);
  }
 
  deleteCategoryById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_LOCATION_SERVICE_REMOVE_BY_ID}`, id);
  }
  getCategoryByOrgIdAndCanDoBia(orgID){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_LOCATION_SERVICE_FIND_BY_ORG_ID + '/' + orgID + Api.CAN_DO_BIA);
  }
  getCategoryLocationBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_LOCATION_SERVICE, data);
  }
}
