import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryResourceListComponent } from './category-resource-list.component';

describe('CategoryResourceListComponent', () => {
  let component: CategoryResourceListComponent;
  let fixture: ComponentFixture<CategoryResourceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CategoryResourceListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoryResourceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
