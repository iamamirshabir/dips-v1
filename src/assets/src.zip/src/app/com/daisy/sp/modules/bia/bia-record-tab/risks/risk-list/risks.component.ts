import { animate, state, style, transition, trigger } from '@angular/animations';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { ExpandListingView } from 'src/app/com/daisy/sp/common/components/expand-listing-view/expand-listing-view.interface';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { RiskFormComponent } from '../risk-form/risk-form.component';

@Component({
  selector: 'app-risks',
  templateUrl: './risks.component.html',
  styleUrls: ['./risks.component.sass'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class RisksComponent extends BaseClass implements OnInit {
  expandListingView: ExpandListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public expandableColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  routeParams: any;
  biaRecordId: any;
  biaRecord: any;
  riskRecord: any[] = [];
  dialogRef: MatDialogRef<RiskFormComponent> | null;

  constructor(private fb: FormBuilder, private cd: ChangeDetectorRef, public dialog: MatDialog) {
    super();
  }

  ngOnInit() {
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'description', name: 'Risk Description', checked: 'true' },
    { key: 'dateLoggedText', name: 'Date Logged', checked: 'true' },
    { key: 'riskScore', name: 'Risk Score', checked: 'true' },
    { key: 'statusText', name: 'Status', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.expandableColumns = [
      [
        { key: 'riskStrategyName', name: 'Risk Strategy' },
        { key: 'ownerName', name: 'Owner' },
        { key: 'controls', name: 'Controls' },
        { key: 'targetDateText', name: 'Target Date' },
        { key: 'impactName', name: 'Impact' },
        { key: 'likelihoodName', name: 'Likelihood' },
        { key: 'closedDateText', name: 'Closed Date' }
      ],
      [
        { key: 'comments', name: 'Comments' },
        { key: 'remedialAction', name: 'remedialAction' }
      ]
    ];

    this.tableButtons = [{ "name": "Delete", "type": this.ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": this.ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.setDataTable([]);
  }

  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.biaRecord = this.routeParams.data;
    if (this.biaRecordId) {
      this.getRiskList();
    }
  }

  getRiskList() {
    this.showLoader();
    this.biaRiskService.getRiskLists(this.biaRecordId).subscribe(res => {
      this.hideLoader();
      this.riskRecord = res;
      this.riskRecord.forEach(element => {
        element.ownerName = element.owner ? element.owner.fullName : '';
        element.riskStrategyName = element.riskStrategy ? element.riskStrategy.name : '';
        element.likelihoodName = element.likelihood ? element.likelihood.value : '';
        element.impactName = element.impact ? element.impact.value : '';
        if (element.dateLogged !== null) {
          element.dateLoggedText = this.setShortDateFormat(element.dateLogged);
        }
        if (element.targetDate !== null) {
          element.targetDateText = this.setShortDateFormat(element.targetDate);

        }
        if (element.closedDate !== null) {
          element.closedDateText = this.setShortDateFormat(element.closedDate);

        }
        if (element.status == false) {
          element.isDisable = false;
          element.statusText = "Open"
        } else {
          element.isDisable = true;
          element.statusText = "Closed"
        }
      });
      this.setDataTable(this.riskRecord);
    }, error => {
      this.hideLoader();
      this.setDataTable([]);
    })
  }

  setDataTable(tableData) {
    this.expandListingView = {
      listTitle: "",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: false,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.RisksListChevronMenu,
      listObject: new Object,
      expandable: true,
      expandableColumns: this.expandableColumns
    }
    this.ExpandlistingViewService.sendExpandedListingView(this.expandListingView);
  }

  btnDoubleClicked(data) {
    if (data.status == true) {
      this.openFormHandler(data, this.PageState.VIEW_STATE);
    } else {
      this.openFormHandler(data, this.PageState.EDIT_STATE);
    }
  }
  openFormHandler(record, pageState) {
    let data = { "data": record, "pageState": pageState }
    this.dialogRef = this.dialog.open(RiskFormComponent, {
      width: '70%',
    
      disableClose: true,
      hasBackdrop: true,
      data: data
    });

    this.dialogRef.afterClosed().subscribe((result: any) => {
      if (result != null && result.data != null && (result.pageState == this.PageState.ADD_STATE || result.pageState == this.PageState.EDIT_STATE)) {
        this.saveRecord(result.data, result.pageState);
      }
      this.dialogRef = null;
    });
  }


  saveRecord(data, pageState) {
    this.showLoader();
    data.owner = Array.isArray(data.owner) ? data.owner[0] : data.owner;
    if (this.biaRecord) {
      data.bia = this.biaRecord;
    }
    this.biaRiskService.saveRisk(data).subscribe(res => {
      this.getRiskList();
      this.hideLoader();
      if (pageState == 1) {
        this.alertService.success("creation.successfull", true);
      }
      else {
        this.alertService.success("updation.successfull", true)
      }
    }, error => {
      this.hideLoader();
    })
  }

  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      if (data.status == true) {
        this.openFormHandler(data, this.PageState.VIEW_STATE);
      } else {
        this.openFormHandler(data, this.PageState.EDIT_STATE);
      }
    }
    if (btnAction == ButtonActions.DELETE) {
      this.deleteRiskById(data.id);
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, this.PageState.VIEW_STATE);
    }
  }

  deleteRiskById(id) {
    this.showLoader();
    this.biaRiskService.deleteRiskbyId(id).subscribe(res => {
      this.getRiskList();
      this.hideLoader();
    }, error => {

    });
  }

  deleteAllClick(data) {
    let riskIds = this.getIdsFromList(data);
    this.showLoader();
    this.biaRiskService.deleteRiskbyIds(riskIds).subscribe(res => {
      this.getRiskList();
      this.hideLoader();
    }, error => {
      this.hideLoader();
    });
  }

  clickComplete(btnAction: ButtonActions) {
    this.showLoader();
    this.biaRecord['risksComplete'] = true;
    this.biaRiskService.saveBiaRecord(this.biaRecord).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('Risk Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      this.biaRecord = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }

  goBackToMainPage(btnAction: ButtonActions) {
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
  }
}