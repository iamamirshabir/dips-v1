import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  constructor(private httpClient: HttpClient) { }

  getCategories(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_FIND_BY_ORG_ID + '/' + orgID);
  }
  saveSubCategories(data){ 
    return this.httpClient.post(`${environment.baseUrl}`+Api.CATEGORY_SAVE,data);
  } 
  getAllRecoveryPolicies(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.RECOVERY_POLICY_FIND_BY_ORGANISATION_ID + '/' + orgID);
  }
  getCategoryITByOrgId(orgID){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_IT_SERVICE_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategorySupplierById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_SUPPLIER_SERVICE_FIND_BY_ID + '/' + id);
  }
  saveCategorySupplier(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_SUPPLIER_SERVICE_SAVE}`, data);
  }
 
  deleteCategoriesById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_DELETE}`, id);
  }
  getCategoryByOrgidAndCatidAndType(orgID,catId,type) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.GET_CATEGORY_BY_ORG_CATEGORY_TYPE_ID  + orgID + '/' + catId + '/' + type);
  }
}
