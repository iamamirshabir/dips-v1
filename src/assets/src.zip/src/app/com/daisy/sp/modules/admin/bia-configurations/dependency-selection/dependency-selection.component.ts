import { Component, OnInit } from "@angular/core";
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { BaseClass } from "../../../../utils/baseclass";
import { ButtonActions } from "../../../../utils/constants/btn-types-constants";
import { CategoryTypes } from "../../../../utils/constants/category-types";
import { RouteConstants } from "../../../../utils/constants/route-constants";

@Component({
    selector: 'app-dependency-selection',
    templateUrl: './dependency-selection.component.html',
    styleUrls: ['./dependency-selection.component.sass']
})
export class DependencySelectionComponent extends BaseClass implements OnInit {

    dependencySelectionForm: FormGroup;

    displayedColumns = ['BIA type', 'Processes', 'Business Area', 'Product And Services', 'Supplier', 'IT', 'Resource', 'Location'];
    biaTypes = [{ name: "Product", type: CategoryTypes.PRODUCT },
    { name: "Business Area", type: CategoryTypes.BUSINESS_AREA },
    { name: "Supplier", type: CategoryTypes.SUPPLIER },
    { name: "IT", type: CategoryTypes.IT },
    { name: "Resource", type: CategoryTypes.RESOURCE },
    { name: "Location", type: CategoryTypes.LOCATION }];

    constructor(private fb: FormBuilder) {
        super();
    }
    ngOnInit(): void {
        this.dependencySelectionForm = this.fb.group({
            dependencySelection: this.fb.array([])
        });
        this.getDependecySelection();
    }

    getDependecySelection() {
        this.showLoader();
        this.dependencySelectionService.getByOrganisationId(this.organisation.id).subscribe((res) => {
            let result: any;
            result = res;
            const fgs = result.map((item) => {
                let name = this.biaTypes.find(x => x.type == item.type).name;

                const fg = new FormGroup({
                    id: new FormControl(item.id),
                    version: new FormControl(item.version),
                    organisation: new FormControl(this.organisation, Validators.required),
                    name: new FormControl(name, Validators.required),
                    type: new FormControl(item.type, Validators.required),
                    typeEnum: new FormControl(item.typeEnum, Validators.required),
                    productAndServices: new FormControl(item.productAndServices, Validators.required),
                    supplier: new FormControl(item.supplier, Validators.required),
                    it: new FormControl(item.it, Validators.required),
                    businessArea: new FormControl(item.businessArea, Validators.required),
                    resource: new FormControl(item.resource, Validators.required),
                    location: new FormControl(item.location, Validators.required),
                    processes: new FormControl(item.processes, Validators.required),
                });
                return fg;
            });
            this.dependencySelectionForm.setControl('dependencySelection', new FormArray(fgs));
        })
        this.hideLoader();
    }

    get dependencySelection(): FormArray {
        return this.dependencySelectionForm.get('dependencySelection') as FormArray;
    }

    onSubmit(btnAction: ButtonActions) {
        this.showLoader();
        this.dependencySelectionService.saveAll(this.dependencySelectionForm.value.dependencySelection).subscribe((res) => {
            this.navigationHandlerAfterSave(btnAction, res);
            // this.getDependecySelection();
            this.alertService.success("updation.successfull", true);
        }, err => {
            this.hideLoader();
        });
    }

    goBackToMainPage() {
        this.routingService.navigate(['/shadowplanner']);
    }

}