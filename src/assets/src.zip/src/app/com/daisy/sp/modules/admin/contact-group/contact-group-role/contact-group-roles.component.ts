import { Component, OnInit } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { RouteParams } from '../../../../utils/model.route-params';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { PageState } from '../../../../utils/constants/page-state-constants';

@Component({
  selector: 'app-contact-group-roles',
  templateUrl: './contact-group-roles.component.html',
  styleUrls: ['./contact-group-roles.component.sass']
})
export class ContactGroupRolesComponent extends BaseClass implements OnInit {

  contactGroup : any;
  contactGroupRolesTitle: string;

  constructor(private router: Router, protected activatedRoute: ActivatedRoute) { super()
    this.activatedRoute.queryParams.subscribe(val => {

    })
  }

  ngOnInit(): void {}

  openPageInAddState(data) {
    this.loadPageData(data);
  }

  openPageInEditState(data) { }

  loadPageData(data) {
    this.contactGroupRolesTitle = data.name;
    this.contactGroupService.getContactGroupById(data.id).subscribe(contactGroup => {
      this.hideLoader();
      this.contactGroup = contactGroup;
      if(this.contactGroup.contactGroupRoles && this.contactGroup.contactGroupRoles.length>0){
        this.contactGroup.contactGroupRoles.sort((a, b) => a.priority - b.priority);
      }
    }, error => { })
  }

  addNewContactChildGroup() {
    let routeParams: RouteParams = new RouteParams();
        routeParams.id = null;
        routeParams.pageState = PageState.ADD_STATE;
        routeParams.parentParams = this.pageParams;
        routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
    this.routingService.openPage(routeParams.routerLink,routeParams);
  }

  editContactGroup() {
    let routeParams: RouteParams = new RouteParams();
        routeParams.id = this.contactGroup.id;
        routeParams.pageState = PageState.EDIT_STATE;
        routeParams.parentParams = this.pageParams;
        routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
    this.routingService.openPage(routeParams.routerLink,routeParams);
  }

  closePage(){
    let routeParams: RouteParams = new RouteParams();
      if(this.pageParams.parentParams){
        routeParams = this.pageParams.parentParams;
        this.routingService.openPage(routeParams.routerLink, routeParams);
      }
      else{
        this.routingService.openPage(RouteConstants.CONTACT_GROUPS_HEIRARCHY, this.pageParams);
      }
  }

  // for sorting purposes on the basis of priority
  //isDesc: boolean = false;
  //priorityColumn: any;
  /////////////////////////////////////////////////////////////////////
  // sort(property) {
  //   this.isDesc = !this.isDesc;
  //   let direction = this.isDesc ? 1 : -1;
  //   this.contactGroupRoles.contactGroupRoles.sort(function (a, b) {
  //     if (a[property] < b[property]) {
  //       return -1 * direction;
  //     } else if (a[property] > b[property]) {
  //       return 1 * direction;
  //     } else {
  //       return 0;
  //     }
  //   });
  //   console.log(this.contactGroupRoles);
  // }
  ////////////////////////////////////////////////////

}
