import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RecoveryPoliciesService {

  constructor(private httpClient: HttpClient) { }

  getAllRecoveryPolicies(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.RECOVERY_POLICY_FIND_BY_ORGANISATION_ID + '/' + orgID);
  }
  getRecoveryPolicyById(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.RECOVERY_POLICY_FIND_BY_ID + '/' + id);
  }
  saveRecoveryPolicy(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.RECOVERY_POLICY_SAVE}`, data);
  }
  deleteRecoveryPolicBySingleId(id){
    return this.httpClient.delete<any>(`${environment.baseUrl}`+Api.RECOVERY_POLICY_REMOVE_BY_ID+'/'+id);
  }
  deleteRecoveryPolicByIds(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.RECOVERY_POLICY_REMOVE_BY_ID}`, id);
  }
}
