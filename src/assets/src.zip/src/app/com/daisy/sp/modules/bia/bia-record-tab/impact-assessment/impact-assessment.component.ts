import { Component, OnInit } from '@angular/core';
import { BiaRecordTabComponent } from '../bia-record-tab.component';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { ImpactAssessmentMatrixComponent } from './impact-assessment-matrix/impact-assessment-matrix.component';
import { BIAService } from '../../bia.service';
import { ImpactAssessmentOverrideComponent } from './impact-assessment-override/impact-assessment-override.component';
import { ImpactAssessmentSummaryReasonComponent } from './impact-assessment-summaryReason/impact-assessment-summaryReason.component';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { AfterViewInit } from '@angular/core';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';


@Component({
  selector: 'app-impact-assessment',
  templateUrl: './impact-assessment.component.html',
  styleUrls: ['./impact-assessment.component.sass']
})
export class ImpactAssessmentComponent extends BiaRecordTabComponent implements OnInit, AfterViewInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  public listTitle: any;
  impactCatList: any[] = [];
  dialogRef: MatDialogRef<ImpactAssessmentMatrixComponent> | null;
  dialogRefOverride: MatDialogRef<ImpactAssessmentOverrideComponent> | null;
  dialogRefSummary: MatDialogRef<ImpactAssessmentSummaryReasonComponent> | null;
  bia: any;
  impactAssessmentList: any;
  recoveryPolicy: any;
  matrix: any;
  impactAssessment: any;
  selectedImpactCategory: any;
  data: any;
  compareImpactCategory: any;
  impactAssessmentOverride: any;
  panelOpenState = false;
  disabelCompleteBtn: boolean = true;
  public complete: boolean;
  summaryReason: any;
  biaRto: any;
  public impactAssessmentForm: FormGroup;
  manualOverideData: any;
  summaryReasonData: any;
 

  constructor(public router: Router, public activatedRoute: ActivatedRoute,
    public dialog: MatDialog, public formBuilder: FormBuilder, private biaService: BIAService) {

    super(formBuilder);

  }
  ngOnInit(): void {
    this.displayedColumns = [
      { key: 'color', name: '', colType: 'colorIcon', checked: 'true' },
      { key: 'name', name: 'Impact Category Name', checked: 'true' },
      { key: 'rtoValue', name: 'RTO', checked: 'true' },
      { key: 'mtpdValue', name: 'MTPD', checked: 'true' },
      { key: 'description', name: 'Impact Category Description', checked: 'true' }
    ];

    this.setDataTable([]);

    this.impactAssessmentForm = this.formBuilder.group({
      id: [null],
      bia: [null],
      override_reason: null,
      rto: null,
      mtpd:null,
      recoveryPolicy: '',
      manualOverride: null,
      summaryReason: null,
      matrix: this.formBuilder.array([]),
      version: [null],
    });
  }

  setDataTable(tableData) {
    this.iListingView = {
      listTitle: '',
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: false,
      search: false,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: false,
      listObject: new Object


    }
    this.listingViewService.sendListingView(this.iListingView);
  }

  btnDoubleClicked(data) {
    this.categoryClicked(data.impactCategory);
  }

  categoryClicked(impactCategory) {
    if (this.impactAssessment != null) {
      if (this.impactAssessment.matrix !== undefined) {
        this.selectedImpactCategory = this.impactAssessment.matrix.find(item => item.impactCategory.id == impactCategory.id)
      }
    }
    if (this.selectedImpactCategory) {
      this.data = { "impactCategory": this.selectedImpactCategory.impactCategory, "bia": this.bia,'levels':this.impactCatList }
    }
    else {
      this.data = { "impactCategory": impactCategory, "bia": this.bia,'levels':this.impactCatList }
    }
    this.dialogRef = this.dialog.open(ImpactAssessmentMatrixComponent, {
      maxWidth: '100%',
      width: '90%',
      disableClose: false,
      hasBackdrop: true,
      data: this.data
    });
    this.dialogRef.beforeClosed().subscribe((result: any) => {
    });
    this.dialogRef.afterClosed().subscribe((result: any) => {

      if (result == null) {
        return
      }
      this.hideLoader();
      let resultData = result;
      this.getBiaRecord();
      this.dialogRef = null;
    });
  }


  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.getBiaRecord();
  }



  getBiaRecord() {
    this.showLoader();
    this.biaService.getBiaRecordById(this.biaRecordId).subscribe((res) => {
      this.hideLoader();
      this.bia = res;
      this.recoveryPolicy = this.bia.recoveryPolicy;
      if (this.recoveryPolicy !== null) {
        this.biaRto =this.bia['recoveryTimeObject'];
        this.getBia_RecoveryPolicybyId();
        this.disabelCompleteBtn = false;
      }
      else {
        this.disabelCompleteBtn = true;
      }
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  getBia_RecoveryPolicybyId(){
    this.showLoader();
    this.impactAssessmentService.getRecoveryPolicyById(this.recoveryPolicy.id).subscribe((res) => {
    if(res){
      this.impactCatList = res.levels;
      this.impactCatList.sort((a, b) => a.impactCategory.id - b.impactCategory.id);
      this.getBia_RecoveryPolicy();
    }
   
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  getBia_RecoveryPolicy() {
    this.showLoader();
    this.impactAssessmentService.getImpactAssessmentLists(this.biaRecordId, this.recoveryPolicy.id).subscribe((res) => {
      this.hideLoader();
      this.impactAssessment = res;
      if (this.impactAssessment != null) {
      this.impactAssessmentForm.patchValue(this.impactAssessment)
      const assessmentMatrixLevelsControl = <FormArray>this.impactAssessmentForm.get('matrix');
      for(var j=0;j<this.impactAssessment.matrix.length;j++){
        assessmentMatrixLevelsControl.value.push(this.impactAssessment.matrix[j])
      }
      for (var i = 0; i < this.impactCatList.length; i++) {
          this.summaryReason = res['summaryReason'];
          this.compareImpactCategory = this.impactAssessment.matrix.find(item => item.impactCategory.id == this.impactCatList[i].impactCategory.id);
          if (this.compareImpactCategory) {
            if (this.compareImpactCategory.rto != null) {
              this.impactCatList[i]['rtoValue'] =  this.timePointDurationbyMeasure(this.compareImpactCategory.rto.measure, this.compareImpactCategory.rto.duration);
             if(this.compareImpactCategory.rto.id == this.biaRto['id'] &&  (this.impactAssessment.manualOverride == false || this.impactAssessment.manualOverride == null) ){
              this.impactCatList[i]['smallestRTO'] = true;
             } 
            }
            if(this.compareImpactCategory.mtpd != null){
              this.impactCatList[i]['mtpdValue'] =  this.timePointDurationbyMeasure(this.compareImpactCategory.mtpd.measure, this.compareImpactCategory.mtpd.duration);
            }
          }
        }
        
      }
      if (this.impactCatList.length >= 1) {
        this.impactCatList.forEach(ele => {
          ele.name = ele.impactCategory.name;
          ele.description = ele.impactCategory.description;
          
        });
      }
      this.setDataTable(this.impactCatList);
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }

  manualOverride() {
    if(this.recoveryPolicy == null){
      this.alertService.error('Recovery Policy is not Defined');
    }
    else{
      this.manualOverideData = { "impactAssessment": this.impactAssessmentForm.value, "bia": this.bia, }
      this.showLoader();
      this.dialogRefOverride = this.dialog.open(ImpactAssessmentOverrideComponent, {
        width: '600px',
        disableClose: true,
        hasBackdrop: true,
        data: this.manualOverideData
      });
      this.dialogRefOverride.beforeClosed().subscribe((result: any) => {
        this.hideLoader();
      });
      this.dialogRefOverride.afterClosed().subscribe((result: any) => {
        this.hideLoader();
      
        let resultData = result;
        if (resultData) {
            this.impactAssessmentForm.patchValue({
              manualOverride:resultData.manualOverride,
              override_reason:resultData.override_reason,
              rto:resultData.rto,
              mtpd:resultData.mtpd
            }) 
        }
        this.hideLoader();
        this.saveImpactAsessment();
  
      });
  
    }
  
  }
  saveImpactAsessment() {
    this.showLoader();
    this.impactAssessmentForm.patchValue({
      bia:this.bia,
      recoveryPolicy:this.recoveryPolicy
    })
    this.impactAssessmentService.saveImpactAssessment( this.impactAssessmentForm.value).subscribe(res => {
      let savedData = res;
      this.getBiaRecord();
      this.hideLoader();
    }, error => {
      this.hideLoader();
    })
  }
  clickSammuaryReason() {
    if(this.recoveryPolicy == null){
      this.alertService.error('Recovery Policy is not Defined');
    }
    else{
      this.showLoader();
      this.summaryReasonData = { "impactAssessment":  this.impactAssessmentForm.value, "bia": this.bia }
      this.dialogRefSummary = this.dialog.open(ImpactAssessmentSummaryReasonComponent, {
        width: '600px',
        disableClose: true,
        hasBackdrop: true,
        data: this.summaryReasonData
      });
      this.dialogRefSummary.beforeClosed().subscribe((result: any) => {
        this.hideLoader();
      });
      this.dialogRefSummary.afterClosed().subscribe((result: any) => {
        this.hideLoader();
        if (result == null) {
          return
        }
        let resultData = result;
        if (resultData) {
            this.impactAssessmentForm.patchValue({
              summaryReason:resultData.summaryReason,
            }) 
          
          this.saveImpactAsessment();
        }
  
        this.hideLoader();
      });
    }

  }
  clickComplete(btnAction: ButtonActions){
    this.showLoader();
    this.bia['impactAssessmentComplete'] = true;
    this.impactAssessmentService.saveBiaRecord(this.bia).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('Impact Assessment Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      // this.routingService.openPage(RouteConstants.BIA_RECORD);
      this.bia = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  
  goBackToMainPage(btnAction: ButtonActions) {
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
}
}