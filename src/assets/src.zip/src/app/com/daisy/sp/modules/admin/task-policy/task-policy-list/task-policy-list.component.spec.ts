import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskPolicyListComponent } from './task-policy-list.component';

describe('TaskPolicyListComponent', () => {
  let component: TaskPolicyListComponent;
  let fixture: ComponentFixture<TaskPolicyListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaskPolicyListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskPolicyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
