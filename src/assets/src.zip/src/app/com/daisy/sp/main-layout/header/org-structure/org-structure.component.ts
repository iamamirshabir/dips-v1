import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-org-structure',
  templateUrl: './org-structure.component.html',
  styleUrls: ['./org-structure.component.sass']
})
export class OrgStructureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
