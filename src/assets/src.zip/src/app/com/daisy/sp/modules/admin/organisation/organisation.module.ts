import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { ComponentsModule } from '../../../common/components/components.module';
import { OrganisationFormComponent } from './organisation-form/organisation-form.component'; 
import { OrganisationListComponent } from './organisation-list/organisation-list.component';
import { OrganisationComponent } from './organisation.component';
const routes: Routes = [
  {
    path: '', component: OrganisationComponent,
    children: [
      { path: 'organisation-list', component: OrganisationListComponent },
      { path: 'organisation-form', component: OrganisationFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [OrganisationListComponent, OrganisationFormComponent, OrganisationComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[OrganisationFormComponent]
})
export class OrganisationModule { }
