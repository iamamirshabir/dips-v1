export class RulesList { 
  static get rules() {
    return [
      {
        "children": [
          {
            "children": [
              {
                "children": [],
                "perspective": {
                  "id": 536,
                  "name": "CCC Administrative Research",
                  "parentPerspective": null,
                  "children": [],
                  "company": null,
                  "perspectiveGroup": {
                    "id": 9,
                    "name": null
                  },
                  "level": 3,
                  "lk": 0,
                  "order": 0,
                  "hasChildren": false,
                  "addedBy": null,
                  "batchAction": null,
                  "hasRecoveryStrategies": false,
                  "hasPerspectiveOptions": false,
                  "externalUID": "auto_536_1606203004380",
                  "lockedBy": null
                },
                "allChildren": false
              }
            ],
            "perspective": {
              "id": 125,
              "name": "Corporate Services",
              "parentPerspective": null,
              "children": [],
              "company": null,
              "perspectiveGroup": {
                "id": 9,
                "name": null
              },
              "level": 2,
              "lk": 0,
              "order": 0,
              "hasChildren": true,
              "addedBy": null,
              "batchAction": null,
              "hasRecoveryStrategies": false,
              "hasPerspectiveOptions": false,
              "externalUID": "dep_fg_cd",
              "lockedBy": null
            },
            "allChildren": false
          },
          {
            "children": [],
            "perspective": {
              "id": 29,
              "name": "Facilities",
              "parentPerspective": null,
              "children": [],
              "company": null,
              "perspectiveGroup": {
                "id": 9,
                "name": null
              },
              "level": 2,
              "lk": 0,
              "order": 1,
              "hasChildren": false,
              "addedBy": null,
              "batchAction": null,
              "hasRecoveryStrategies": false,
              "hasPerspectiveOptions": false,
              "externalUID": "dept_fg_fac",
              "lockedBy": null
            },
            "allChildren": false
          }
        ],
        "perspective": {
          "id": 27,
          "name": "Department(s)",
          "parentPerspective": null,
          "children": [],
          "company": null,
          "perspectiveGroup": {
            "id": 9,
            "name": null
          },
          "level": 0,
          "lk": 0,
          "order": 0,
          "hasChildren": true,
          "addedBy": null,
          "batchAction": null,
          "hasRecoveryStrategies": false,
          "hasPerspectiveOptions": false,
          "externalUID": "dept",
          "lockedBy": null
        },
        "allChildren": false
      },
      {
        "children": [
          {
            "children": [],
            "perspective": {
              "id": 47,
              "name": "EMEA ",
              "parentPerspective": null,
              "children": [],
              "company": null,
              "perspectiveGroup": {
                "id": 10,
                "name": null
              },
              "level": 2,
              "lk": 0,
              "order": 0,
              "hasChildren": false,
              "addedBy": null,
              "batchAction": null,
              "hasRecoveryStrategies": false,
              "hasPerspectiveOptions": false,
              "externalUID": "loc_fg_EU",
              "lockedBy": null
            },
            "allChildren": false
          },
          {
            "children": [
              {
                "children": [],
                "perspective": {
                  "id": 52,
                  "name": "Boston",
                  "parentPerspective": null,
                  "children": [],
                  "company": null,
                  "perspectiveGroup": {
                    "id": 10,
                    "name": null
                  },
                  "level": 3,
                  "lk": 0,
                  "order": 0,
                  "hasChildren": false,
                  "addedBy": null,
                  "batchAction": null,
                  "hasRecoveryStrategies": false,
                  "hasPerspectiveOptions": false,
                  "externalUID": "loc_fg_na_bo",
                  "lockedBy": null
                },
                "allChildren": false
              },
              {
                "children": [],
                "perspective": {
                  "id": 53,
                  "name": "NYC",
                  "parentPerspective": null,
                  "children": [],
                  "company": null,
                  "perspectiveGroup": {
                    "id": 10,
                    "name": null
                  },
                  "level": 3,
                  "lk": 0,
                  "order": 1,
                  "hasChildren": false,
                  "addedBy": null,
                  "batchAction": null,
                  "hasRecoveryStrategies": false,
                  "hasPerspectiveOptions": false,
                  "externalUID": "loc_fg_na_nyc",
                  "lockedBy": null
                },
                "allChildren": false
              },
              {
                "children": [],
                "perspective": {
                  "id": 54,
                  "name": "Toronto",
                  "parentPerspective": null,
                  "children": [],
                  "company": null,
                  "perspectiveGroup": {
                    "id": 10,
                    "name": null
                  },
                  "level": 3,
                  "lk": 0,
                  "order": 2,
                  "hasChildren": false,
                  "addedBy": null,
                  "batchAction": null,
                  "hasRecoveryStrategies": false,
                  "hasPerspectiveOptions": false,
                  "externalUID": "loc_fg_na_to",
                  "lockedBy": null
                },
                "allChildren": false
              }
            ],
            "perspective": {
              "id": 51,
              "name": "North America (NA)",
              "parentPerspective": null,
              "children": [],
              "company": null,
              "perspectiveGroup": {
                "id": 10,
                "name": null
              },
              "level": 2,
              "lk": 0,
              "order": 1,
              "hasChildren": true,
              "addedBy": null,
              "batchAction": null,
              "hasRecoveryStrategies": false,
              "hasPerspectiveOptions": false,
              "externalUID": "loc_fg_na",
              "lockedBy": null
            },
            "allChildren": false
          }
        ],
        "perspective": {
          "id": 41,
          "name": "Office(s)",
          "parentPerspective": null,
          "children": [],
          "company": null,
          "perspectiveGroup": {
            "id": 10,
            "name": null
          },
          "level": 0,
          "lk": 0,
          "order": 1,
          "hasChildren": true,
          "addedBy": null,
          "batchAction": null,
          "hasRecoveryStrategies": false,
          "hasPerspectiveOptions": false,
          "externalUID": "loc",
          "lockedBy": null
        },
        "allChildren": false
      }
    ];
  }
} 