import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { CategoryProductServiceComponent } from './category-productService.component';
import { CategoryProductServiceListComponent } from './category-productService-list/category-productService-list.component';
import { CategoryProductServiceFormComponent } from './category-productService-form/category-productService-form.component';

const routes: Routes = [
  {
    path: '', component: CategoryProductServiceComponent,
    children: [
      { path: 'category-productService-list', component:  CategoryProductServiceListComponent},
      { path: 'category-productService-form', component: CategoryProductServiceFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [CategoryProductServiceComponent, CategoryProductServiceListComponent,CategoryProductServiceFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[CategoryProductServiceFormComponent]
})
export class    CategoryProductServiceModule { }
