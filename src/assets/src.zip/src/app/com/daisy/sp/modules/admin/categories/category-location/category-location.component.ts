import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-location',
  templateUrl: './category-location.component.html',
  styleUrls: ['./category-location.component.sass']
})
export class CategoryLocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
