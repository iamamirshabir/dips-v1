import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BIAComponent } from './bia.component';

describe('BIAComponent', () => {
  let component: BIAComponent;
  let fixture: ComponentFixture<BIAComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BIAComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BIAComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
