import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { MatIcons } from './../../../../utils/constants/mat-icons-constants';

import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Component, OnInit, ViewChild } from '@angular/core';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { AbstractControl, FormArray, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { BehaviorSubject } from 'rxjs';
import { BusinessAreaListComponent } from '../business-area/business-area-list/business-area-list.component';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { GlobalConstants } from '../../../../utils/global-constants';
import { SpChipFormFieldComponent } from '../../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { CategoryTypes } from '../../../../utils/constants/category-types'
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { TimeScalesConstant } from '../../../../utils/constants/timeScales-constant';
@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.sass']
})
export class LocationsComponent extends BaseClass {
  displayColumns = ['name', 'descriptionOfReliance', 'rto', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  routeParams: any;
  locations: FormArray = this.fb.array([]);
  locationsForm: FormGroup = this.fb.group({ 'locations': this.locations });
  @ViewChild(MatSort) sort: MatSort;
  biaRecordId: any;
  biaType: any;
  categoryRecord: any;
  biaRecord: any;
  selectedRTO: any;
  RtoObject: any;
  rtoList: any = [];
  memberDropped: any;
  globals: GlobalConstants;
  @ViewChild('locationField') locationField: SpChipFormFieldComponent;
  rtoId: any;


  constructor(private fb: FormBuilder, globals: GlobalConstants) {
    super();
    this.globals = globals;

  }

  ngOnInit(): void {
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.biaType = this.routeParams.parentParams;
    this.biaRecord = this.routeParams.data;
    let categoryRecord = this.biaRecord['categoryRecord'];
    if (categoryRecord['category']) {
      let categoryData = categoryRecord['category'];
      if (categoryData['rtoTimeScale']) {
        let rtoTimeScale = categoryData['rtoTimeScale'];
        this.rtoId = rtoTimeScale['id'];
        this.rtoList = this.setTimeScalesList(this.rtoId, TimeScalesConstant.RTO_TYPE);
        this.getTimeScalesList().subscribe(
          (data) => {
            if (data.type == TimeScalesConstant.RTO_TYPE)
              this.rtoList = data.list;
          });
      }
    }
    this.locationsService.getLocationByBiaId(this.biaRecordId).subscribe((res) => {
      if (res.length >= 1) {
        this.patchLocationsValues(res);
      }
      else {
        this.addRow();
      }
    }, err => {
      console.log(err);
    })
  }
  patchLocationsValues(res) {
    var locationValues = res;
    locationValues.forEach(locationRows => {
      this.addRow();
      this.locations.patchValue(res);
      this.updateView();
    });

  }

  emptyTable() {
    while (this.locations.length !== 0) {
      this.locations.removeAt(0);
    }
  }
  compareObjects(o1: any, o2: any): boolean {
    return o1.name === o2.name && o1.id === o2.id;
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.id === f2.id;
  }

  addRow(noUpdate?: boolean, droppedElement = null, objectToReplace = null) {
    this.globals.DROPPED_ID_ARRAY = [];
    if (objectToReplace != null && objectToReplace.key === 2) {
      var row = this.fb.group({
        id: [null],
        location: [null],
        description: ['', Validators.required],
        rto: [null, Validators.required],
        organisation: this.routeParams.data['organisation'],
        bia: [null],
        version: [null],
      });
      this.locations.insert(objectToReplace.index, row);
    }
    else {
      if (this.locations.controls[this.locations.controls.length - 1] != undefined) {
        if (this.locations.controls[this.locations.controls.length - 1]['controls'].location.invalid) {
          this.locations.controls[this.locations.controls.length - 1]['controls'].location.markAsTouched();
          return
        }
      }
      var row = this.fb.group({
        id: [null],
        location: [null],
        description: ['', Validators.required],
        rto: [null, Validators.required],
        organisation: this.routeParams.data['organisation'],
        bia: [null],
        version: [null],
      });
      this.locations.push(row);
    }
    if (!noUpdate) { this.updateView(); }
    if (droppedElement != null) {
      row.controls.location.patchValue(droppedElement);
    }
    for (var i = 0; i < this.locations.controls.length; i++) {
      this.globals.DROPPED_ID_ARRAY.push('list-' + i)
    }

  }

  updateView() {
    this.dataSource.next(this.locations.controls);
  }
  dropFromSearch(event: CdkDragDrop<string[]>, businessAreaRow) {
    this.memberDropped = event.previousContainer.data;

    if (this.memberDropped[0].category.type != CategoryTypes.LOCATION) {
      return
    }

    if (businessAreaRow.value.location === null) {
      if (this.memberDropped.length === 1 && this.locations.value[0].location === null) {
        this.locations.controls[0]['controls'].location.patchValue(this.memberDropped[0]);
        this.locationField.patchDataInControls(this.locations.controls[0]['controls'].location.value);
      }
      else if (this.memberDropped.length === 1 && this.locations.value[this.locations.value.length - 1].location === null) {
        this.locations.controls.pop();
        this.addRow(false, this.memberDropped[0]);
      }
      else if (this.memberDropped.length > 1 && this.locations.value[0].location === null) {
        this.locations.controls[0]['controls'].location.patchValue(this.memberDropped[0]);
        this.locationField.patchDataInControls(this.locations.controls[0]['controls'].location.value);
        for (var i = 1; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else if (this.memberDropped.length > 1 && this.locations.value[this.locations.value.length - 1].location === null) {
        this.locations.controls.pop();
        for (var i = 0; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else {
        this.memberDropped.forEach(droppedElement => {
          if (droppedElement['dragged']) {
            this.addRow(false, droppedElement);
          }
        });
      }
    }

    else {
      if (this.memberDropped.length > 1) {
        this.alertService.error("You can replace single record at a time");
        return
      }
      const index = this.locations.controls.indexOf(businessAreaRow);
      var row = this.locations.controls[index];
      if (row.value.id != null) {
        this.locationsService.deleteLocationById([row.value.id]).subscribe((res) => { });
      }
      this.locations.removeAt(index);
      var memberObject = { key: 2, index: index, memberDropped: this.memberDropped[0], rowDropped: businessAreaRow };
      this.addRow(false, this.memberDropped[0], memberObject);
    }
  }

  deleteRow(index: number, row) {
    const control = this.locationsForm.get('locations') as FormArray;
    if (this.locations.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      let that = this;
        this.alertService.confirmation("deleteListConfirm",
        function () {
          that.locationsService.deleteLocationById([row.value.id]).subscribe((res) => {
      
            control.removeAt(index);
            that.updateView();
            that.alertService.success("Successfully Deleted");
          }, err => {
            console.log(err);
          });
        });
    }
    else if (row.value.id === null) {
      let that = this;
      if (this.locations.at(index).dirty) {
      
        this.alertService.confirmation("deleteListConfirm",
          function () {
            control.removeAt(index);
            that.updateView();
          
            that.alertService.success("Successfully Deleted");
          });
      }
      else {
       
        control.removeAt(index);
        that.updateView();
      }
    }
  }
  clickComplete(btnAction: ButtonActions) {
    this.showLoader();
    this.biaRecord['locationComplete'] = true;
    this.locationsService.saveBiaRecord(this.biaRecord).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('Location Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      this.biaRecord = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  onSubmit(btnAction: ButtonActions) {
    if (this.locations.invalid) {
      return
    }
    this.showLoader();
    this.locations.value.forEach(loc => {
      loc['bia'] = this.biaRecord;
      if (Array.isArray(loc.location)) {
        loc.location = loc.location[0];
      }
    });
    this.locationsService.saveAllLocations(this.locations.value).subscribe((res) => {
      this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
      this.hideLoader();
      if (this.routedPageState === 1) {
        this.alertService.success("Successfully Created");
      }
      else {
        this.alertService.success("Successfully Updated")
      }
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  goBackToMainPage(btnAction: ButtonActions) {
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
  }
}
