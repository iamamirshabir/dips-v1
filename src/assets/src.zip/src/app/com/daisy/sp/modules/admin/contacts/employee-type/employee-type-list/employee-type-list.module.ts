import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { ComponentsModule } from 'src/app/com/daisy/sp/common/components/components.module';
import { EmployeeTypeFormComponent } from '../employee-type-form/employee-type-form.component';
import { EmployeeTypeListComponent } from './employee-type-list.component';

export const routes =[{
  path: '', component:EmployeeTypeListComponent
}];

@NgModule({
  declarations: [EmployeeTypeListComponent, EmployeeTypeFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule, 
    RouterModule.forChild(routes)
  ]
})
export class EmployeeTypeListModule { }
