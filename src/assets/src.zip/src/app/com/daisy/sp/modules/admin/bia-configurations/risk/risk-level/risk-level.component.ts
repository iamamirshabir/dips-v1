import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';

@Component({
  selector: 'app-risk-level',
  templateUrl: './risk-level.component.html',
  styleUrls: ['./risk-level.component.sass']
})
export class RiskLevelComponent extends BaseClass implements OnInit {
  risklevelForm: FormGroup;
  likelihoodRiskForm: FormArray;
  riskImpactForm: FormArray;

  panelOpenState = false;
  public static LEVEL_TYPE_IMPACT: number = 1;
  public static LEVEL_TYPE_LIKELIHOOD: number = 2;

  public risklevelImpact: String = "";
  public likelihoodRisk: String = "";

  public risklevelImpactArray: Array<any>;
  public likelihoodRiskArray: Array<any>;

  public riskLevelsObject: any;
  public deleteRiskImpactEnable: boolean = true;
  public deleteLikelihoodEnable: boolean = true;
  constructor(private formBuilder: FormBuilder, public activatedRoute: ActivatedRoute) {
    super();
    activatedRoute.queryParams.subscribe(data => {
      this.risklevelForm = this.formBuilder.group({
        id: [null],
        organisation: this.organisation,
        riskLevel: this.formBuilder.array([]),
        likelihoodRiskForm: this.formBuilder.array([]),
        riskImpactForm: this.formBuilder.array([]),
        version: [null]
      });
      this.getRiskLevels();
    });
  }
  ngOnInit(): void {
  }
  getRiskLevels() {
    this.showLoader();
    this.risklevelService.getRiskLevelsByOrgId(this.organisation.id).
      subscribe(res => {
        this.hideLoader();
        this.riskLevelsObject = res;
        this.patchFormData(this.riskLevelsObject);
      }, error => {
        this.hideLoader();
      })
  }
  patchFormData(riskLevelsObject) {
    this.likelihoodRiskArray = new Array<any>();
    this.risklevelImpactArray = new Array<any>();
    this.risklevelImpact = "";
    this.likelihoodRisk = "";
    this.risklevelForm.patchValue({
      id: riskLevelsObject.id,
      organisation: riskLevelsObject.organisation,
      version: riskLevelsObject.version
    })
    const controlRiskLevels = <FormArray>this.risklevelForm.get('riskLevel');
    const controlRiskImpact = <FormArray>this.risklevelForm.get('riskImpactForm');
    const controlLikelihoodRisk = <FormArray>this.risklevelForm.get('likelihoodRiskForm');
    if (riskLevelsObject.riskLevel && riskLevelsObject.riskLevel.length > 0) {
      riskLevelsObject.riskLevel.forEach(riskLevel => {
        let obj: any = riskLevel;
        controlRiskLevels.push(this.patchValues(obj));
        if (obj.levelType == RiskLevelComponent.LEVEL_TYPE_IMPACT) {
          controlRiskImpact.push(this.patchValues(obj));
          this.risklevelImpactArray.push(obj);
        }
        else if (obj.levelType == RiskLevelComponent.LEVEL_TYPE_LIKELIHOOD) {
          controlLikelihoodRisk.push(this.patchValues(obj));
          this.likelihoodRiskArray.push(obj);
        }
      }
      )
      this.risklevelImpact = this.setLabelValues(this.risklevelImpactArray);
      this.likelihoodRisk = this.setLabelValues(this.likelihoodRiskArray);
    }
  }
  setLabelValues(riskLevels) {
    let label: any = "";
    let idx = 0;
    if (riskLevels && riskLevels.length > 0) {
      riskLevels.forEach(riskLevel => {
        idx++;
        if (idx == riskLevels.length)
          label = label + riskLevel.value + ' = ' + riskLevel.category;
        else
          label = label + riskLevel.value + ' = ' + riskLevel.category + ' / ';
      });
    }
    return label;
  }
  patchValues(riskLevel) {
    return this.formBuilder.group({
      checked: false,
      id: riskLevel.id,
      organisation: riskLevel.organisation,
      value: riskLevel.value,
      externalUID: riskLevel.externalUID,
      category: riskLevel.category,
      version: riskLevel.version,
      priority: riskLevel.priority,
      levelType: riskLevel.levelType,
      versionableRisLevel: riskLevel.versionableRisLevel
    })
  }

  addRiskLevel(type) {
    if (type == RiskLevelComponent.LEVEL_TYPE_IMPACT) {
      let controlForm = this.risklevelForm.get('riskImpactForm') as FormArray;
      controlForm.push(this.createRiskLevel(type));
    } else if (type == RiskLevelComponent.LEVEL_TYPE_LIKELIHOOD) {
      let controlForm = this.risklevelForm.get('likelihoodRiskForm') as FormArray;
      controlForm.push(this.createRiskLevel(type));
    }
  }
  createRiskLevel(type): FormGroup {
    return this.formBuilder.group({
      checked: false,
      id: [null],
      description: [null],
      organisation: this.organisation,
      value: [null, [Validators.pattern("^[0-9]*$")]],
      externalUID: [null],
      category: ['', [Validators.required]],
      version: [null],
      levelType: type,
      priority: [null],
      versionableRisLevel: [null]
    });
  }
  cancelClick() {
    this.routingService.openPage(RouteConstants.BIA_CONFIG_RISK_LEVELS, null);
  }
  checkBoxChangeHandler(type) {
    let likelihood: any = <FormArray>this.risklevelForm.get('likelihoodRiskForm').value;
    let impact: any = <FormArray>this.risklevelForm.get('riskImpactForm').value;
    if (type == RiskLevelComponent.LEVEL_TYPE_IMPACT) {
      this.deleteRiskImpactEnable = true;
      if (impact) {
        impact.forEach(element => {
          if (element.checked) {
            this.deleteRiskImpactEnable = false;
          }
        });
      }
    } else if (type == RiskLevelComponent.LEVEL_TYPE_LIKELIHOOD) {
      if (likelihood) {
        this.deleteLikelihoodEnable = true;
        likelihood.forEach(element => {
          if (element.checked) {
            this.deleteLikelihoodEnable = false;
          }
        });
      }
    }
  }
  saveRiskLevel() {
    if (this.risklevelForm.get('likelihoodRiskForm').invalid ||
      this.risklevelForm.get('riskImpactForm').invalid)
      return;

    let impact: any;
    let likelihood: any;
    let riskLevels: any[] = [];
    likelihood = <FormArray>this.risklevelForm.get('likelihoodRiskForm').value;
    impact = <FormArray>this.risklevelForm.get('riskImpactForm').value;
    if (likelihood) {
      likelihood.forEach(element => {
        riskLevels.push(element);
      });
    }
    if (impact) {
      impact.forEach(element => {
        riskLevels.push(element);
      });
    }
    if (riskLevels && riskLevels.length > 0) {
      this.risklevelForm.value['riskLevel'] = riskLevels;
    } else {
      this.risklevelForm.value['riskLevel'] = [];
    }
    this.showLoader();
    this.risklevelService.saveRiskLevel(this.risklevelForm.value).
      subscribe(res => {
        this.hideLoader();
        this.routingService.openPage(RouteConstants.BIA_CONFIG_RISK_LEVELS, null);
      }, error => {
        this.hideLoader();
        this.routingService.openPage(RouteConstants.BIA_CONFIG_RISK_LEVELS, null);
      })
  }
  deleteRiskLevel(type) {
    if (type == RiskLevelComponent.LEVEL_TYPE_IMPACT) {
      let control = <FormArray>this.risklevelForm.controls['riskImpactForm'];
      let riskImpact = this.risklevelForm.get('riskImpactForm').value;
      let that = this;
      this.alertService.confirmation("deleteListConfirm",
        function () {
          if (riskImpact) {
            riskImpact.forEach(element => {
              if (element.checked) {
                let index = control.value.indexOf(element);
                control.removeAt(index);
                that.deleteRiskImpactEnable = true;
              }
            });
           }
        });
    } else if (type == RiskLevelComponent.LEVEL_TYPE_LIKELIHOOD) {
      let control = <FormArray>this.risklevelForm.controls['likelihoodRiskForm'];
      let likelihoodRisk = this.risklevelForm.get('likelihoodRiskForm').value;
      let that = this;
      this.alertService.confirmation("deleteListConfirm",
        function () {
          if (likelihoodRisk) {
            likelihoodRisk.forEach(element => {
              if (element.checked) {

                let index = control.value.indexOf(element);
                control.removeAt(index);
                that.deleteLikelihoodEnable = true;
              }
            });
         }
        });
    }
  }
}