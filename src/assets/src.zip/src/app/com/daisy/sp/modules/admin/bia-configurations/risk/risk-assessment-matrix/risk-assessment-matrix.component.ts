
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { RiskLevelComponent } from '../risk-level/risk-level.component';

@Component({
  selector: 'app-risk-assessment-matrix',
  templateUrl: './risk-assessment-matrix.component.html',
  styleUrls: ['./risk-assessment-matrix.component.sass']
})
export class RiskAssessmentMatrixComponent extends BaseClass implements OnInit {
  riskLevelsObject: any;
  public modalFormGroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  public risklevelImpactArray: any = [];
  public getRisklevelImpactArray: any = [];
  public likelihoodRiskArray: any = [];
  public reverseOrderLikliHood: any = [];
  color: any;
  listMatrix: any = [];
  selectedList: any = [];
  colorValue: any;
  riskAssessmentObj: any;
 
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,public activatedRoute: ActivatedRoute) {
    super();
    activatedRoute.queryParams.subscribe(data => {  
      this.modalFormGroup = this.fb.group({
        id: [null],
        name: ['Master Template Risk Assessment Matrix'],
        color: [null],
        assessmentMatrixValues: this.fb.array([]),
        organisation: [this.organisation],
        version: [null]
      });
      this.getRiskLevels();
     });
  }
  ngOnInit(): void {
  }

  getRiskLevels() {
    this.showLoader();
    this.likelihoodRiskArray = new Array<any>();
    this.getRisklevelImpactArray = new Array<any>();
    this.risklevelService.getRiskLevelsByOrgId(this.organisation.id).
      subscribe(res => {
        this.hideLoader();
        this.riskLevelsObject = res;
        if (this.riskLevelsObject.riskLevel && this.riskLevelsObject.riskLevel.length > 0) {
          this.riskLevelsObject.riskLevel.forEach(riskLevel => {
            let obj: any = riskLevel;
            if (obj.levelType == RiskLevelComponent.LEVEL_TYPE_IMPACT) {
              this.getRisklevelImpactArray.push(obj);
            }
            else if (obj.levelType == RiskLevelComponent.LEVEL_TYPE_LIKELIHOOD) {
              this.likelihoodRiskArray.push(obj);
            }
          }
          );
          this.risklevelImpactArray = this.getRisklevelImpactArray.sort((n1,n2) => n1.value - n2.value);
          this.reverseOrderLikliHood = this.likelihoodRiskArray.sort((n1,n2) => n2.value - n1.value);
          this.patchFormList();
        }

      }, error => {
        this.hideLoader();
      })
  }
  patchFormList() {
    for (var i = 0; i < this.reverseOrderLikliHood.length; i++) {
      let tempList = [];
      for (var j = 0; j < this.risklevelImpactArray.length; j++) {

        tempList.push(this.reverseOrderLikliHood[i].value * this.risklevelImpactArray[j].value);
      }
      this.listMatrix.push(tempList);
    }
    this.getRiskAssessmentData();
  }
  getRiskAssessmentData() {
    this.showLoader();
    this.risklevelService.getRiskAssessment().
      subscribe(res => {
        this.hideLoader();
        this.riskAssessmentObj = res;
        if (this.riskAssessmentObj) {
          this.patchRecievedData(this.riskAssessmentObj[0])
        }
      }, error => {
        this.hideLoader();
      })
  }
  patchRecievedData(data) {
    this.modalFormGroup.patchValue({
      id: data.id,
      name: data.name,
      version: data.version
    });
    if (data.assessmentMatrixValues && data.assessmentMatrixValues.length > 0) {
      data.assessmentMatrixValues.forEach(riskAsessment => {
        let obj: any = riskAsessment;
        this.selectedColor(obj.colour);
        this.selectedCell(obj.likelihood, obj.impact);

        let val = this.selectedList.findIndex(ev => ev.likelihood == obj.likelihood && ev.impact == obj.impact);
        if (val >= 0){
        this.selectedList[val].id = obj.id;
        this.selectedList[val].version = obj.version;
        }
      });
    }
    this.selectedColor(null);
  }
  goBackToMainPage() {
    this.routingService.navigate(['/shadowplanner']);
  }
  selectedColor(colr) {
    this.modalFormGroup.controls['color'].setValue(colr);
    this.colorValue = colr;
  }

  selectedCell(likelihood, impact) {
    let val = this.selectedList.findIndex((ev: any) => ev.likelihood.id == likelihood.id && ev.impact.id == impact.id);
    if (val >= 0) {
      this.selectedList[val].colour = this.colorValue;
      if(this.selectedList[val].colour == null){
        this.selectedList.splice(val,1)
      }
    }
    else {
        this.selectedList.push({
          id: null,
          colour: this.colorValue,
          likelihood: likelihood,
          impact: impact,
          version: null
        });
    }
  }

  showBackgroundColor(likliHoodId, impactId) {
    let val = this.selectedList.findIndex(ev => ev.likelihood.id == likliHoodId && ev.impact.id == impactId);
    if (val >= 0) {
      return this.selectedList[val].colour
    }
    else {
      return null
    }

  }

  onSubmit(btnType: ButtonActions) {
    if (this.modalFormGroup.invalid) {
      return;
    }
    const assessmentMatrixLevelsControl = <FormArray>this.modalFormGroup.get('assessmentMatrixValues');
    for (var i = 0; i < this.selectedList.length; i++) {
      assessmentMatrixLevelsControl.value.push(this.selectedList[i]);
    }
    this.showLoader();
    this.risklevelService.saveRiskAssessmentMatrix(this.modalFormGroup.value).
      subscribe(res => {
        this.navigationHandlerAfterSave(btnType, res);
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
       //   this.goBackToMainPage();
        }
      }, error => {
        this.hideLoader();
      })
  }
  cancelClick() {
    this.routingService.openPage(RouteConstants.BIA_CONFIG_RISK_ASSESSMENT_MATRIX, null);
  }
}

