import { Component, OnInit } from '@angular/core';
import { CdkDragDrop,moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-security-roles',
  templateUrl: './security-roles.component.html',
  styleUrls: ['./security-roles.component.sass']
})
export class SecurityRolesComponent extends BaseClass implements OnInit {

  securityRoles: any[]=[];
  dataList: any[]=[];
  updatedContactsList: any[]=[];
  contactsWithoutRoles: any[]=[];
  currentUserRoleId : any;

  constructor() {
    super()
    this.currentUserRoleId = this.user.roles[0].id;
    this.getPageData();
   }

  ngOnInit(): void {}

  getPageData(){
    this.showLoader();
    this.securityService.getPageData().
    subscribe(data => {
      let contactList = data[0];
      this.securityRoles = data[1];
      this.contactsWithoutRoles = contactList.filter(contact => contact.role && contact.role.id == 5)
      this.securityRoles.forEach(role => {
        if(role.id !=5){
          if(this.currentUserRoleId == 1 && role.id == 1){
            this.setPageData(contactList, role)
          }
          else if(this.currentUserRoleId == 1 && role.id != 1){
            this.setPageData(contactList, role)
          }
          else if(this.currentUserRoleId != 1 && role.id != 1){
            this.setPageData(contactList, role)
          }
        }
        this.hideLoader();
      });
    })
  }

  setPageData(contactList, role){
    let contacts = contactList.filter(contact => contact.role && contact.role.id == role.id);
    let obj = {
      securityRole : role,
      contacts : contacts ? contacts : [],
      contactCount : contacts.length
    }
    this.dataList.push(obj);
  }

  changeContactRole(event: CdkDragDrop<string[]>) {
    this.updateContactRole(event.previousContainer.data[event.previousIndex], event.container.id);
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  } 

  updateContactRole(contact, roleId){
    let checkContact = this.updatedContactsList.find(con => con.id == contact.id);
    if(checkContact){
      this.setRoleInContact(checkContact, roleId);
    }
    else{
      this.updatedContactsList.push(this.setRoleInContact(contact, roleId));
    } 
  }

  setRoleInContact(contact, roleId){
    if(roleId != 'contacts'){
      contact.role = this.securityRoles.find(role => role.id == roleId)
    }
    else{
      contact.role = null;
    }
    return contact;
  }

  updateChangedContacts(){
    this.contactService.saveAllContacts(this.updatedContactsList).
    subscribe(data => {
      console.log(data)
      this.alertService.success('Successfully Saved');
      this.resetPageData()
      this.getPageData();
    },error=>{})
  }

  resetPageData(){
    this.securityRoles= [];
    this.dataList= [];
    this.updatedContactsList= [];
    this.contactsWithoutRoles= [];
  }

}
