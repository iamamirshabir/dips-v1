import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';


@Component({
  selector: 'app-category-location-form',
  templateUrl: './category-location-form.component.html',
  styleUrls: ['./category-location-form.component.sass']
})
export class CategoryLocationFormComponent extends BaseClass implements OnInit {
  categoryItForm: FormGroup;
  submitted = false;
  securityRoles: any[] = [];
  ButtonActions = ButtonActions;
  routeParams: any;
  contactObject: any;
  subCategories: any;
  categoryLocation: any;
  public static CATEGORY_LOCATION: number = 6;
  categorySupplier: any;
  realEntities: any;
  tenanted: any = true;
  public static RPO_TYPE: number = 1;
  public static RTO_TYPE: number = 2;
  public static ART_TYPE: number = 3;
  public ARTdurationString: any = [];
  public ARTArray: any = [];
  timeScales: any = [];
  @ViewChild('ownerContact') ownerContact: SpChipFormFieldComponent;
  @ViewChild('perspectiveDepartmental') perspectiveDepartmental: SpChipFormFieldComponent;
  @ViewChild('perspectiveLocational') perspectiveLocational: SpChipFormFieldComponent;
  cat_IT_Id: any;
  categoryObject: any;
  addState: boolean = true;
  cat_Location_data: any;
  cat_Location_type: any;
  perspectiveLocationalObj: any;
  perspectiveDepartmentalObj: any;
  artTimeScale: any;
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.categoryItForm.controls; }
  ngOnInit(): void {

    this.categoryItForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: ['', [Validators.required]],
      description: [''],
      category: [null],
      categoryName: [null],
      perspectiveDepartmental: [null],
      perspectiveLocational: [null],
      art: [null],
      provider: null,
      version: [null],
      tenanted: [null],
      tenants: [null],
      address: [null],
      responsible: [null]
    });
    this.loadingService.enableLoading();
    this.getRealEntity();
    this.getCategorySupplierByOrgId();
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_IT_Id = this.routeParams['id'];
    this.cat_Location_data = this.routeParams['data'];
    if (this.cat_IT_Id) {
      this.getCategoryITById(this.cat_IT_Id);
    }
    if (this.cat_Location_data) {
      this.cat_Location_type = this.cat_Location_data['type'];
      this.artTimeScale = this.cat_Location_data['artTimeScale'];
      if (this.artTimeScale != null) {
        this.ARTArray = this.setTimeScalesList(this.artTimeScale.id,TimeScalesConstant.ART_TYPE);
          this.getTimeScalesList().subscribe(
          (data) => { 
            if(data.type == TimeScalesConstant.ART_TYPE)
            this.ARTArray = data.list;
           }
      );
      }
    
      this.getCategoryByOrgId();
      this.categoryItForm.controls['category'].setValue(this.cat_Location_data);
    }
  }
  getCategoryITById(id) {
    this.showLoader();
    this.categoryLocationService.getCategoryById(id).subscribe(data => {
      this.hideLoader();
      this.categoryObject = data;
      this.patchFormData();
    }, error => {
      this.hideLoader();
    })

  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.duration === f2.duration;
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.perspectiveLocational.patchDataInControls(this.categoryItForm.controls['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryItForm.controls['perspectiveDepartmental']);
    } else {
      this.perspectiveLocational.patchDataInControls(this.categoryObject['perspectiveLocational']);
      this.perspectiveDepartmental.patchDataInControls(this.categoryObject['perspectiveDepartmental']);
      this.categoryItForm.controls['id'].setValue(this.categoryObject['id']);
      this.categoryItForm.controls['version'].setValue(this.categoryObject['version']);
      this.bindJsonObjectToFormObject(this.categoryObject, this.categoryItForm);
    }
  }

  getCategoryByOrgId() {
    this.showLoader();
    this.categoryItService.getSubCategories(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.subCategories = data;
      let SubCatObj = this.subCategories.find(item => (item.type == this.cat_Location_type));
      if (SubCatObj != undefined) {
        this.categoryItForm.controls['categoryName'].setValue(SubCatObj.name);
      }
    }, error => {
      this.hideLoader();
    })
  }



  getCategorySupplierByOrgId() {
    this.showLoader();
    this.categoryItService.getCategorySupplierByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.categorySupplier = data;
    }, error => {
      this.hideLoader();
    })
  }
  getRealEntity() {
    this.showLoader();
    this.categoryItService.getRealEntityByOrgId(this.organisation.id).subscribe(data => {
      this.hideLoader();
      this.realEntities = data;
    }, error => {
      this.hideLoader();
    })
  }

  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    this.categoryItForm.controls['organisation'].setValue(this.organisation);
    this.showLoader();
    this.perspectiveLocationalObj = this.categoryItForm.value.perspectiveLocational;
    this.perspectiveDepartmentalObj = this.categoryItForm.value.perspectiveDepartmental;

    this.categoryItForm.controls['perspectiveLocational'].setValue(this.perspectiveLocationalObj);
    this.categoryItForm.controls['perspectiveDepartmental'].setValue(this.perspectiveDepartmentalObj);
    this.subCategories.forEach(element => {
      if (element.type == CategoryLocationFormComponent.CATEGORY_LOCATION) {
        this.categoryLocation = element;
        return;
      }
    });

    console.log(this.categoryItForm.value)
    this.categoryLocationService.saveCategory(this.categoryItForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        } else if (btnType == ButtonActions.SAVE_AND_CONT) {
          this.contactObject = res;
          this.routedPageState = PageState.EDIT_STATE;
          this.patchFormData();
        }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CATEGORY_LOCATION_LIST);
  }



  tenatChange(tenantValue) {
    if (tenantValue == 1) {
      this.categoryItForm.controls['tenants'].enable();
    }
    if (tenantValue == 0) {
      this.categoryItForm.controls['tenants'].disable();
    }
  }
}