import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants';
import { BusinessEntityFormComponent } from './business-entity-form/business-entity-form.component';

@Component({
  selector: 'app-business-entity',
  templateUrl: './business-entity.component.html',
  styleUrls: ['./business-entity.component.sass']
})
export class BusinessEntityComponent  extends BaseClass implements OnInit {
  private tableButtons:any;
  public tableData: any[] = [];
  private displayedColumns:any;
  private iListingView:IListingView;
  private filterSelectObj:any[];
  private dialogRef:MatDialogRef<BusinessEntityFormComponent> | null;

  constructor( protected activatedRoute: ActivatedRoute, public dialog: MatDialog) {
    super();
   }

  ngOnInit(): void {
    this.displayedColumns = [
      { key: 'select', name: '' ,checked: 'true'},
      { key: 'name', name: 'Name',checked: 'true'},
      { key: 'description', name: 'Description', checked: 'true'},
      { key: 'action', name: '' ,checked: 'true'}
    ];

    this.tableButtons = [
      { "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
      { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }
    ];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', options: [] },
                            { name: 'Description', columnProp: 'description', options: [] }]

    this.setTableData([]);
  }

  ngAfterViewInit() {
    this.showLoader();
    this.getBusinessEntityList();
    this.hideLoader();
  }
  
  setTableData(data){
    this.iListingView = {
    listTitle: this.languageTranslator('admin.bia.business.entity'),
    displayedColumns: this.displayedColumns,
    dataSource: data,
    tableButtons: this.tableButtons,
    pagination: true,
    search: true,
    recordsPerpage: true,
    showSelectAll: true,
    showFilters: true,
    filterSelectObj: this.filterSelectObj,
    chevronMenuClassName: ChevronMenuClassName.BusinessEntityListChevronMenu,
    listObject:new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }

  private getBusinessEntityList(){
    this.showLoader();
    this.businessEntityService.getListByOrganisationId(this.organisation.id).
      subscribe(res => {
        this.setTableData(res);
        this.hideLoader();
      }, error => {
        this.setTableData([]);
        this.hideLoader();
      })
  }

  btnDoubleClicked(record){
    this.openFormHandler(record, this.PageState.EDIT_STATE); 
   }
  
  chevronMenuClick(menue){
    let action = menue.btnAction;
    if(action == ButtonActions.EDIT){
     this.btnDoubleClicked(menue.data)
    }else if(action == ButtonActions.VIEW){
     this.openFormHandler(menue.data, this.PageState.VIEW_STATE);
    }else if(action == ButtonActions.DELETE){
     let that = this;
       this.alertService.confirmation("deleteOneConfirm",
         function () {
           that.delete( [menue.data.id]);
       }); 
    }
  }
  
  openFormHandler(record,pageState){ 
    let data = {"data":record,"pageState":pageState} 
    this.dialogRef = this.dialog.open(BusinessEntityFormComponent, {
      width: '600px',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });
    this.dialogRef.afterClosed().subscribe((result: any) => { 
      let resultData = result.data;
      if(result && result.pageState == this.PageState.ADD_STATE){
        resultData.organisation = this.organisation; 
        this.saveRecord(resultData);
      }else if(result && result.pageState == this.PageState.EDIT_STATE){
        this.saveRecord(resultData);
      } 
      this.dialogRef = null;
    }); 
  }
  
  printClick(data,exportType) {
  
  }
  
  saveRecord(data) {
    this.showLoader();
    data.organisation = this.organisation;
    if(data.id){
      this.businessEntityService.update(data).subscribe(res => {
        this.hideLoader();
        this.alertService.success('updation.successfull', true);
        this.getBusinessEntityList();
      }, error => {  
        this.hideLoader(); 
      })
    }else{
      this.businessEntityService.save(data).subscribe(res => {
        this.hideLoader();
        this.alertService.success('creation.successfull', true);
        this.getBusinessEntityList();
      }, error => {  
        this.hideLoader(); 
      })
    }  
  }
  
  deleteAllClick(data) {
    let ids = [];
    data.forEach(element => {
      ids.push(element.id);
    });
    this.delete(ids);
  }
  
  delete(ids) {
    this.showLoader();
    this.businessEntityService.delete(ids).
      subscribe(res => {
        this.alertService.success("deleteOne.successfull", true);
        this.hideLoader();
        this.getBusinessEntityList();
      }, error => {
        this.hideLoader();
      })
  }
  
}
