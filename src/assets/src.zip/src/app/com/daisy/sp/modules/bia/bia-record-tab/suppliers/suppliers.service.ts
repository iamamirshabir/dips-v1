import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class BIASupplierService {


  constructor(private router : Router,private httpClient: HttpClient){}

  saveBiaSupplier(data){
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_SUPPLIER_SAVE}`,data);
  }
  
  saveAllBiaSupplier(data){
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_SUPPLIER_SAVE_ALL}`,data);
  }
  updateBiaSupplier(data){
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_SUPPLIER_UPDATE}`,data);
  }
  getSupplierByBIA(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_SUPPLIER_LIST_BY_BIA_ID+id);
  }

  deleteSupplierbyId(data){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.BIA_SUPPLIER_REMOVE_BY_ID , data);
  }
 
  saveBiaRecord(biaRecord): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
}


}