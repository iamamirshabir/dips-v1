import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoveryPoliciesComponent } from './recovery-policies.component';

describe('RecoveryPoliciesComponent', () => {
  let component: RecoveryPoliciesComponent;
  let fixture: ComponentFixture<RecoveryPoliciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecoveryPoliciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoveryPoliciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
