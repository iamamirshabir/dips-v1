import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpChipFormFieldComponent } from './sp-chip-form-field.component';

describe('SpChipFormFieldComponent', () => {
  let component: SpChipFormFieldComponent;
  let fixture: ComponentFixture<SpChipFormFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpChipFormFieldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpChipFormFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
