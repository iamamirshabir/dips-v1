import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-impact-categories.',
  templateUrl: './impact-categories.component.html',
  styleUrls: ['./impact-categories.component.sass']
})
export class ImpactcategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
