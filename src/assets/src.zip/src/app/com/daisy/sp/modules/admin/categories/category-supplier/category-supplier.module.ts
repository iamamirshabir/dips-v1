import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { CategorySupplierComponent } from './category-supplier.component';
import { CategorySupplierFormComponent } from './category-supplier-form/category-supplier-form.component';
import { CategorySupplierListComponent } from './category-supplier-list/category-supplier-list.component';
const routes: Routes = [
  {
    path: '', component: CategorySupplierComponent,
    children: [
      { path: 'category-supplier-list', component: CategorySupplierListComponent },
      { path: 'category-supplier-form', component: CategorySupplierFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [CategorySupplierListComponent, CategorySupplierFormComponent,CategorySupplierComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[CategorySupplierFormComponent]
})
export class    CategorySupplierModule { }
