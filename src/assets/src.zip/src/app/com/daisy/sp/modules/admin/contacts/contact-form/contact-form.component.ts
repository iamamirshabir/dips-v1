import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { LoaderService } from 'src/app/core-services/loader.service';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactTypes } from '../../../../utils/constants/contacts-types';
import { PageState } from '../../../../utils/constants/page-state-constants';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.sass']
})
export class ContactFormComponent extends BaseClass implements OnInit {
  contactForm: FormGroup;
  submitted = false;
  employeeTypes: any[] = [];
  ButtonActions = ButtonActions;
  contactTypes: any[] = [];
  routeParams: any;
  selectedContactType: any = '0';
  contactId: any;
  contactObject: any;
  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
    this.contactTypes = ContactTypes;
    this.getContactFormPreLoadingData();
  }
  get f() { return this.contactForm.controls; }
  ngOnInit(): void {

    this.contactForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      firstName: [''],
      lastName: [''],
      jobTitle: [''],
      workTel: ['', [Validators.pattern("^[+-]?[0-9]*$")]],
      workMobile: ['', [Validators.pattern("^[+-]?[0-9]*$")]],
      homeTel: ['', [Validators.pattern("^[+-]?[0-9]*$")]],
      homeMobile: ['', [Validators.pattern("^[+-]?[0-9]*$")]],
      workEmail: ['', [Validators.email]],
      homeEmail: [''],
      address: [''],
      username: [''],
      location: [''],
      organisationName: [null, Validators.required],
      contactType: [null, Validators.required],
      employeeNo: [''],
      version: [null],
      manger: [null],
      companyName: [null],
      tempPassword: [null],
      lastLogin: [null],
      addedOn: [null],
      updatedOn: [null],
      addedBy: [null],
      updatedBy: [null],
      externalUid: [null],
      passwordExpiresOn: [null],
      forgotPassword: [null],
      loginAttempts: [null],
      blocked: [null],
      blockedDate: [null],
      loginCnt: [null],
      employeeType: [null, Validators.required],
      costCenter: [''],
      costCenterDescription: [''],
      leavingDate: [''],
    });
    this.loadingService.enableLoading();
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.contactId = this.routeParams['id'];
    if (this.contactId) {
      this.getContactById(this.contactId);
    }
  }
  getContactFormPreLoadingData() {
    this.contactService.getContactFormPreLoadingData(this.organisation.id).
      subscribe(data => {
        this.hideLoader();
        this.employeeTypes = data[0];

        if (this.routedPageState === PageState.ADD_STATE) {
          this.contactForm.patchValue({
            organisationName: this.organisation.name,
          });
        }
      }, error => { })
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
      this.contactForm.patchValue({
        organisationName: this.organisation.name
      });
    } else {
      this.bindJsonObjectToFormObject(this.contactObject, this.contactForm);

      this.contactForm.patchValue({
        organisationName: this.organisation.name
      });
    }
  }
  getContactById(id) {
    this.showLoader();
    this.contactService.getContactById(id).subscribe(data => {
      this.hideLoader();
      this.contactObject = data;
      this.patchFormData();
      this.selectedContactType = +data.contactType;
    }, error => {
      this.hideLoader();
    })
  }
  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.contactForm.invalid) {
      return;
    }
    this.contactForm.value['organisation'] = this.organisation;
    this.showLoader();
    this.contactService.saveContact(this.contactForm.value).
      subscribe(res => {
        this.hideLoader();
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        } else if (btnType == ButtonActions.SAVE_AND_CONT) {
          this.contactObject = res;
          this.routedPageState = PageState.EDIT_STATE;
          this.patchFormData();
        }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.CONTACTS_LIST);
  }
}
