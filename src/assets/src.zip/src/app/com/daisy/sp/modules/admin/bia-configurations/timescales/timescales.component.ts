import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timescales',
  templateUrl: './timescales.component.html',
  styleUrls: ['./timescales.component.sass']
})
export class TimescalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
