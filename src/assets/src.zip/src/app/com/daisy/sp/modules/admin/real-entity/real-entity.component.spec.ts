import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RealEntityComponent } from './real-entity.component';

describe('RealEntityComponent', () => {
  let component: RealEntityComponent;
  let fixture: ComponentFixture<RealEntityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RealEntityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealEntityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
