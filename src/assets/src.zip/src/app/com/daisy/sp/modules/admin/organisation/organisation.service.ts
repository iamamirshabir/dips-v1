import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class OrganisationService {

  constructor(private router: Router, private httpClient: HttpClient) { }

  saveOrganisation(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.ADMIN_ORGANISATION_SAVE}`, data);
  }

  getOrganisationList() {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ADMIN_ORGANISATION_FINDALL);
  }

}