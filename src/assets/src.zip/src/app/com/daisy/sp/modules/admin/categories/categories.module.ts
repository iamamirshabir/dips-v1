import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactGroupHierarchyComponent } from '../contact-group/contact-group-hierarchy/contact-group-hierarchy.component';
import { ContactGroupRolesComponent } from '../contact-group/contact-group-role/contact-group-roles.component';
import { ContactGroupFormComponent } from '../contact-group/contact-group-form/contact-group-form.component';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';

import { CategoriesComponent } from './categories.component';
import { CategoriesListComponent } from './categories-list/categories-list.component';
import { CategoriesFormComponent } from './categories-form/categories-form.component';

const routes: Routes = [
  {
    path: '', component: CategoriesComponent,
    children: [
        { path: 'categories-list', component: CategoriesListComponent },
        { path: 'categories-form', component: CategoriesFormComponent },
        { path: 'category-it', loadChildren: () => import('../categories/category-it/category-it.module').then(m => m.CategoryITModule) },
        { path: 'category-location', loadChildren: () => import('../categories/category-location/category-location.module').then(m => m.CategoryLocationModule) },
       { path: 'category-supplier', loadChildren: () => import('../categories/category-supplier/category-supplier.module').then(m => m.CategorySupplierModule) },
       { path: 'category-business-area', loadChildren: () => import('../categories/category-business-area/category-business-area.module').then(m => m.CategoryBusinessAreaModule) },
       { path: 'category-resource', loadChildren: () => import('../categories/category-resource/category-resource.module').then(m => m.CategoryResourceModule) },
       { path: 'category-productService', loadChildren: () => import('../categories/category-productService/category-productService.module').then(m => m.CategoryProductServiceModule) },
    ]
  }
];


@NgModule({
  declarations: [CategoriesComponent,CategoriesListComponent,CategoriesFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  providers: [],
  entryComponents: []
})
export class CategoriesModule { }
