import { Component, OnInit, Inject, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from '../../../../utils/baseclass';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names'; 
import { RulesList } from '../../real-entity/rules.class';

@Component({
  selector: 'app-perspectives-form',
  templateUrl: './perspectives-form.component.html',
  styleUrls: ['./perspectives-form.component.sass']
})
export class PerspectivesFormComponent extends BaseClass implements OnInit {
  public breakpoint: number;
  public name: string = ``;
  public address: string = ``;
  public organisation:any;
  public addRealEntityForm: FormGroup; 
  public addPerspectiveForm: FormGroup; 
  public modalData:any;
  public wasFormChanged = false;
  public contentHeight = ''; 
  public addedPerspectives:any[]=[]; 
  public perspectivesTree:any[]=[]; 
  public perspectivesCount:any = 0;
  @ViewChild('matDialogRealEntity') matDialogRealEntity: ElementRef;

  selectedPerspective: any = '0';
  public perspectives:any[] = [
    { id: 2, name: 'Department'},
    { id: 1, name: 'Location'}           
  ];
  
  constructor(private fb: FormBuilder,
              public dialog: MatDialog,
              public dialogRef: MatDialogRef<PerspectivesFormComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any){ 
  super();
  this.modalData = data; 
  }

  public ngOnInit(): void {
    this.addRealEntityForm = this.fb.group({
      name: [null, [Validators.required]],
      address: [null],
      parentName: [null],
      perspectiveGroup: [null]
    });
    if(this.modalData){ 
      this.addRealEntityForm.patchValue({
        parentName: this.modalData.node?this.modalData.node.parent.name:this.modalData.parentNode?this.modalData.parentNode.name:"",
        name: this.modalData.node?this.modalData.node.name:"",  
        address: this.modalData.node?this.modalData.node.address:"",
        perspectiveGroup: this.modalData.node?this.modalData.node.perspectiveGroup:"",
      }); 
    }
    this.breakpoint = window.innerWidth <= 600 ? 1 : 1; // Breakpoint observer code  
  } 
  ngAfterViewInit(){
    this.contentHeight = (this.matDialogRealEntity.nativeElement.offsetHeight-60)+'px'; 
  }  
  saveRealEntity(): void {
    if(this.addRealEntityForm.invalid){
      return;
    }
    if(this.modalData && this.modalData.node){
      this.modalData.node.name = this.addRealEntityForm.value['name'];
      this.modalData.node.address = this.addRealEntityForm.value['address'];
      this.modalData.node.perspectiveGroup = this.addRealEntityForm.value['perspectiveGroup'];
    }else{
      this.modalData.node = {"name":this.addRealEntityForm.value['name'],"address":this.addRealEntityForm.value['address'],"perspectiveGroup":this.addRealEntityForm.value['perspectiveGroup']}
    }
    this.dialogRef.close(this.modalData); 
  }

  closeRealEntityModal(): void {
    this.dialogRef.close(null); 
  }
 
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 1;
  }

  private markAsDirty(group: FormGroup): void {
    group.markAsDirty(); 
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }
    
}