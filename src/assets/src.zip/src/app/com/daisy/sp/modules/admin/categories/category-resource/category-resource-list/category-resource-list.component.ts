import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { data } from 'dom7';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { element } from 'protractor';
import { CategoryResourceFormComponent } from '../category-resource-form/category-resource-form.component';
import { TranslateService } from '@ngx-translate/core';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';
@Component({
  selector: 'app-category-resource-list',
  templateUrl: './category-resource-list.component.html',
  styleUrls: ['./category-resource-list.component.sass']
})
export class CategoryResourceListComponent extends BaseClass implements OnInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  public ARTdurationString: any;
  public ARPdurationString: any;
  routeParams: any;
  cat_Resource: any;
  catId: any;
  catType: any;
  hierarchy:string;
  constructor(
    private router: Router, protected activatedRoute: ActivatedRoute) {
    super();
  }
  ngOnInit(): void {

    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'category', name: 'Sub Category', checked: 'true' },
    { key: 'perspectiveDepartmental', name: 'Departmental', checked: 'true' },
    { key: 'perspectiveLocational', name: 'Locational', checked: 'true' },
    { key: 'description', name: 'Description', checked: 'true' },
    { key: 'pooled', name: 'Pooled', checked: 'true' },
    { key: 'art', name: 'ART', checked: 'true' },
    { key: 'arp', name: 'ARP', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD },
    ];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', options: [] },
    { name: 'Username', columnProp: 'username', options: [] },
    { name: 'Email', columnProp: 'workEmail', options: [] }];
    this.setDataTable([]);
    this.getCategoryRecordFromTree();
  }

  openFormByState(routeParams) {
    console.log("reciever");
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_Resource= this.routeParams['data'];
    this.hierarchy = this.cat_Resource.hierarchy;
    this.categoryResourceService.catResourceDetails = this.cat_Resource;
   this.getCategoryRecordFromTree();
  }
getCategoryRecordFromTree(){
  if (this.categoryResourceService.catResourceDetails) {
   this.catId= this.categoryResourceService.catResourceDetails['id'];
   this.catType = this.categoryResourceService.catResourceDetails['type'];
   if(!this.hierarchy) {
    this.hierarchy = this.categoryResourceService.catResourceDetails.hierarchy;
    }
    this.getCategoryResourceList();
   
  }
}
  getCategoryResourceList() {
    this.showLoader();
    this.categoriesService.getCategoryByOrgidAndCatidAndType(this.organisation.id,+this.catId,this.catType).
      subscribe(res => {
        if (res) {
          
          this.tableData = res;
        } else {
          this.tableData = [];
        }
        this.hideLoader();
        if (this.tableData) {
          this.tableData.forEach(element => {
            element.category =  this.hierarchy;
            // element.realEntity = element.realEntity.name;
            if (element.pooled == true) {
              element.pooled = "Yes"
            }
            else {
              element.pooled = "No"
            }
            if (element && element.art != null) {
                this.ARTdurationString = this.timePointDurationbyMeasure(element.art.measure, element.art.duration);
                element.art = this.ARTdurationString;
            }

            if (element && element.arp != null) {
                this.ARPdurationString = this.timePointDurationbyMeasure(element.arp.measure, element.arp.duration);
                element.arp = this.ARPdurationString;
            }
            var deptArray: any = [];
            element.perspectiveDepartmental.forEach(department => {
              deptArray.push(department.name);
            });
            element.perspectiveDepartmental = deptArray.join(", ");
           
            var locArray : any = [];
            element.perspectiveLocational.forEach(location => {
              locArray.push(location.name);
            });
            element.perspectiveLocational = locArray.join(", ");      

          });
        }
        this.setDataTable(this.tableData);
      }, error => {
        this.hideLoader();
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.category.categoryResource.title'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ContactListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }

  btnDoubleClicked(data) {

    this.openFormHandler(data, PageState.EDIT_STATE);
  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
      routeParams.data = this.categoryResourceService.catResourceDetails;
      data.hierarchy = this.hierarchy;
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.CATEGORY_RESOURCE_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }

  printClick(data, exportType) {
  }

  deleteAllClick(data) {
    let Id = this.getIdsFromList(data);
    this.showLoader();
    this.categoryResourceService.deleteCategoryResourceById(Id).
      subscribe(res => {
        this.hideLoader();
        this.alertService.success("Successfully Deleted");
        this.getCategoryResourceList();
      }, error => {
        this.hideLoader();
      })
  }

  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteCategoryBySingleId(data);
        });
    }

    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }

  deleteCategoryBySingleId(data) {
    this.showLoader();
    let Id = this.getIdsFromList([data]);
    this.categoryResourceService.deleteCategoryResourceById(Id).
      subscribe(res => {
        this.hideLoader();
        this.alertService.success("Successfully Deleted");
        this.getCategoryResourceList();
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.ADMIN_LIBRARY_CATEGORY);
  }
}
