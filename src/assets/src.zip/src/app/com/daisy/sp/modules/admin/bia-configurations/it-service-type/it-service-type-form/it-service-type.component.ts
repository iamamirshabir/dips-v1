
import { Inject, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { extname } from 'path';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';
@Component({
  selector: 'app-it-service-type',
  templateUrl: './it-service-type.component.html',
  styleUrls: ['./it-service-type.component.sass']
})
export class ItServiceTypeComponent extends BaseClass implements OnInit {

  modalData:any ;
  public modalFormFroup: FormGroup;
  
  constructor(@Inject(MAT_DIALOG_DATA) public data: any ,private fb: FormBuilder,
  public dialog: MatDialog,public dialogRef: MatDialogRef<ItServiceTypeComponent>) {
    super();
    this.modalData = data;
   }

   closeModal(): void {
    this.dialogRef.close(null); 
  } 


  ngOnInit(): void {
    this.modalFormFroup = this.fb.group({
      id:[null],
      name: [null, [Validators.required]],
      description: [null],
      version: [null],
      organisation : [null]
    });
    if(this.modalData){ 
      this.modalFormFroup.patchValue(this.modalData.data); 
    }
  }

  saveFormData(): void {
    if(this.modalFormFroup.invalid){
     return;
    }
    
    this.modalData.data = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData); 
  }

}
