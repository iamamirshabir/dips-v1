import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactGroupFormComponent } from './contact-group-form.component';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../../common/components/components.module';
import { DirtyCheckGuard } from 'src/app/guards/dirty-check.guard';

export const routes = [
  { path: '', component: ContactGroupFormComponent }
];

@NgModule({
  declarations: [ContactGroupFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ]
})
export class ContactGroupFormModule { }
