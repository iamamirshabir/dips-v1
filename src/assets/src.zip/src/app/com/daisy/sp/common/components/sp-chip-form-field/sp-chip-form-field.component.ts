import { FormControl, FormGroup } from '@angular/forms';
import { Component, ViewChild, ElementRef, Input, OnInit, OnChanges, AfterContentInit, AfterViewInit, EventEmitter, Output } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips';
import { map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MatAutocomplete, MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Observable, fromEvent, of } from 'rxjs';
import { ENTER, COMMA } from '@angular/cdk/keycodes';
import { BaseClass } from '../../../utils/baseclass';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactService } from '../../../modules/admin/contacts/contact.service';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { RecordTypes } from '../../../utils/constants/record-types';
import { MainLayoutService } from '../../../main-layout/main-layout-service';


@Component({
  selector: 'app-sp-chip-form-field',
  templateUrl: './sp-chip-form-field.component.html',
  styleUrls: ['./sp-chip-form-field.component.sass'],
})

export class SpChipFormFieldComponent implements OnInit, OnChanges, AfterContentInit, AfterViewInit {

  @Input() formGroupSP: FormGroup;
  @Input() recordType: any;
  @Input() formControlSP = new FormControl();
  @Input() label: string;
  @Input() allowMultiple: boolean = true;
  @Input() data: boolean = true;

  @Output() doFilter = new EventEmitter<any>();
  @Output() emitedFormData = new EventEmitter<any>();
  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  isLoading = false;
  filteredmembers: any[] = [];
  members: any[] = [];
  filterFlag = false;
  viewControl;
  @ViewChild('chipInput', { static: true }) chipInput: ElementRef;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;
  selectedValue: any;

  constructor(private httpClient: HttpClient, private contactService: ContactService,
    private mainService: MainLayoutService) {
  }

  ngOnInit() {
    fromEvent(this.chipInput.nativeElement, 'keyup').pipe(
      map((event: any) => {
        return event.target.value;
      })
      , debounceTime(400)
      , distinctUntilChanged()
    ).subscribe((text: string) => {
      this.isLoading = true;
      this.searchGetCall(text).subscribe((res: any) => {
        this.isLoading = false;
        this.filteredmembers = res;
        if (this.filteredmembers.length === 0 && text != '') {
          this.filterFlag = true;
        }
        else {
          if (this.recordType === RecordTypes.CONTACTS) {
            this.filteredmembers.forEach(element => {
              element.name = element.firstName + ' ' + element.lastName;
            });
          }
          else if (this.recordType === undefined || this.recordType === null) {
            this.filteredmembers.forEach(element => {
              element.name = element.firstName + ' ' + element.lastName;
            });
          }
          else if (this.recordType === RecordTypes.CONTACT_CONTACT_GROUP) {
            this.filteredmembers.forEach(element => {
              element.name = element.fullName;
            });
          }
          this.filterFlag = false;
        }
      }, (err) => {
        this.isLoading = false;
        this.filteredmembers = [];
      });
    });
    this.getControls();
  }

  ngAfterViewInit() { }

  ngOnChanges() { }

  ngAfterContentInit() { }

  getControls() {
    if (this.formControlSP && this.formControlSP.value) {
      if (this.allowMultiple) {
        if (this.formControlSP.value && this.formControlSP.value.length) {
          this.formControlSP.value.forEach(element => {
            if (this.recordType != null && this.recordType === RecordTypes.CONTACTS) {
              element.name = element.firstName + " " + element.lastName;
            }
            else if (this.recordType != null && this.recordType === RecordTypes.CONTACT_GROUPS) {
              element.name = element.name;
            }
            else if (this.recordType != null && this.recordType === RecordTypes.CONTACT_CONTACT_GROUP) {
              element.name = element.fullName;
            }
            this.members.push(element);
          });
        }
        else {
          if (this.recordType == null || this.recordType === RecordTypes.CONTACTS) {
            if (this.formControlSP.value.length != 0 && this.formControlSP.value) {
              this.members.push(this.formControlSP.value);
            }
          }

        }
      }
      else {
        if (this.recordType != null && this.recordType === RecordTypes.CONTACTS) {
          if (this.formControlSP.value.fullName) {
            this.formControlSP.value.name = this.formControlSP.value.fullName;
          }
          else {
            this.formControlSP.value.name = this.formControlSP.value.firstName + ' ' + this.formControlSP.value.lastName;
          }
        }
        else if (this.recordType != null && this.recordType === RecordTypes.CONTACT_GROUPS) {
          if (this.formControlSP.value.fullName) {
            this.formControlSP.value.name = this.formControlSP.value.fullName;
          }
          else {
            this.formControlSP.value.name = this.formControlSP.value.name;
          }
        }
        else {
          if (this.formControlSP.value.fullName) {
            this.formControlSP.value.name = this.formControlSP.value.fullName;

          }
          else {
            this.formControlSP.value.name = this.formControlSP.value.name;
          }
        }
        this.members.push(this.formControlSP.value);
      }
    }
  }

  patchDataInControls(data, viewOnly = null) {

    if (data == null) {
      return
    }

    this.viewControl = viewOnly;
    if (Array.isArray(data)) {
      this.formControlSP.patchValue(data);
      this.getControls();
      return
    }

    if (this.recordType != null && this.recordType === RecordTypes.CONTACTS) {
      data.name = data.firstName + ' ' + data.lastName;
    } else if (this.recordType != null && this.recordType === RecordTypes.CONTACT_CONTACT_GROUP) {
      data.name = data.fullName;
    }

    this.formControlSP.patchValue(data);
    this.getControls();
    // }
  }
  memberDropped: any;
  dropFromSearch(event: CdkDragDrop<string[]>) {
    this.memberDropped = event.previousContainer.data[event.previousIndex];
    this.memberDropped['name'] = this.memberDropped.firstName + ' ' + this.memberDropped.lastName;
    this.members = [this.memberDropped];
  }
  searchGetCall(term: string) {
    if (term === '') {
      return of([]);
    }
    if (this.recordType === RecordTypes.CONTACTS) {
      return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_SEARCH_CONTACT_BY_NAME}/` + term);
    }
    else if (this.recordType === RecordTypes.CONTACT_CONTACT_GROUP) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_BY_CONTACT_CONTACT_GROUP}/` + term);
    }
    else if (this.recordType === RecordTypes.CATEGORY_IT) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_IT_SERVICE}/` + term);
    }
    else if (this.recordType === RecordTypes.CATEGORY_Supplier) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_SUPPLIER_SERVICE}/` + term);
    }
    else if (this.recordType === RecordTypes.REAL_ENTITY) {
      let data = { "name": term, "organisationId": this.mainService.getloggedInOrganisation().id }
      return this.httpClient.post(`${environment.baseUrl + Api.REAL_ENTITY_SEARCH_BY_NAME}`, data);
    }
    else if (this.recordType === RecordTypes.COST_CENTRE) {
      return this.httpClient.get(`${environment.baseUrl + Api.BIA_CONFIGURATIONS_COST_CENTER_SEARCH}/` + term);
    }
    else if (this.recordType === RecordTypes.BUSINESS_ENTITY) {
      return this.httpClient.get(`${environment.baseUrl + Api.BIA_CONFIGURATIONS_BUSINESS_ENTITY_SEARCH}/` + term);
    }
    else if (this.recordType === RecordTypes.CATEGORY_PRODUCT_SERVICE) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_PRODUCT_SERVICE}/` + term);
    }
    else if (this.recordType === RecordTypes.BUSINESS_AREA) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_BUSINESS_AREA}/` + term);
    }
    else if (this.recordType === RecordTypes.PERSPECTIVE) {
      let data = { "name": term, "organisationId": this.mainService.getloggedInOrganisation().id }
      return this.httpClient.post(`${environment.baseUrl + Api.PERSPETIVE_SEARCH_BY_NAME}`, data);
    }
    else if (this.recordType === RecordTypes.SUPPLIER) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_SUPPLIER_SERVICE}/` + term);
    }
    else if (this.recordType === RecordTypes.RESOURCES) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_CATEGORY_RESOURCE}/` + term);
    }
    else if (this.recordType === RecordTypes.LOCATIONS) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_LOCATION_SERVICE}/` + term);
    }
    else if (this.recordType === RecordTypes.ITSERVICES) {
      return this.httpClient.get(`${environment.baseUrl + Api.SEARCH_IT_SERVICE}/` + term);
    }
    else if (this.recordType === RecordTypes.TaskTypes) {
      return this.httpClient.get(`${environment.baseUrl + Api.ADMIN_TASK_MANAGEMENT_TASK_TYPES_SEARCH}/` + term);
    }
    else {
      return this.httpClient.get(`${environment.baseUrl + Api.CONTACT_SEARCH_CONTACT_BY_NAME}/` + term);
    }
  }
  addMembers(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || "").trim()) {
      if (this.filteredmembers.indexOf(value) > -1) {
        this.members.push(value.trim());
      }
    }
    if (input) {
      input.value = '';
    }
    this.autocomplete.closePanel();
    this.formControlSP.setValue(this.members)
  }

  contactGroupsList: any = [];
  autoCompleteList() {
    this.contactService.getFullContactList().
      subscribe(data => {
        this.contactGroupsList = data;
      })
  }

  removeMembers(member: string): void {
    const index = this.members.indexOf(member);
    if (index >= 0) {
      this.members.splice(index, 1);
    }
    this.formControlSP.setValue(this.members)
    this.doFilter.emit(this.members);
  }

  selectedMembers(event: MatAutocompleteSelectedEvent): void {
    if (this.allowMultiple) {
      if (event.option.value && !this.members.find(member => member.id == event.option.value.id)) {
        this.members.push(event.option.value);
      }
    }
    else {
      if (event.option.value && !this.members.find(member => member.id == event.option.value.id)) {
        this.members = [event.option.value];
      }
    }
    this.chipInput.nativeElement.value = '';
    this.formControlSP.setValue(this.members)
    this.doFilter.emit(this.members);
    this.emitedFormData.emit(this.formControlSP);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.filteredmembers.filter(member => member.name.toLowerCase().indexOf(filterValue) === 0);
  }

  drop(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.formControlSP.value, event.previousIndex, event.currentIndex);
  }

}

