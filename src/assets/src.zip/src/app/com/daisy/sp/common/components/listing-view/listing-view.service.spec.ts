import { TestBed } from '@angular/core/testing';

import { ListingViewService } from './listing-view.service';

describe('ListingViewService', () => {
  let service: ListingViewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ListingViewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
