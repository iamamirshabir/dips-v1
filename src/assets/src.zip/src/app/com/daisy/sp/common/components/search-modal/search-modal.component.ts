import { CdkDragStart } from '@angular/cdk/drag-drop';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatListOption } from '@angular/material/list';
import { PageEvent } from '@angular/material/paginator';
import { ActivationEnd, Router } from '@angular/router';
import { BaseClass } from '../../../utils/baseclass';
import { GlobalConstants } from '../../../utils/global-constants';
import { RoundSpinnerService } from '../../services/round-spinner.service';


@Component({
  selector: 'app-search-modal',
  templateUrl: './search-modal.component.html',
  styleUrls: ['./search-modal.component.sass']
})
export class SearchModalComponent extends BaseClass implements OnInit {
  filterData: any;
  searchForm: FormGroup;
  globals: GlobalConstants;
  SpModulesList: any = [
    {
      key: "Contacts",
      field: "fullName",
      searchBy: ['First Name', 'Last Name'],
      getAllCallback: function (self) { return self.contactService.getFullContactList() },
      searchCallback: function (self, data) { return self.contactService.getBySearchCriteria(data) }
    },

    {
      key: "Contact Groups",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.contactGroupService.getContactGroupByOrganisationId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.contactGroupService.getContactGroupBySearchCriteria(data) }
    },

    {
      key: "Business Area",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.categoryBusinessAreaService.getCategoryBuisnessAreaByOrgId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.categoryBusinessAreaService.getCategoryBuisnessAreaBySearchCriteria(data) }
    },

    {
      key: "IT Service",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.categoryItService.getCategoryITByOrgId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.categoryItService.getCategoryITBySearchCriteria(data) }
    },

    {
      key: "Supplier",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.categorySupplierService.getCategorySupplierByOrgId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.categorySupplierService.getCategorySupplierBySearchCriteria(data) }
    },

    {
      key: "Resource",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.categoryResourceService.getCategpryResourceByOrgId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.categoryResourceService.getCategpryResourceBySearchCriteria(data) }
    },

    {
      key: "Location",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.categoryLocationService.getCategoryByOrgId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.categoryLocationService.getCategoryLocationBySearchCriteria(data) }
    },

    {
      key: "Product Service",
      field: "name",
      searchBy: ['Name', 'Description'],
      getAllCallback: function (self) { return self.CategoryProductServiceService.getCategoryProductServiceByOrgId(self.mainLayoutService.getloggedInOrganisation().id) },
      searchCallback: function (self, data) { return self.CategoryProductServiceService.getCategoryProductServiceBySearchCriteria(data) }
    },
  ];

  SpSubModulesActiveList: string[] = [];
  SpSubModulesOperation: string[] = ['Starts with', 'Contains', 'Ends with', 'Is Equal'];
  searchedList: any = [];
  showSearchContainer: boolean = false;
  showFilters: boolean = false;
  showSpinner: boolean = false;
  lowValue: number = 0;
  highValue: number = 20;
  paginatorShow = false;
  selectedField: any;
  selectedValue: any;
  dragging: any;
  selections: any;

  constructor(private formBuilder: FormBuilder, public dialogRef: MatDialogRef<SearchModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private roundSpinner: RoundSpinnerService, private router: Router, globals: GlobalConstants) {
    super();
    this.globals = globals;
    this.searchForm = this.formBuilder.group({
      optionToSearch: [''],
      filterName: [''],
      filterStartValue: [''],
      valueFilter: [''],
    })
  }

  ngOnInit(): void { }


  public getPaginatorData(event: PageEvent): PageEvent {
    this.lowValue = event.pageIndex * event.pageSize;
    this.highValue = this.lowValue + event.pageSize;
    return event;
  }

  openFormByState(routeParams) {

  }
  selectedOption(ev) {
    let selectedOption = this.searchForm.value.optionToSearch;
    let selectedObject = this.SpModulesList.find(item => item.key === selectedOption.key);
    if (selectedObject != null) {
      this.SpSubModulesActiveList = selectedObject.searchBy;
      this.selectedField = selectedObject.field;
      this.showSpinner = true;
      this.showFilters = true;
      selectedObject.getAllCallback(this).subscribe((res) => {
        this.showSpinner = false;
        this.showSearchContainer = true;
        this.searchedList = res;
      }, err => {
        this.showSpinner = false;
        console.log(err);
      });
    }
  }
  globalList(value) {
    let list: any = [];
    value.forEach(element => {
      element.forEach(element => {
        list.push(element)
      });
    });
    return list;
  }
  selectedArray: any;
  checkedRecord(options: MatListOption[]) {
    this.selectedArray = options.map(o => o.value);
    if (this.selectedArray.length) {
      this.selectedArray.forEach((res) => {
        res.dragged = true;
      });
    }
    else {
      this.searchedList.forEach(searchItem => {
        searchItem.dragged = false;
      });
    }
  }
  showAllResult() {
    this.paginatorShow = true;
  }

  closePanel(): void {
    this.dialogRef.close();
  }
  resetForm() {
    this.showSearchContainer = false;
    this.showFilters = false;
    this.searchForm.reset();
  }
  search(event) {
    let searchObject = this.searchForm.value;

    this.showSpinner = true;
    this.showSearchContainer = false;
    this.selectedField = searchObject.optionToSearch.field;
    let data = [{
      key: this.toCamelCase(searchObject.filterName),
      searchOperation: this.toUpperCaseWithUnderscoreSeperator(searchObject.filterStartValue),
      operationType: "AND",
      value: searchObject.valueFilter
    }]
    searchObject.optionToSearch.searchCallback(this, data).subscribe((res) => {
      this.showSpinner = false;
      this.showSearchContainer = true;
      this.searchedList = res;
    }, err => {
      this.searchedList = [];
      this.showSearchContainer = true;
      this.showSpinner = false;
      console.log(err);
    })
  }
  toCamelCase(str) {
    return str.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (m, chr) => chr.toUpperCase());
  }
  toUpperCaseWithUnderscoreSeperator(str) {
    return str.replace(/\s/g, '_').toUpperCase()
  }
}
