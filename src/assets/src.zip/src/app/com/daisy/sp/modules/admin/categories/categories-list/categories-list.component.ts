import { Component, OnInit, Inject } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../real-entity/real-entity-form/real-entity-form.component';
import { DOCUMENT } from '@angular/common';
import { debounce } from '@agentepsilon/decko';
import { MatTreeFlatDataSource, MatTreeFlattener, MatTreeNestedDataSource } from '@angular/material/tree';
import { FlatTreeControl, NestedTreeControl } from '@angular/cdk/tree';
import { CategoriesFormComponent } from '../categories-form/categories-form.component';
import { RouteParams } from '../../../../utils/model.route-params';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { CategoryTypes } from '../../../../utils/constants/category-types';


@Component({
  selector: 'app-categories-list',
  templateUrl: './categories-list.component.html',
  styleUrls: ['./categories-list.component.sass']
})
export class CategoriesListComponent extends BaseClass implements OnInit {
 

  nodes: any[] = [];
  dropTargetIds = [];
  nodeLookup = {};
  dropActionTodo: DropedNodeInfo = null;
  dialogRef: MatDialogRef<CategoriesFormComponent> | null;
  selectedNode: any;
  deletedCategoriesList: any[] = [];
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new TreeDataSource(this.treeControl, this.nodes);
  constructor(public dialog: MatDialog,
    @Inject(DOCUMENT) private document: Document) {
    super();
  }
  ngOnInit() {
    this.getCategoriesList();
  }
  getCategoriesList() {
    this.categoriesService.getCategories(this.organisation.id).subscribe(data => {
      this.nodes = data;
     this.deletedCategoriesList = [];
     this.setEmptyChildren(this.nodes);
      this.dataSource = new TreeDataSource(this.treeControl, this.nodes);
    }, error => {
    });
  }

 
  setEmptyChildren(treeData) {

    treeData.forEach(element => {
      element.id = element.id.toString();
      if (element.children && element.children.length > 0) {
        element.children = element.children.sort((a, b) => a.order - b.order);
        this.setEmptyChildren(element.children);
      } else {
        element.children = [];
      }
    });
  }

  getParentNodeId(id: string, nodesToSearch: any[], parentId: string): string {
    for (let node of nodesToSearch) {
      if (node.id == id) return parentId;
      let ret = this.getParentNodeId(id, node.children, node.id);
      if (ret) return ret;
    }
    return null;
  }

  activatedNodeChange(activeNode) {
    this.selectedNode = activeNode;
  }
  addNode() {
    if (this.selectedNode == null) {
      this.alertService.error("please select a parent node first");
      return;
    }
    this.openCategoryDialog(null, this.selectedNode, this.PageState.ADD_STATE);
  }
  openCategoryDialog(node, parentNode, pageState) {

    let data = { "node": node, "parentNode": parentNode, "pageState": pageState }
    this.dialogRef = this.dialog.open(CategoriesFormComponent, {
      height: '450',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });
    this.dialogRef.beforeClosed().subscribe((result: any) => {
    });
    this.dialogRef.afterClosed().subscribe((result: any) => {
      let cloneObject = Object.assign({}, result.parentNode);
      cloneObject.children = [];
      if (result && result.pageState == this.PageState.ADD_STATE) {
        let node: any = {
          id: null,
          name: result.node ? result.node.name : "",
          organisation: { "id": this.organisation.id, "version": 0 },
          children: [],
          externalUid: null,
          description: result.node ? result.node.description : "",
          canDoBia: result.node ? result.node.canDoBia : "",
          recoveryPolicy: result.node ? result.node.recoveryPolicy : "",
          hideCategory: result.node ? result.node.hideCategory : "",
          inheritErto: result.node ? result.node.inheritErto : "",
          type: result.node ? result.node.type : "",
          lk: null,
          rk: null,
          bcCoordinator: null,
          order: result.parentNode ? result.parentNode.children.length + 1 : 0,
          parent: cloneObject,
          artTimeScale: result.node.artTimeScale,
          arpTimeScale: result.node.arpTimeScale,
          rtoTimeScale: result.node.rtoTimeScale,
          rpoTimeScale: result.node.rpoTimeScale,
        }
        this.addNewNode(node, result.parentNode);
      } else if (result && result.pageState == this.PageState.EDIT_STATE) {

      }
      this.dialogRef = null;
    });


  }

  addNewNode(node: any, parentNode: any) {
    this.dataSource.add(node, parentNode);
    this.selectedNode = null;
  }
  editNode(node: any = null) {
    this.openCategoryDialog(node, this.selectedNode, this.PageState.EDIT_STATE);
  }
  remove(node: any) {
 
    let parentNode = this.nodes;
    if (node.children && node.children.length > 0) {
      for(let i=0;i<parentNode.length;i++){
      node.children.forEach(element => {
        parentNode[i].children.push(element);
      });
    }
    }
    this.dataSource = new TreeDataSource(this.treeControl, this.nodes);
    this.deletedCategoriesList.push(node);
    this.dataSource.remove(node);
  }

  findRelevatCategoryNode(type){
    for (var currentCategory of this.nodes){
      if(currentCategory.type == type){
        return currentCategory;
      }
    } 
    return null;
  }

  prepareCategoryHirarchy(selectedNode) {
    let foundNode ;
    let relevantCategoryNodes = this.findRelevatCategoryNode(selectedNode.type);
     if(relevantCategoryNodes) {
        this.findThisNodeInChildern(relevantCategoryNodes.children, selectedNode);
       if(this.distanceNode) {
        this.hirarichalName += this.distanceNode.name;
        if(this.distanceNode.parent) {
          this.appendParentName(this.findFlateData(this.distanceNode.parent));
        }
       }
    }
  }

  appendParentName(nodeToFind) {
    if(nodeToFind) {
      this.hirarichalName = nodeToFind.name + "/" + this.hirarichalName;
      if(nodeToFind.parent) {
        this.appendParentName(this.findFlateData(nodeToFind.parent));
      }
    }
  }

  findFlateData(toFind) {
    for (var current of this.flateData) {
      if(current.id == toFind.id){
        return current;
      }
    }
  }

  hirarichalName = "";
  flateData:any[] = [];
  distanceNode = null;
  findThisNodeInChildern(nodestoBeSearched, selectedNode) {
    for (var current of nodestoBeSearched) {
      this.flateData.push(current);
       if(current.id == selectedNode.id) {
        this.distanceNode = current;
        break;
       } else if(current.children) {
        this.findThisNodeInChildern(current.children, selectedNode);
       }
    }
   }

  showRecord(node) {
    let routeParams: RouteParams = new RouteParams();
    if (node) {
      this.prepareCategoryHirarchy(node);
      node.hierarchy = this.hirarichalName;
      
      routeParams.data = node;
    }
    if (node.type == CategoryTypes.SUPPLIER) {
      routeParams.routerLink = RouteConstants.CATEGORY_supplier_LIST;
    }
    if (node.type == CategoryTypes.PRODUCT) {
      routeParams.routerLink = RouteConstants.CATEGORY_PRODUCT_SERVICE_LIST;
    }
    if (node.type == CategoryTypes.IT) {
      routeParams.routerLink = RouteConstants.CATEGORY_IT_LIST;
    }
    if (node.type == CategoryTypes.BUSINESS_AREA) {
      routeParams.routerLink = RouteConstants.CATEGORY_BUSINESS_AREA_LIST;
    }
    if (node.type == CategoryTypes.LOCATION) {
      routeParams.routerLink = RouteConstants.CATEGORY_LOCATION_LIST;
    }
    if (node.type == CategoryTypes.RESOURCE) {
      routeParams.routerLink = RouteConstants.CATEGORY_RESOURCE_LIST;
    }


    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  saveCategories() {
    this.showLoader();

    let data: any = this.nodes;
    if (this.deletedCategoriesList && this.deletedCategoriesList.length > 0) {
      data.toRemove = this.deletedCategoriesList;
      this.deleteAllClick( data.toRemove);
    }
    this.categoriesService.saveSubCategories(data).subscribe(data => {
      this.hideLoader();
      this.deletedCategoriesList = [];
      this.getCategoriesList();
    }, error => {
      console.log("error", error);
      this.hideLoader();
    });
  }
  deleteAllClick(data) {
    let Id = this.getIdsFromList(data);
    console.log("data", data)
    this.showLoader();
    this.categoriesService.deleteCategoriesById(Id).
      subscribe(res => {
        this.hideLoader();
      }, error => {
        this.hideLoader();
      })
  }
  setNode(child, index): any {
    child.order = index;
    return { node: child };
  }
}
export interface DropedNodeInfo {
  targetId: string;
  action?: string;
}
export class TreeDataSource extends MatTreeNestedDataSource<any> {
  constructor(
    private treeControl: NestedTreeControl<any>,
    intialData: any[]
  ) {
    super();
    this._data.next(intialData);
  }

  public add(node: any, parent: any) {
    const newTreeData = {
      id: null,
      name: null,
      organisation: null,
      children: this.data,
      externalUid: null,
      address: null,
      lk: null,
      rk: null,
      bcCoordinator: null,
      parent: null
    };
    this._add(node, parent, newTreeData);
    this.data = newTreeData.children;
  }

  public remove(node: any) {
    const newTreeData = {
      id: null,
      name: null,
      organisation: null,
      children: this.data,
      externalUid: null,
      address: null,
      lk: null,
      rk: null,
      bcCoordinator: null,
      parent: null
    };
    this._remove(node, newTreeData);
    this.data = newTreeData.children;
  }

  protected _add(newNode: any, parent: any, tree: any) {
    if (tree === parent) {
      tree.children = [...tree.children!, newNode];
      this.treeControl.expand(tree);
      return true;
    }
    if (!tree.children) {
      return false;
    }
    return this.update(tree, this._add.bind(this, newNode, parent));
  }

  _remove(node: any, tree: any): boolean {
    if (!tree.children) {
      return false;
    }
    const i = tree.children.indexOf(node);
    if (i > -1) {
      tree.children = [
        ...tree.children.slice(0, i),
        ...tree.children.slice(i + 1)
      ];
      this.treeControl.collapse(node);
      return true;
    }
    return this.update(tree, this._remove.bind(this, node));
  }

  protected update(tree: any, predicate: (n: any) => boolean) {
    let updatedTree: any, updatedIndex: number;

    tree.children!.find((node, i) => {
      if (predicate(node)) {
        updatedTree = { ...node };
        updatedIndex = i;
        this.moveExpansionState(node, updatedTree);
        return true;
      }
      return false;
    });

    if (updatedTree!) {
      tree.children![updatedIndex!] = updatedTree!;
      return true;
    }
    return false;
  }

  moveExpansionState(from: any, to: any) {
    if (this.treeControl.isExpanded(from)) {
      this.treeControl.collapse(from);
      this.treeControl.expand(to);
    }
  }

}