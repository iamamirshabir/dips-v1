import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../../admin/real-entity/real-entity-form/real-entity-form.component';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';



@Component({
  selector: 'app-impact-assessment-matrix',
  templateUrl: './impact-assessment-matrix.component.html',
  styleUrls: ['./impact-assessment-matrix.component.sass']
})
export class ImpactAssessmentMatrixComponent extends BaseClass implements OnInit {
  public breakpoint: number;
  public impactAssessmentForm: FormGroup;
  public impactAssessmentMatrixForm: FormGroup;
  public impactCategory: any;
  public modalData: any;
  public wasFormChanged = false;
  impactLevels: any;
  RtoObject: any;
  rtoList: any[];
  matrix: any = [];
  listofLevelAndRto: any = [];
  impactCatList: any;
  commentValue: any;
  impactAssessmentData: Object;
  getSavedImpactAssessmentLevels: any;
  getSavedImpactAssessmentTimePoint: any;
  selectedImpactCategory: any;
  selectedMatixList: any;
  discriptionImpactLevels: any;
  color: any = 'primary';
  rtoId: any;
  saveAndNextForm: any = null;
  impactAssessment: any;
  categoryDetail: any;
  hideSaveNext: boolean = false;
  impactAssesmentName: any;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RealEntityFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
  }

  public ngOnInit(): void {
    this.impactAssessmentForm = this.fb.group({
      id: [null],
      bia: '',
      override_reason: null,
      rto: null,
      recoveryPolicy: '',
      manualOverride: null,
      summaryReason: null,
      matrix: this.fb.array([]),
      version: [null],
    });
    this.impactAssessmentMatrixForm = this.fb.group({
      impactCategory: new FormControl(''),
      assessmentMatrixLevels: this.fb.array([]),
      comment: [''],
      rto: [null]
    });
    if (this.modalData) {
      this.impactCatList = this.modalData.levels;
      this.impactAssesmentName = this.languageTranslator(this.modalData.bia.name);
      this.impactCatList.sort((a, b) => a.impactCategory.id - b.impactCategory.id);
      let categoryRecord = this.modalData.bia['categoryRecord'];
      if (categoryRecord['category']) {
        let categoryData = categoryRecord['category'];
        if (categoryData['rtoTimeScale']) {
          let rtoTimeScale = categoryData['rtoTimeScale'];
          this.rtoId = rtoTimeScale['id'];
        }
      }
      this.impactAssessmentForm.patchValue({
        bia: this.modalData.bia,
        recoveryPolicy: this.modalData.bia.recoveryPolicy,
      });
      if (this.modalData.impactCategory) {
        this.categoryDetail = this.modalData.impactCategory;
      }
      this.getBia_RecoveryPolicy();

    }
    this.breakpoint = window.innerWidth <= 600 ? 1 : 1; // Breakpoint observer code
  }

  getBia_RecoveryPolicy() {
    this.showLoader();
    this.impactAssessmentForm.get('matrix').setValue([]);
    this.impactAssessmentService.getImpactAssessmentLists(this.impactAssessmentForm.value.bia.id, this.impactAssessmentForm.value.recoveryPolicy.id).subscribe((res) => {
      this.hideLoader();
      this.impactAssessment = res;
      if (this.impactAssessment !== null) {
        if (this.impactAssessment.matrix) {
          this.impactAssessmentForm.patchValue({
            id: this.impactAssessment.id,
            version: this.impactAssessment.version,
            override_reason: this.impactAssessment.override_reason,
            rto: this.impactAssessment.rto,
            manualOverride: this.impactAssessment.manualOverride,
            summaryReason: this.impactAssessment.summaryReason
          });
          this.selectedMatixList = this.impactAssessment.matrix;
          for (var i = 0; i < this.selectedMatixList.length; i++) {
            this.impactAssessmentForm.get('matrix').value.push(this.impactAssessment.matrix[i]);
          }
        }
      }
      this.showAssesmentsCategory(this.categoryDetail);

    }, err => {
      this.hideLoader();

    });
  }
  showAssesmentsCategory(impactCategory) {
    this.impactCategory = impactCategory;
    this.impactLevels = impactCategory.impactCategoryLevels;
    this.impactLevels.sort((a, b) => a.severity - b.severity);

    let newData = this.impactCatList.find(item => item.impactCategory.id == impactCategory.id);
    let currentIndex = this.impactCatList.findIndex(item => item.impactCategory.id == impactCategory.id);
    if (currentIndex == this.impactCatList.length - 1) {
      this.hideSaveNext = true;
    }
    else {
      this.hideSaveNext = false;
    }
    this.impactCatList.forEach(element => {
      element["isSelected"] = false;
      if (this.selectedMatixList) {
        let data = this.selectedMatixList.find(item => item.impactCategory.id == element.impactCategory.id)
        if (data) {
          element["isColor"] = true;
        }
        else {
          element["isColor"] = false;
        }
      }
      else {
        element["isColor"] = false;
      }
    });
    if (newData) {
      newData["isSelected"] = true;
    }
    this.selectedImpactCategory =
      this.listofLevelAndRto = [];
    this.getRTO();
  }

  selectedMatix() {
    if (this.selectedImpactCategory.comment) {
      this.commentValue = this.selectedImpactCategory.comment;
    }
    if (this.selectedImpactCategory.assessmentMatrixLevels) {
      this.selectedImpactCategory.assessmentMatrixLevels.forEach(value => {
        this.radioButtonChangeHandler(value.impactCategoryLevel, value.timePoint)
      });
    }
  }

  getRTO() {
    this.showLoader();
    this.timeScalesService.getTimeScalesListById(this.rtoId).subscribe(data => {
      this.hideLoader();
      this.RtoObject = data;
      this.rtoList = this.RtoObject.timePoints;
      this.rtoList.forEach(element => {
        element['checked'] = "off";
        element['disabled'] = false;
        element.rtoName = this.timePointDurationbyMeasure(element.measure, element.duration)
        element.timInMinutes = this.scaleByMeasureInMinutes(element.measure, element.duration)
      });
      this.commentValue = '';
      this.rtoList.sort((a, b) => a.timInMinutes - b.timInMinutes);
      this.patchFormData(this.RtoObject);

      if (this.selectedMatixList !== undefined) {
        this.selectedImpactCategory = this.selectedMatixList.find(item => item.impactCategory.id == this.impactCategory.id)
      }
      if (this.selectedImpactCategory) {
        this.selectedMatix();
      }

    }, error => {
      this.hideLoader();
    })
  }


  matrixObjectList: any[] = [];
  patchFormData(RtoObject) {
    this.impactAssessmentMatrixForm.controls['impactCategory'].setValue(this.impactCategory);
    let levelsObject: any = new Object;
    this.impactLevels.forEach(level => {
      let rtoList: any[] = [];
      this.rtoList.forEach(rto => {
        let record: any = new Object;
        record['impactCategoryLevel'] = level;
        record['timePoint'] = rto;
        record['checked'] = 'off';
        record['disabled'] = false;
        rtoList.push(record);
      });
      levelsObject[level.id] = rtoList;
      levelsObject['name'] = level.name;
      levelsObject['description'] = level.description;
    });
    this.matrixObjectList = levelsObject;
 
  }


  scaleByMeasureInMinutes(measure: number, duration: number): Number {
    var result: number;
    switch (measure) {
      case TimeScalesConstant.TIME_MEASURE_MIN:
        result = duration
        break;
      case TimeScalesConstant.TIME_MEASURE_HOUR:
        result = duration * 60
        break;
      case TimeScalesConstant.TIME_MEASURE_DAY:
        result = duration * 3600
        break;
      case TimeScalesConstant.TIME_MEASURE_WEEK:
        result = duration * 10080
        break;
    }
    return result;
  }


  saveImpactAssessment(): void {
    if (this.impactAssessmentForm.invalid) {
      return;
    }
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    if (this.saveAndNextForm != null) {
      this.dialogRef.close(this.saveAndNextForm);
    }
    else {
      this.dialogRef.close(null);
    }

  }

  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 1;
  }

  private markAsDirty(group: FormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  radioButtonChangeHandler(level, rtoItem) {

    let moveUp: boolean = true;
    var currentLevelIndex = this.impactLevels.findIndex(x => x.id === level.id);
    let prevSelectedLevel;
    for (let i = 0; i < this.rtoList.length; i++) {
      for (let j = 0; j < this.impactLevels.length; j++) {
        let row = this.matrixObjectList[this.impactLevels[j].id];
        if (row[i].checked == "on" && !prevSelectedLevel && this.rtoList[i].id == rtoItem.id) {
          prevSelectedLevel = this.impactLevels[j];
        }
      }
    }

    if (prevSelectedLevel == null) {
      this.impactLevels.forEach(catLevel => {
        let row = this.matrixObjectList[catLevel.id];
        if (catLevel.id == level.id) {
          let record = row.find(item => item.timePoint.id == rtoItem.id)
          let timePointIndex = row.findIndex(x => x.timePoint.id === record.timePoint.id);
          for (let i = timePointIndex; i < row.length; i++) {
            row[i].checked = 'on';
          }
        } else {
          let record = row.find(item => item.timePoint.id == rtoItem.id)
          let timePointIndex = row.findIndex(x => x.timePoint.id === record.timePoint.id);
          for (let i = 0; i < row.length; i++) {
            row[i].checked = 'off';
          }
        }
      });
    } else {
      let prevSelectedLevelIndex = this.impactLevels.findIndex(x => x.id === prevSelectedLevel.id);
      if (currentLevelIndex > prevSelectedLevelIndex) {
        moveUp = false;
      } else {
        moveUp = true;
      }
      if (moveUp == false) {
        this.impactLevels.forEach(catLevel => {
          let row = this.matrixObjectList[catLevel.id];
          if (catLevel.id == level.id) {
            let record = row.find(item => item.timePoint.id == rtoItem.id)
            let timePointIndex = row.findIndex(x => x.timePoint.id === record.timePoint.id);
            for (let i = timePointIndex; i < row.length; i++) {
              row[i].checked = 'on';
            }
          } else {
            let record = row.find(item => item.timePoint.id == rtoItem.id)
            let timePointIndex = row.findIndex(x => x.timePoint.id === record.timePoint.id);
            for (let i = timePointIndex; i < row.length; i++) {
              row[i].checked = 'off';
            }
          }
        });
      } else {
        for (let j = 0; j < this.impactLevels.length; j++) {
          let row = this.matrixObjectList[this.impactLevels[j].id];
          let record = row.find(item => item.timePoint.id == rtoItem.id)
          if (record.impactCategoryLevel.id == level.id) {
            record.checked = 'on';
          } else {
            record.checked = 'off';
          }
        }
      }
    }
    this.makeEnableDisable(level, rtoItem);
  }
  makeEnableDisable(level, rtoItem) {
    let fisrtRtoSelected
    for (let i = 0; i < this.rtoList.length; i++) {
      for (let j = 0; j < this.impactLevels.length; j++) {
        let row = this.matrixObjectList[this.impactLevels[j].id];
        row[i].disabled = true;
        if (row[i].checked == "on" && !fisrtRtoSelected) {
          fisrtRtoSelected = row[i];
        }
      }
    }

    let fisrtRtoSelectedIndex = this.rtoList.findIndex(x => x.id === fisrtRtoSelected.timePoint.id);
    for (let i = 0; i <= fisrtRtoSelectedIndex; i++) {
      for (let j = 0; j < this.impactLevels.length; j++) {
        let row = this.matrixObjectList[this.impactLevels[j].id];
        row[i].disabled = false;
      }
    }

    for (let i = fisrtRtoSelectedIndex + 1; i < this.rtoList.length; i++) {
      let isSelectedRto: boolean = false;
      for (let j = 0; j < this.impactLevels.length; j++) {
        let row = this.matrixObjectList[this.impactLevels[j].id];
        if (row[i].checked == "on" && !isSelectedRto) {
          row[i].disabled = false;
          isSelectedRto = true;
        }
        if (isSelectedRto) {
          row[i].disabled = false;
        }
      }
    }

    for (let j = 0; j < this.impactLevels.length; j++) {
      let row = this.matrixObjectList[this.impactLevels[j].id];
      for (let i = 0; i < row.length; i++) {
        if (row[i].checked == "on") {
          row[i + 1] ? row[i + 1].disabled = false : '';
        }
      }
    }

    for (let i = 0; i < this.rtoList.length; i++) {
      let fisrtEnableFound: boolean = false;
      for (let j = 0; j < this.impactLevels.length; j++) {
        let row = this.matrixObjectList[this.impactLevels[j].id];
        if (row[i].disabled == false && !fisrtEnableFound) {
          fisrtEnableFound = true;
        }
        if (fisrtEnableFound) {
          row[i].disabled = false;
        }
      }
    }
  }

  saveFormData() {
    this.showLoader();
    this.impactAssessmentMatrixForm.get('assessmentMatrixLevels').setValue([]);
    this.impactAssessmentMatrixForm.controls['comment'].setValue(this.commentValue);
    const assessmentMatrixLevelsControl = <FormArray>this.impactAssessmentMatrixForm.get('assessmentMatrixLevels');
    const list = []
    const matrixControl = <FormArray>this.impactAssessmentForm.get('matrix');
    let val = matrixControl.value.find(item => item.impactCategory.id == this.impactAssessmentMatrixForm.value.impactCategory.id)
    if (val) {
      val.comment = this.commentValue;
      this.impactLevels.forEach(catLevel => {
        let row = this.matrixObjectList[catLevel.id];
        row.forEach(rtoLevel => {
          if (rtoLevel.checked == 'on') {
            list.push(rtoLevel)
          }
        });
      });
      for (var i = 0; i < list.length; i++) {
        let newVal = val.assessmentMatrixLevels.find(item => ((item.impactCategoryLevel.id !== list[i].impactCategoryLevel.id) && (item.timePoint.id == list[i].timePoint.id)))
        if (newVal) {
          newVal.impactCategoryLevel = list[i].impactCategoryLevel;
        } else {
          if (list.length !== val.assessmentMatrixLevels.length)
            val.assessmentMatrixLevels.push(list[i]);
        }
      }
      assessmentMatrixLevelsControl.value.push(val.assessmentMatrixLevels);
    }
    else {
      this.impactLevels.forEach(catLevel => {
        let row = this.matrixObjectList[catLevel.id];
        row.forEach(rtoLevel => {
          if (rtoLevel.checked == 'on') {
            assessmentMatrixLevelsControl.value.push(rtoLevel);
          }
        });
      });
      matrixControl.value.push(this.impactAssessmentMatrixForm.value);
    }
    this.impactAssessmentService.saveImpactAssessment(this.impactAssessmentForm.value).subscribe(res => {
      this.impactAssessmentData = res;
      this.hideLoader();
      this.dialogRef.close(this.impactAssessmentForm.value);
    }, error => {
      this.hideLoader();
    })
  }
  saveAndnext() {
    this.showLoader();
    this.impactAssessmentMatrixForm.get('assessmentMatrixLevels').setValue([]);
    this.impactAssessmentMatrixForm.controls['comment'].setValue(this.commentValue);
    const assessmentMatrixLevelsControl = <FormArray>this.impactAssessmentMatrixForm.get('assessmentMatrixLevels');
    const list = []
    const matrixControl = <FormArray>this.impactAssessmentForm.get('matrix');
    let val = matrixControl.value.find(item => item.impactCategory.id == this.impactAssessmentMatrixForm.value.impactCategory.id)
    if (val) {
      val.comment = this.commentValue;
      this.impactLevels.forEach(catLevel => {
        let row = this.matrixObjectList[catLevel.id];
        row.forEach(rtoLevel => {
          if (rtoLevel.checked == 'on') {
            list.push(rtoLevel)
          }
        });
      });
      for (var i = 0; i < list.length; i++) {
        let newVal = val.assessmentMatrixLevels.find(item => ((item.impactCategoryLevel.id !== list[i].impactCategoryLevel.id) && (item.timePoint.id == list[i].timePoint.id)))
        if (newVal) {
          newVal.impactCategoryLevel = list[i].impactCategoryLevel;
        } else {
          if (list.length !== val.assessmentMatrixLevels.length)
            val.assessmentMatrixLevels.push(list[i]);
        }
      }
      assessmentMatrixLevelsControl.value.push(val.assessmentMatrixLevels);
    }
    else {
      this.impactLevels.forEach(catLevel => {
        let row = this.matrixObjectList[catLevel.id];
        row.forEach(rtoLevel => {
          if (rtoLevel.checked == 'on') {
            assessmentMatrixLevelsControl.value.push(rtoLevel);
          }
        });
      });
      matrixControl.value.push(this.impactAssessmentMatrixForm.value);
    }
    this.saveAndNextForm = this.impactAssessmentForm.value;

    this.impactAssessmentService.saveImpactAssessment(this.impactAssessmentForm.value).subscribe(res => {
      this.impactAssessmentData = res;
      this.hideLoader();
      let val = this.impactCatList.findIndex(val => val.impactCategory.id == this.impactAssessmentMatrixForm.value.impactCategory.id);
      if (val >= 0) {
        if (this.impactCatList[val + 1].impactCategory) {
          this.categoryDetail = this.impactCatList[val + 1].impactCategory;
          this.getBia_RecoveryPolicy();
        }
      }
    }, error => {
      this.hideLoader();
    })
  }
 



}

