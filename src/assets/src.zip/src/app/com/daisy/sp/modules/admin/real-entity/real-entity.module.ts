import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactGroupHierarchyComponent } from '../contact-group/contact-group-hierarchy/contact-group-hierarchy.component';
import { ContactGroupRolesComponent } from '../contact-group/contact-group-role/contact-group-roles.component';
import { ContactGroupFormComponent } from '../contact-group/contact-group-form/contact-group-form.component';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { RealEntityComponent } from './real-entity.component';
import { RealEntityListComponent } from './real-entity-list/real-entity-list.component';
import { RealEntityFormComponent } from './real-entity-form/real-entity-form.component';

const routes: Routes = [
  {
    path: '', component: RealEntityComponent,
    children: [
      { path: 'real-entity-form', component: RealEntityFormComponent },
      { path: 'real-entity-list', component: RealEntityListComponent }
    ]
  }
];


@NgModule({
  declarations: [RealEntityComponent, RealEntityListComponent, RealEntityFormComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  providers: [],
  entryComponents: [RealEntityFormComponent]
})
export class RealEntityModule { }
