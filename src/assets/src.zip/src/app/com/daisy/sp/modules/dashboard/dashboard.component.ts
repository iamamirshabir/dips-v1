import { Component, OnInit, ViewChildren } from '@angular/core';
import { trigger, transition, style, animate, state } from '@angular/animations';
import { Chart } from 'chart.js';
import { PageState } from '../../utils/constants/page-state-constants';
import { BaseClass } from '../../utils/baseclass';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  animations: [
    trigger('openClose', [
      state('open', style({
        opacity: 1,
      })),
      state('closed', style({
        opacity: 0,
      })),
      transition('closed => open', [
        animate('2.5s')
      ]),
    ]),
  ],
  styleUrls: ['./dashboard.component.sass']
})
export class DashboardComponent extends BaseClass implements OnInit {

  isOpen = false;
  @ViewChildren('mycharts') allMyCanvas: any;
  chart: any;

  dashboard = "Dashboard";
  chartStats = [
    { name: "canvas", description: "IT Systems", label: "Critical", data: "100", type: "bar", dataLabel: "Data 1" },
    { name: "canvas1", description: "Network Systems", label: "Moderate", data: "15", type: "pie", dataLabel: "Data 2" },
    { name: "canvas2", description: "Server Performance", label: "Minor", data: "25", type: "line", dataLabel: "Data 3" },
    // { name: "canvas3", description: "Database Systems", data: "75", type: "doughnut", dataLabel: "Data 4" },
  ]
  bgColorChart = [
    "rgba(62, 149, 205, 1)", "rgba(142, 94, 162, 1)",
    "rgba(60, 186, 159, 1)", "rgba(232, 195, 185, 1)", "rgba(196, 88, 80, 1)"
  ];

  constructor() {
    super();
  }

  ngOnInit(): void { }

  mouseEnter() {
    this.isOpen = true;
  }

  ngAfterViewInit(): void {
    this.generateChartStats();
  }
  generateChartStats() {
    var dataStats = this.chartStats.map((stats) => {
      return stats.data;
    });
    var label = this.chartStats.map((labels) => {
      return labels.label;
    });
    let canvasCharts = this.allMyCanvas._results;
    var typesOfChart = this.chartStats.map((types) => {
      return types.type;
    });
    canvasCharts.map((myCanvas, i) => {
      this.chartStats[i].name = new Chart(myCanvas.nativeElement.getContext('2d'), {
        type: typesOfChart[i],
        data: {
          labels: label,
          datasets: [
            {
              label: label,
              backgroundColor: this.bgColorChart,
              data: dataStats
            },
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: true
          },
          tooltips: {
            enabled: true
          }
        }
      });
    });
    this.hideLoader();
  }

}
