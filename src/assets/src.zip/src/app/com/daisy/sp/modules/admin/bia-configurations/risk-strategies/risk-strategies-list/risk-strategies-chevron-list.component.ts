import { ChevronMenuBase } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-base';

import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';

import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';

import { AccessAreas } from '../../../security/access-areas';

import { SecurityActions } from '../../../security/security-actions';

export class RiskStrategiesListChevronMenu extends ChevronMenuBase { 
    constructor(record, recordsList) { 
     super();
     this.record = record;
     this.recordsList = recordsList;
     this.onInitChevronMenu();
    } 
    onInitChevronMenu(){ 
        this.addMenu(ButtonActions.EDIT, MatIcons.EDIT,AccessAreas.ADMIN,SecurityActions.SECURITY_ACTION_UPDATE);
        this.addMenu(ButtonActions.VIEW, MatIcons.PREVIEW,AccessAreas.ADMIN,SecurityActions.SECURITY_ACTION_READ);
        this.addMenu(ButtonActions.DELETE, MatIcons.DELETE,AccessAreas.ADMIN,SecurityActions.SECURITY_ACTION_DELETE); 
    } 
}