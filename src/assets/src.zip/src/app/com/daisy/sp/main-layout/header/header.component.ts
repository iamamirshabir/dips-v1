import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { RoutingService } from '../../common/services/routing-service';
import { RouteConstants } from '../../utils/constants/route-constants';
import { BaseClass } from '../../utils/baseclass';
import { PageState } from '../../utils/constants/page-state-constants';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass']
})
export class HeaderComponent extends BaseClass implements OnInit {
  selectedValue:any =''; 
  dropdownList: any[] = [
    {value: 1, viewValue: 'Client with long name'}, 
    {value: 2, viewValue: 'Client name'}, 
    {value: 3, viewValue: 'Client with very very long name'}, 
    {value: 4, viewValue: 'Master template'}, 
  ]; 
  dropdownAdmin = new FormControl('', [Validators.required]); 
  @Output() closeSideNav = new EventEmitter<any>();
  constructor(public formBuilder: FormBuilder,
              public routingService: RoutingService) {
    super();
    this.selectedValue = 1; 
   }

  ngOnInit(): void {
  }
  openIncidents(){

  }
  openMyFav(){ 
  }
  toggleSideNav(){
    this.closeSideNav.emit(true);
  }   
  openRealEntityModal(){
    this.openRealEntityModel(null);
  }
  updateRealEntities(data){
    console.log("data screen filter",data)
  }
}
