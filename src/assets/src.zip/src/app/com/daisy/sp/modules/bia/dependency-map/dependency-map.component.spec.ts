import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DependencyMapComponent } from './dependency-map.component';

describe('DependencyMapComponent', () => {
  let component: DependencyMapComponent;
  let fixture: ComponentFixture<DependencyMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DependencyMapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DependencyMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
