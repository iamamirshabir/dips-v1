import { Injectable } from '@angular/core';
import { Router } from '@angular/router'; 
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TimeScalesService {


  constructor(private router : Router,private httpClient: HttpClient){}

  saveTimeScales(data){ 
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_TIME_SCALES_SAVE}`,data);
  } 

  getTimeScalesList(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_TIME_SCALES_LIST);
  }  

  getTimeScalesListById(id) : Observable<any> {
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_TIME_SCALES_LIST_BY_ID+id);
  } 

  getTimeScalesListByOrgId(id){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_TIME_SCALES_LIST_BY_ORG_ID+id);
  }

  getTimeScalesListByOrgIdAndType(OrgId, type){
    return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_CONFIGURATIONS_TIME_SCALES_LIST_BY_ORG_ID_AND_TYPE+"organisation/"+OrgId+"/type/"+type);
  }

  removeTimeScale(obj) {
    return this.httpClient.post(`${environment.baseUrl+Api.BIA_CONFIGURATIONS_TIME_SCALES_REMOVE_BY_ID}`,obj);
  }
}
