import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analysis-colors',
  templateUrl: './analysis-colors.component.html',
  styleUrls: ['./analysis-colors.component.sass']
})
export class AnalysisColorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
