import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskPolicyFormComponent } from './task-policy-form.component';

describe('TaskPolicyFormComponent', () => {
  let component: TaskPolicyFormComponent;
  let fixture: ComponentFixture<TaskPolicyFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaskPolicyFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskPolicyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
