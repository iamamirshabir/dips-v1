import { Component, OnInit } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-task-policy-list',
  templateUrl: './task-policy-list.component.html',
  styleUrls: ['./task-policy-list.component.sass']
})
export class TaskPolicyListComponent extends BaseClass implements OnInit {

  constructor() { 
    super();
  }

  ngOnInit(): void {
  }

}
