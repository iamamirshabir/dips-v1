import { Component, Input, OnInit, ViewChild } from '@angular/core';
// import { FileHandle } from '../../directives/drag-drop.directive';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.sass']
})
export class UploadFileComponent implements OnInit {

  // @ViewChild('fileInput')
  // @Input() formControlSP;
  // @Input() formGroupSP;

  // fileInput;
  // flagUploaded: boolean = true;
  // file: File | null = null;
  // fileType;
  // uploadedData;
  // uploadRawData: any;
  // uploadedUrl = [];
  // uploadBinaryData
  // uploadFile = [];
  // documentModel = {};
  constructor() { }

  ngOnInit(): void {
  }
  // onClickFileInputButton(): void {
  //   this.fileInput.nativeElement.click();
  // }
  // browseFile(event: { target: { files: any[]; }; }) {
  //   this.flagUploaded = false;
  //   if (event.target.files && event.target.files[0]) {
  //     var reader = new FileReader();
  //     let file = event.target.files[0];
  //     this.fileType = file.type;
  //     reader.readAsDataURL(file);
  //     reader.onload = (event: any) => {
  //       this.uploadedData = file;
  //       this.uploadRawData = event.target.result;
  //       this.uploadedUrl.push(this.uploadedData);

  //       let filestring = btoa(this.uploadRawData);
  //       this.uploadBinaryData = this.fileSringToBinary(filestring);
  //       this.documentModel = {
  //         name: file.name,
  //         document: this.uploadBinaryData,
  //         path: ""
  //       };
  //       this.uploadFile.push(this.documentModel);
  //     };
  //   }
  // }
  // filesDropped(files: FileHandle[]): void {
  //   this.flagUploaded = false;
  //   files.forEach((file => {
  //     if (file) {
  //       var reader = new FileReader();
  //       this.fileType = file.file.type;
  //       reader.readAsDataURL(file.file);
  //       reader.onload = (event: any) => {
  //         this.uploadedData = file;
  //         this.uploadRawData = event.target.result;
  //         this.uploadedUrl.push(this.uploadedData);
  //         let filestring = btoa(this.uploadRawData);
  //         this.uploadBinaryData = this.fileSringToBinary(filestring);
  //         this.documentModel = {
  //           name: file.file.name,
  //           document: this.uploadBinaryData,
  //           path: ""
  //         };
  //         this.uploadFile.push(this.documentModel);
  //       };
  //     }
  //   }));
  // }
  // fileSringToBinary(strData: string): any {
  //   const byteCharacters = atob(strData);
  //   const byteNumbers = new Array(byteCharacters.length);
  //   for (let i = 0; i < byteCharacters.length; i++) {
  //     byteNumbers[i] = byteCharacters.charCodeAt(i);
  //   }
  //   return byteNumbers;
  // }
  // deleteImage(file) {
  //   this.uploadedUrl.forEach((item, index) => {
  //     if (item === file) {
  //       this.uploadedUrl.splice(index, 1);
  //       this.uploadFile.splice(index, 1);
  //     }
  //   });

  // }
  // setImageBinary(file) {
  //   this.fileSringToBinary(file)
  // }
  // downloadFile(file) {
  //   if (file.document) {
  //     var fileDownlaoded = atob(file.document);
  //     var link = document.createElement("a");
  //     link.download = file.name;
  //     link.href = fileDownlaoded;
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);
  //   }
  //   else {
  //     var reader = new FileReader();
  //     var result;
  //     reader.readAsDataURL(file);
  //     reader.onload = (event: any) => {
  //       result = event.target.result;
  //       var link = document.createElement("a");
  //       link.download = file.name;
  //       link.href = result;
  //       document.body.appendChild(link);
  //       link.click();
  //       document.body.removeChild(link);
  //     };
  //   }

  // }
}
