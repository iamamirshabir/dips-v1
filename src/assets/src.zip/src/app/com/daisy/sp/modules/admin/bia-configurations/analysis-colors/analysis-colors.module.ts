import { NgModule } from '@angular/core';
import { AnalysisColorsComponent } from './analysis-colors.component';
import { Routes, RouterModule } from '@angular/router';
import { AnalysisColorsListComponent } from './analysis-colors-list/analysis-colors-list.component';
import { AnalysisColorsFormComponent } from './analysis-colors-form/analysis-colors-form.component';
import { ComponentsModule } from '../../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
const routes: Routes = [
  {
    path: '', component: AnalysisColorsComponent,
    children: [
      { path: 'analysis-colors-list', component: AnalysisColorsListComponent },
      { path: 'analysis-colors-form', component: AnalysisColorsFormComponent }
    ]
  }
]; 

@NgModule({
  declarations: [AnalysisColorsListComponent, AnalysisColorsFormComponent,AnalysisColorsComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[AnalysisColorsFormComponent]
})
export class AnalysisColorsModule { }
