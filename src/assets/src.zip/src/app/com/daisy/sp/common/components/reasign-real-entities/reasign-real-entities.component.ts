import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { MainLayoutService } from '../../../main-layout/main-layout-service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-reasign-real-entities',
  templateUrl: './reasign-real-entities.component.html',
  styleUrls: ['./reasign-real-entities.component.sass'],
})
export class ReasignRealEntitiesComponent implements OnInit,AfterViewInit {
  listRealEntities:any[] =[]; 
  flatListRealEntities:any[] =[]; 
  addedRealEntities:any[] =[];
  modalData: any;
  contentHeight;
  recordName:any='';
  inputInAll:string = "";
  inputInSelected:string = ""; 
  @ViewChild('matDialog') matDialog: ElementRef;

  private _transformer = (node: any, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      id: node.id,
      level: level,
    };
  }
  treeControl = new FlatTreeControl<any>(node => node.level, node => node.expandable);
  treeFlattener = new MatTreeFlattener(this._transformer, node => node.level, node => node.expandable, node => node.children);
  treeControlAdded = new FlatTreeControl<any>(node => node.level, node => node.expandable);
  treeFlattenerAdded = new MatTreeFlattener(this._transformer, node => node.level, node => node.expandable, node => node.children);
  dataSourceAll = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  dataSourceSelected = new MatTreeFlatDataSource(this.treeControlAdded, this.treeFlattenerAdded); 
  checklistSelectionAll = new SelectionModel<any>(true);
  checklistSelectionAdded = new SelectionModel<any>(true); 

  constructor(private mainLayoutService: MainLayoutService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ReasignRealEntitiesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.modalData = JSON.parse(JSON.stringify(data)); 
  } 
  hasChild = (_: number, node: any) => node.expandable;

  ngOnInit(): void {
    this.listRealEntities = [];
    this.flatListRealEntities = [];
    this.addedRealEntities = [];
    this.listRealEntities = JSON.parse(JSON.stringify([this.mainLayoutService.getRealEntitiesList()]));
    this.setEmptyChildren(this.listRealEntities); 
    let listNodesClone = JSON.parse(JSON.stringify(this.listRealEntities))
    this.flatListRealEntities = this.change_tree_to_list({children:listNodesClone},this.flatListRealEntities); 
    this.dataSourceAll.data = listNodesClone;
    if(this.modalData.records && this.modalData.records.length == 1){ 
      this.addedRealEntities = this.modalData.records[0].realEntities;
      this.recordName = this.modalData.records[0].name; 
      this.dataSourceSelected.data = this.change_list_to_tree(this.addedRealEntities); 
    // for (let i = 0; i < this.treeControlAdded.dataNodes.length; i++) {
    //   if(!this.checklistSelectionAll.isSelected(this.treeControlAdded.dataNodes[i]))
    //      this.checklistSelectionAll.toggle(this.treeControlAdded.dataNodes[i]);
    //      this.treeControl.expand(this.treeControl.dataNodes[i])
    // } 
    }else{ 
      this.addedRealEntities = [];
      this.recordName = '';
    } 
  }
 
  ngAfterViewInit(){
    this.contentHeight = (this.matDialog.nativeElement.offsetHeight-110)+'px';
  } 

  saveRealEntity() {
    if(this.modalData.records && this.modalData.records.length > 0){
      this.modalData.records.forEach(element => {
        element.realEntities = this.addedRealEntities;
      });
    }
    this.dialogRef.close(this.modalData);
  }

  closeRealEntityModal() {
    this.dialogRef.close(null);
  }

  changeRealEntitiesHandler(type){
   if(type == 'addAll'){ 
    this.addedRealEntities = [];
    this.dataSourceSelected.data = []; 
    this.addedRealEntities = this.change_tree_to_list({children:this.listRealEntities},this.addedRealEntities); 
    this.dataSourceSelected.data = this.change_list_to_tree(this.addedRealEntities); 
    this.checklistSelectionAll = new SelectionModel<any>(true);
   }else if(type == 'removeAll'){
     this.dataSourceSelected.data = []; 
    this.addedRealEntities = []; 
    this.checklistSelectionAdded = new SelectionModel<any>(true);
   }else if(type == 'remove'){
     if(this.checklistSelectionAdded.selected && this.checklistSelectionAdded.selected.length>0){ 
      this.checklistSelectionAdded.selected.forEach(element => {
        this.addedRealEntities = this.addedRealEntities.filter(item => item.id != element.id);
      }) 
      this.dataSourceSelected.data = [];
      this.dataSourceSelected.data = this.change_list_to_tree(this.addedRealEntities); 
      this.checklistSelectionAdded = new SelectionModel<any>(true);
     }
     for(let i = 0; i < this.treeControlAdded.dataNodes.length; i++){ 
          this.treeControlAdded.expand(this.treeControlAdded.dataNodes[i])
      }
   }else if(type == 'add'){
     if(this.checklistSelectionAll.selected && this.checklistSelectionAll.selected.length>0){ 
       this.dataSourceSelected.data = []; 
       this.checklistSelectionAll.selected.forEach(element => { 
        let node = this.flatListRealEntities.find(item => item.id == element.id); 
        let found = this.addedRealEntities.find(item => item.id == node.id); 
        if(!found){
          this.addedRealEntities.push(node); 
        }  
      }) 
      this.dataSourceSelected.data = this.change_list_to_tree(this.addedRealEntities);
      this.checklistSelectionAll = new SelectionModel<any>(true);
     }
     for(let i = 0; i < this.treeControlAdded.dataNodes.length; i++){ 
          this.treeControlAdded.expand(this.treeControlAdded.dataNodes[i])
      }
   }
  }

  change_list_to_tree(list) {
    var map = {}, node, roots = [], i;    
    for (i = 0; i < list.length; i += 1) {
      map[list[i].id] = i; 
      list[i].children = []; 
    }    
    for (i = 0; i < list.length; i += 1) {
      node = list[i];
      if (node.parent && node.parent.id !== null && this.ifParentExists(list,node.parent)) { 
        list[map[node.parent.id]].children.push(node);
      } else {
        roots.push(node);
      }
    }
    return roots;
  }

  ifParentExists(list,parent){
    let isFind:Boolean = false; 
    let found = list.find(item => item.id == parent.id); 
    if(found){
      isFind = true;
    }else{
      isFind = false;
    }
    return isFind; 
  }

  change_tree_to_list(treeNode, list) {
    if(treeNode.children && treeNode.children.length>0){ 
       treeNode.children.forEach(element => {
        list.push(element);
        if(element.children && element.children.length>0){
          this.change_tree_to_list(element,list);
        } 
      });
    }
    return list;
  }  
 
  selectionChangeHandlerAll(node){
    this.checklistSelectionAll.toggle(node)
  }

  selectionChangeHandlerAdded(node){
    this.checklistSelectionAdded.toggle(node)
  }

  clearAllSelection(selections){
    selections.forEach(node => {
      this.checklistSelectionAll.toggle(node); 
    }); 
  }

  setEmptyChildren(treeData) {
    treeData.forEach(element => {
      element.id = element.id.toString();
      element.checked = true;
      if (element.children && element.children.length > 0) {
          element.children = element.children.sort((a, b) => a.order - b.order);
        this.setEmptyChildren(element.children);
      } else {
        element.children = [];
      }
    });
  }
  filterChanged(value){

  }
}
