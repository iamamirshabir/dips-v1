import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { environment } from "src/environments/environment";
import { Api } from "../../../../utils/api";


@Injectable({ providedIn:'root' })

export class ItServiceTypeService {

    constructor(private router:Router, private http:HttpClient){ }

save(data){
 return this.http.post(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_IT_SERVICE_TYPE_SAVE, data)
}

update(data){
    return this.http.post(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_IT_SERVICE_TYPE_UPDATE, data)
   }

delete(ids){
 return this.http.post(`${environment.baseUrl}` + Api.BIA_CONFIGURATIONS_IT_SERVICE_TYPE_DELETE_BY_ID, ids)
}

listByOrganisationId(id){
   return this.http.get(`${environment.baseUrl}`  + Api.BIA_CONFIGURATIONS_IT_SERVICE_TYPE_BY_ORG_ID + id);
}

}