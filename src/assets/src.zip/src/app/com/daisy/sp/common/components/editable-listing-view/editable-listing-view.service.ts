import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { EditableListingView } from './editable-listing-view.interface';

@Injectable({
  providedIn: 'root'
})
export class EditableListingViewService {

  constructor() { }
  private subject = new Subject<any>();

  sendListingView(listingView: EditableListingView) {
    this.subject.next(listingView);
  }

  clearListingView() {
    this.subject.next();
  }

  onListingView(): Observable<EditableListingView> {
    return this.subject.asObservable();
  }
}
