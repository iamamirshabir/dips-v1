import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ConfirmationComponent } from '../confirmation/confirmation.component';

@Component({
  selector: 'app-confirmation-component',
  templateUrl: './confirmation-component.component.html',
  styleUrls: ['./confirmation-component.component.sass']
})
export class ConfirmationComponentComponent implements OnInit {

  constructor(private readonly dialogRef: MatDialogRef<ConfirmationComponent, boolean>) { }

  ngOnInit(): void {
  }

  onClickCancel() {
    this.dialogRef.close(false);
  }

  onClickConfirm() {
    this.dialogRef.close(true);
  }
}
