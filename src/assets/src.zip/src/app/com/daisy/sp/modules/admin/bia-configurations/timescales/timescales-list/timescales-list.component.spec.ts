import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimescalesListComponent } from './timescales-list.component';

describe('TimescalesListComponent', () => {
  let component: TimescalesListComponent;
  let fixture: ComponentFixture<TimescalesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TimescalesListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TimescalesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
