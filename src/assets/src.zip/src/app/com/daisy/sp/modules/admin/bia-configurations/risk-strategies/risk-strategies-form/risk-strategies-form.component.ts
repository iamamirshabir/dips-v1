import { Component, OnInit, Inject } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RealEntityFormComponent } from '../../../real-entity/real-entity-form/real-entity-form.component';

@Component({
  selector: 'app-risk-strategies-form',
  templateUrl: './risk-strategies-form.component.html',
  styleUrls: ['./risk-strategies-form.component.sass']
})
export class RiskstratgiesFormComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  public breakpoint: number;
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RealEntityFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
  }
  public ngOnInit(): void {
    this.modalFormFroup = this.fb.group({
      id: [null],
      name: [null, [Validators.required]],
      description: [null],
      order: [null],
      organisation: [this.organisation],
      version: [null],
    });
    // this.breakpoint = window.innerWidth <= 600 ? 1 : 1; // Breakpoint observer code
    if (this.modalData) {
      this.modalFormFroup.patchValue(this.modalData.data);
      if (this.modalData.pageState === this.PageState.VIEW_STATE) {
        this.modalFormFroup.disable();
      }
    }
  }

  saveFormData(): void {
    if (this.modalFormFroup.invalid) {
      return;
    }
    this.modalData.data = this.modalFormFroup.value;
    this.dialogRef.close(this.modalData);
  }

  closeModal(): void {
    this.dialogRef.close(null);
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  public onResize(event: any): void {
    // this.breakpoint = event.target.innerWidth <= 600 ? 1 : 1;
  }
}