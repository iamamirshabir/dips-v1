import { TestBed } from '@angular/core/testing';

import { RecoveryPoliciesService } from './recovery-policies.service';

describe('RecoveryPoliciesService', () => {
  let service: RecoveryPoliciesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecoveryPoliciesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
