import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { BiaRecordTabComponent } from './bia-record-tab.component';
import { ImpactAssessmentComponent } from './impact-assessment/impact-assessment.component';
import { ImpactAssessmentMatrixComponent } from './impact-assessment/impact-assessment-matrix/impact-assessment-matrix.component';
import { GeneralInformationComponent } from './general-information/general-information.component';
import { ProcessesListComponent } from './processes/processes-list/processes-list.component';
import { ProcessesFormComponent } from './processes/processes-form/processes-form.component';
import { LocationsComponent } from './locations/locations.component';
import { RiskFormComponent } from './risks/risk-form/risk-form.component';
import { RisksComponent } from './risks/risk-list/risks.component';

import { ProductsServicesListComponent } from './product-services/products-services-list/products-services-list.component';
import { ImpactAssessmentOverrideComponent } from './impact-assessment/impact-assessment-override/impact-assessment-override.component';
import { ImpactAssessmentSummaryReasonComponent } from './impact-assessment/impact-assessment-summaryReason/impact-assessment-summaryReason.component';
import { ResourcesListComponent } from './resources/resources-list/resources-list.component';
import { ItServicesComponent } from './it-services/it-services.component';
import { SuppliersListComponent } from './suppliers/suppliers-list/suppliers-list.component';
import { BusinessAreaListComponent } from './business-area/business-area-list/business-area-list.component';



const routes: Routes = [
    {
        path: '', component: BiaRecordTabComponent,

        children: [
            { path: 'processes-list', component: ProcessesListComponent , },
            { path: 'processes-form', component: ProcessesFormComponent , },
            { path: 'impact-assesment', component: ImpactAssessmentComponent , },
            { path: 'products-services-list', component: ProductsServicesListComponent , },
            { path: 'general-information', component: GeneralInformationComponent , },
            { path: 'locations', component: LocationsComponent , },
            { path: 'risks', component: RisksComponent , },
            { path: 'risks-form', component: RiskFormComponent , },
            { path: 'resources-list', component: ResourcesListComponent,  },
            { path: 'it-services', component: ItServicesComponent , },
            { path: 'supplier-list', component: SuppliersListComponent , },
            { path: 'business-area-list', component: BusinessAreaListComponent , },
        ]

    }

];

@NgModule({

    declarations: [
        BiaRecordTabComponent,
        ProcessesListComponent,
        LocationsComponent,
        ProcessesFormComponent,
        ImpactAssessmentComponent,
        ImpactAssessmentMatrixComponent,
        GeneralInformationComponent,
        RisksComponent,
        RiskFormComponent,
        ProductsServicesListComponent,
        ImpactAssessmentOverrideComponent,
        ImpactAssessmentSummaryReasonComponent,
        ResourcesListComponent,
        ItServicesComponent,
        SuppliersListComponent,
        BusinessAreaListComponent,
    ],
    imports: [
        ComponentsModule,
        AngularMaterialModule,
        RouterModule.forChild(routes)
    ],
    entryComponents: [ImpactAssessmentMatrixComponent, ImpactAssessmentOverrideComponent, ImpactAssessmentSummaryReasonComponent]

})
export class BIARecordTabModule { }
