import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from '../../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { CustomFieldComponent } from './custom-field.component';
import { CustomFieldListComponent } from './custom-field-list/custom-field-list.component';
import { CustomFieldFormComponent } from './custom-field-form/custom-field-form.component';
import { CfRecordTypeEditorComponent } from './custom-field-form/editor/cf-record-type-editor/cf-record-type-editor.component';


const routes: Routes = [
  {
    path: '', component: CustomFieldComponent,
    children: [
      { path: 'custom-field-list', component: CustomFieldListComponent },
      { path: 'custom-field-form', component: CustomFieldFormComponent },
      { path:'cf-record-type-editor',component:CfRecordTypeEditorComponent}

    
    ]
  }
]; 

@NgModule({
  declarations: [
     CustomFieldComponent,
     CustomFieldListComponent,
     CustomFieldFormComponent,
     CfRecordTypeEditorComponent
    ],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes) 
  ],
  entryComponents:[CustomFieldFormComponent]
})
export class CustomFieldModule { }
