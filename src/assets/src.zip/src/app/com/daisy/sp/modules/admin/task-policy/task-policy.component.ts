import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-policy',
  templateUrl: './task-policy.component.html',
  styleUrls: ['./task-policy.component.sass']
})
export class TaskPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
