import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../utils/api';

@Injectable({
  providedIn: 'root'
})

export class CustomFieldService {

  constructor(private router: Router, private httpClient: HttpClient) { }

  saveCustomField(data) {
    return this.httpClient.post(`${environment.baseUrl + Api.ADMIN_CUSTOM_FIELD_SAVE}`, data);
  }

  getcustomFieldsbyRecordTypeId(id) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ADMIN_CUSTOM_FIELD_FIND_BY_RECORD_TYPE + id);
  }
  getCustomFieldById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ADMIN_CUSTOM_FIELD_FIND_BY_ID + id);
    
  }
  getAllCustomFields(){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ADMIN_CUSTOM_FIELD_FIND_ALL );
  }
  getCustomFieldTypes(){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.ADMIN_CUSTOM_FIELD_TYPE_FIND_ALL );
  }

  deleteCustomField(id) {
    return this.httpClient.post(`${environment.baseUrl + Api.ADMIN_CUSTOM_FIELD_DELETE_BY_ID}`, id);
  }


}