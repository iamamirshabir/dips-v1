import { Component, OnInit, Inject } from '@angular/core';


@Component({
  selector: 'app-category-resource',
  templateUrl: './category-resource.component.html',
  styleUrls: ['./category-resource.component.sass']
})
export class CategoryResourceComponent  implements OnInit {
  
  constructor() {
  }
 
  ngOnInit(): void {
}
   
}
