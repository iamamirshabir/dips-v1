import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ExpandListingView } from './expand-listing-view.interface';


@Injectable({
  providedIn: 'root'
})
export class ExpandListingViewService {

  constructor() { }

  private subjectExpand = new Subject<any>();

  sendExpandedListingView(exlistingView: ExpandListingView) {
      this.subjectExpand.next(exlistingView);
  }

  clearExpandedListingView() {
      this.subjectExpand.next();
  }

  onExpandedListingView(): Observable<ExpandListingView> {
          return this.subjectExpand.asObservable();
  }
}
