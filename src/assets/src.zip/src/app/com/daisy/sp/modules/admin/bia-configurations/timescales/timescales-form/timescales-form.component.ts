
import { Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTable } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { TimeScalesConstant } from 'src/app/com/daisy/sp/utils/constants/timeScales-constant';
import { LoaderService } from 'src/app/core-services/loader.service';

@Component({
  selector: 'app-timescales-form',
  templateUrl: './timescales-form.component.html',
  styleUrls: ['./timescales-form.component.sass']
})
export class TimescalesFormComponent extends BaseClass implements OnInit {
  displayColumns = [ 'duration', 'measure', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  timeScaleForm: FormGroup;
  submitted = false;
  ButtonActions = ButtonActions;
  contactTypes: any[] = [];
  routeParams: any;
  timeScale_Id: any;
  timeScaleObject: any;
  timeScales: any = [];
  disableType: boolean = false;
  timePoints: FormArray = this.formBuilder.array([]);
  @ViewChild('table') table: MatTable<any>;
  selectedType: any;

  constructor(private formBuilder: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.timeScaleForm.controls; }
  ngOnInit(): void {

    this.timeScaleForm = this.formBuilder.group({
      id: [null],
      organisation: [null],
      name: ['', [Validators.required]],
      description: [''],
      version: [null],
      type: [null],
      timePoints: this.timePoints

    });
    this.loadingService.enableLoading();
    this.timeScales = TimeScalesConstant.timeScalesTypes;

  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.timeScale_Id = this.routeParams['id'];
    //  this.cat_IT_data = this.routeParams['data'];
    if (this.timeScale_Id != null) {
      this.getTimeScaleById(this.timeScale_Id);
      this.disableType = true;
    }  else {
      this.addRow();
    }

  }
  getTimeScaleById(id) {
    this.showLoader();
    this.timeScalesService.getTimeScalesListById(id).subscribe(data => {
      this.hideLoader();
      this.timeScaleObject = data;
      if(this.timeScaleObject['type']){
        this.selectTimeScaleType(this.timeScaleObject['type'])
      }
      if (this.timeScaleObject['timePoints'].length >= 1) {
        this.patchLists(this.timeScaleObject['timePoints']);
      }
      if(this.timeScaleObject['timePoints'].length == 0){
        this.addRow();
      }

      this.patchFormData();
    }, error => {
      this.hideLoader();
    });

  }

  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.duration === f2.duration;
  }
  
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
    } else {
      this.bindJsonObjectToFormObject(this.timeScaleObject, this.timeScaleForm);
    }
  }
  patchLists(res) {
    var productValues = res;
    productValues.forEach(Rows => {
      this.addRow();
      this.timePoints.patchValue(res);
      this.updateView();
    });

  }
  addRow(noUpdate?: boolean) {
    const row = this.formBuilder.group({
      id: [null],
      custom: [null],
      duration: [null, Validators.required],
      measure: [null, Validators.required],
      version: [null],
      externalUid:[null],
      timeInMinutes:	[null],
      systemFieldType: [null],
      organisation: this.organisation
    });
    this.timePoints.push(row);
    if (!noUpdate) { this.updateView(); }

  }
  updateView() {
    this.dataSource.next(this.timePoints.controls);
  }
  deleteRow(index: number, row) {
    const control = this.timeScaleForm.get('timePoints') as FormArray;
    if (this.timePoints.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      control.removeAt(index);
      this.updateView();
      this.alertService.success("Successfully Deleted");
    }
    else {
      control.removeAt(index);
      this.updateView();
    }
  }

  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    if (this.timeScaleForm.invalid) {
      return;
    }
    this.timeScaleForm.controls['organisation'].setValue(this.organisation);
    this.showLoader();
    this.timeScalesService.saveTimeScales(this.timeScaleForm.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        }
        // else if (btnType == ButtonActions.SAVE_AND_CONT) {
        //   this.contactObject = res;
        //   this.routedPageState = PageState.EDIT_STATE;
        //   this.patchFormData();
        // }
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.BIA_CONFIG_TIMESCALES_LIST);
  }

selectTimeScaleType(value){

let getType = this.timeScales.find(ele => ele.type == value);
this.selectedType = getType.type;
}

}
