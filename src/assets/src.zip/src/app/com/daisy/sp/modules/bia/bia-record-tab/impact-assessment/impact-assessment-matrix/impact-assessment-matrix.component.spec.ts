import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImpactAssessmentMatrixComponent } from './impact-assessment-matrix.component';

describe('ImpactAssessmentMatrixComponent', () => {
  let component: ImpactAssessmentMatrixComponent;
  let fixture: ComponentFixture<ImpactAssessmentMatrixComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImpactAssessmentMatrixComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImpactAssessmentMatrixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
