import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {  Component, OnDestroy, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { SpChipFormFieldComponent } from '../../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { GlobalConstants } from '../../../../utils/global-constants';




@Component({
  selector: 'app-role-assignment',
  templateUrl: './role-assignment.component.html',
  styleUrls: ['./role-assignment.component.sass']
})
export class RoleAssignmentComponent extends BaseClass implements OnInit,OnDestroy {
  @ViewChildren('ownerContact') ownerContact: SpChipFormFieldComponent;
  @ViewChildren('firstApprovertest') firstApprovertest: SpChipFormFieldComponent;
  @ViewChildren('secondApprover') secondApprover: SpChipFormFieldComponent;
  @ViewChildren('Escalation') Escalation: SpChipFormFieldComponent;
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  isLoading = true;
  modalFormGroup: FormGroup;
  memberDropped: string[];
  globals: GlobalConstants;
  roleAssignmentData: any;
  filteredProperties$: Observable<[]>;
  constructor(
    private fb: FormBuilder, globals: GlobalConstants, private router: Router,
    protected activatedRoute: ActivatedRoute) {
    super();
    this.globals = globals;
    this.activateRoute.queryParams.subscribe(val => {
      this.initializePageData();
    })
  }
  

  initializePageData() {
    this.modalFormGroup = this.fb.group({
      roleAssignmentList: this.fb.array([]),
      taskType:[null]
    });
    
    this.isLoading = false;
    this.getRoleAssignments();
  }
  ngOnInit(): void {
    this.globals.isDragOnMultiColumns = true;
    this.filteredProperties$ = this.modalFormGroup.valueChanges.pipe(
      map(value => {
        if ( value.taskType == null) {
          return value.roleAssignmentList.map((p, index) => ({ ...p, index }));
        }
        else{
          if(value.taskType.length >0){
            let list:any =[];
            for(let i=0;i<value.taskType.length;i++ ){
              const taskTypeLower = value.taskType[i].name.toLowerCase();
              let filteredValue= value.roleAssignmentList.filter(p =>
                p.taskTypeName.toLowerCase().includes(taskTypeLower) ).map(p => ({p, index: value.roleAssignmentList.indexOf(p) }));
                if(filteredValue.length > 0){
                list.push(filteredValue[0]) ; 
                }
              }
              return list
            } 
          else{
            return value.roleAssignmentList.map((p, index) => ({ ...p, index }));
          }
        }
      }),
      );
  }
  get roleAssignmentProperties(): FormArray {
    return <FormArray>this.modalFormGroup.get('roleAssignmentList');
  }
  getModalFormGroup(index: number): FormGroup {
    return this.roleAssignmentProperties.at(index) as FormGroup;
  }
  getRoleAssignments() {
    this.showLoader();
    this.roleAssignmentService.getRoleAssignmentByOrgId().
      subscribe(data => {
        this.hideLoader();
        this.roleAssignmentData = data;
        this.patchLists();
      }, error => {
        this.hideLoader();
      })
  }

  patchLists() {
    if (this.roleAssignmentData.length > 0) {
      let i = 0;
      this.roleAssignmentData.forEach(element => {
        let tempList = [];
        for (var j = 0; j < 4; j++) {
          tempList.push('list-' + i + '-col-' + j);
        }
        i++;
        this.globals.DROPPED_ID_ARRAY.push(tempList);
        this.addRow();
        element['taskTypeName'] = element['taskType']['name'];
      });
    }
    this.modalFormGroup.controls.roleAssignmentList.patchValue(this.roleAssignmentData);
    this.updateView();
  }

  addRow() {
    var row = this.fb.group({
      id: [null],
      taskType: [null],
      name: [null],
      owner: [null],
      firstApprover: [null],
      secondApprover:[null],
      escalation:[null],
      taskTypeName: [null],
      version: [null],
    });
    const control = this.modalFormGroup.get('roleAssignmentList') as FormArray;
    control.insert(0, row);
    this.updateView();
  }

  goBackToMainPage() {
    this.routingService.navigate(['/shadowplanner']);
  }

  dropFromSearch(event: CdkDragDrop<string[]>, roleAssignment, cellName, currentData) {
    this.memberDropped = event.previousContainer.data;
    let index =   this.modalFormGroup.controls.roleAssignmentList.value.findIndex(val => val == currentData.value);
    if (index >= 0) {
      for(var i=0;i<this.memberDropped.length;i++){
        this.selectedEditableField(cellName, index, this.memberDropped[i]);
      }
    }

  }
  updateView() {
    this.dataSource.next(this.modalFormGroup.controls.roleAssignmentList["controls"]);
  }
  selectedEditableField(cellName, index, newValue) {
    switch (cellName) {
      case 'owner':
        this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].owner.value.push(newValue);
        this.ownerContact['_results'][index].patchDataInControls( this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].owner.value);
        break;
      case 'firstApprover':
        this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].firstApprover.value.push(newValue);
        this.firstApprovertest['_results'][index].patchDataInControls(  this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].firstApprover.value);
        break;
      case 'secondApprover':
        this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].secondApprover.value.push(newValue);
        this.secondApprover['_results'][index].patchDataInControls(  this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].secondApprover.value);
        break;
      case 'escalation':
        this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].escalation.value.push(newValue);
        this.Escalation['_results'][index].patchDataInControls( this.modalFormGroup.controls.roleAssignmentList["controls"][index]["controls"].escalation.value);
        break;
    }
       this.updateView();
  }
  ngOnDestroy() {
    this.globals.isDragOnMultiColumns = false;
  }
  onSubmit(buttonAction) {
    if (this.modalFormGroup.invalid) {
      return;
    }
    this.roleAssignmentService.saveRoleAssignments(this.modalFormGroup.controls.roleAssignmentList.value).
      subscribe(data => {
        if (buttonAction == ButtonActions.SAVE) {
          this.goBackToMainPage();
          this.alertService.success('updation.successfull', true);
        }
        else if (buttonAction == ButtonActions.SAVE_AND_CONT) {
          this.alertService.success('updation.successfull', true);
          this.navigationHandlerAfterSave(buttonAction, data);
        }
      }, error => {
        console.log(error)
      })
  }

}



