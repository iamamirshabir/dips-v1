import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditableListingViewComponent } from './editable-listing-view.component';

describe('EditableListingViewComponent', () => {
  let component: EditableListingViewComponent;
  let fixture: ComponentFixture<EditableListingViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditableListingViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditableListingViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
