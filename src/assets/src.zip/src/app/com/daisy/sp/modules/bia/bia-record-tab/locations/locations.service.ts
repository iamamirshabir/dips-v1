import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
  
  export class LocationsService
  {
    constructor(private router: Router, private httpClient: HttpClient) { }

      saveLocations(data)
      {
          return this.httpClient.post(`${environment.baseUrl + Api.BIA_LOCATIONS_SAVE}`, data);
      }
      saveAllLocations(data)
      {
        return this.httpClient.post(`${environment.baseUrl + Api.BIA_LOCATIONS_SAVE_ALL}`, data);
      }
      updateLocation(data)
      {
        this.httpClient.post(`${environment.baseUrl + Api.BIA_LOCATIONS_UPDATE}`, data);
      }
      deleteLocationById(id)
      {
        return this.httpClient.post(`${environment.baseUrl + Api.BIA_LOCATIONS_DELETE_BY_ID}`, id);
      }
      getLocationByBiaId(id)
      {
        return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_LOCATIONS_FIND_BY_BIA_ID+id);
      }
      getLocationByOrgId(id)
      {
        return this.httpClient.get<any>(`${environment.baseUrl}`+Api.BIA_LOCATIONS_FIND_BY_ORG_ID+id);
      }
      saveBiaRecord(biaRecord): Observable<any> {
        return this.httpClient.post(`${environment.baseUrl + Api.BIA_SAVE_RECORD}`, biaRecord);
    }
  }
