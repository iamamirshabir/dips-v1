import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BCPComponent } from './bcp.component';

@NgModule({
  declarations: [BCPComponent],
  imports: [
    CommonModule
  ]
})
export class BCPModule { }
