import { Component, OnInit, Inject, EventEmitter, Output, ViewChild } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormArray, FormControl } from '@angular/forms';
import { BehaviorSubject, timer } from 'rxjs';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { PageState } from '../../../../utils/constants/page-state-constants';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/core-services/loader.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { MatTable } from '@angular/material/table';
import { SystemRecords } from '../../../../utils/constants/system-records-constant';
import { RecordTypes } from '../../../../utils/constants/record-types';
import { RecordTypesConstants } from '../../../../utils/constants/record-types-constant';
import { CustomFieldTypesConstants } from '../../../../utils/constants/custom_field_types';




@Component({
  selector: 'app-custom-field-form',
  templateUrl: './custom-field-form.component.html',
  styleUrls: ['./custom-field-form.component.sass']
})
export class CustomFieldFormComponent extends BaseClass implements OnInit {
  public modalFormFroup: FormGroup;

  displayColumns = ['#', 'name', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  routeParams: any;
  customFieldListItem: FormArray = this.fb.array([]);
  @ViewChild('table') table: MatTable<any>;
  submitted = false;
  customFieldTypes: any = [];
  checkboxes: any = [];
  recordTypes: any = [];
  ButtonActions = ButtonActions;
  selectedFieldType: any;
  customField_Id: any;
  rec_data: any;
  customFieldData: any;
  showList: boolean = false;
  showRecordTypes: boolean = false;
  disabledCustomField: boolean = false;

  constructor(private fb: FormBuilder, protected activatedRoute: ActivatedRoute,
    private router: Router,
    private loadingService: LoaderService) {
    super();
  }
  get f() { return this.modalFormFroup.controls; }
  public ngOnInit(): void {

    this.modalFormFroup = this.fb.group({
      id: [null],
      name: [null, [Validators.required]],
      description: [''],
      mandatory: [false],
      validated: [false],
      customFieldType: [null, [Validators.required]],
      recordType: [null, [Validators.required]],
      order: [null],
      organisation: [this.organisation],
      version: [null],
      systemRecordType: this.fb.array([]),
      customFieldListItem: this.customFieldListItem
    });

    this.checkboxes = SystemRecords.Record_Names;
    this.recordTypes = RecordTypesConstants.Record_Data;
    this.customFieldTypes = CustomFieldTypesConstants.Custom_Field_Data;
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.customField_Id = this.routeParams['id'];
    this.rec_data = this.routeParams['data'];
    if (this.customField_Id) {
      this.getCustomFieldbyId();
      this.disabledCustomField = true;
    }
    else {
      this.addRow();
    }

  }

  getCustomFieldbyId() {
    this.showLoader();
    this.customFieldService.getCustomFieldById(this.customField_Id).
      subscribe(data => {
        this.hideLoader();
        this.customFieldData = data;
        if (this.customFieldData['customFieldType']) {
          this.selectedCustomType(this.customFieldData['customFieldType']);
        }
        if (this.customFieldData['customFieldListItem'].length >= 1) {
          this.patchLists(this.customFieldData['customFieldListItem']);
        }
        if (this.customFieldData['systemRecordType'].length >= 1) {
          let systemRecordData = this.customFieldData['systemRecordType'];
          for (var i = 0; i < systemRecordData.length; i++) {
            let index = this.checkboxes.findIndex(ele => ele.type == systemRecordData[i]);
            let obj = this.checkboxes[index];
            this.onRoleChangeCheckbox(true, obj)
          }
        }

        this.patchFormData();
      }, error => {
        this.hideLoader();
      })
  }
  patchLists(res) {
    var productValues = res;
    productValues.forEach(Rows => {
      this.addRow();
      this.customFieldListItem.patchValue(res);
      this.updateView();
    });

  }

  selectCustomType(event) {
    this.selectedFieldType = event;
    this.selectedCustomType(this.selectedFieldType);
  }
  selectedCustomType(value) {
    this.showList = false;
    this.showRecordTypes = false;
    switch (value) {
      case CustomFieldTypesConstants.singleList:
        this.showList = true;

        break;
      case CustomFieldTypesConstants.multipleList:
        this.showList = true;

        break;
      case CustomFieldTypesConstants.systemRecord:
        this.showRecordTypes = true;
        break;
    }
  }
  patchFormData() {
    if (this.routedPageState === PageState.ADD_STATE) {
    } else {
      this.bindJsonObjectToFormObject(this.customFieldData, this.modalFormFroup);
    }
  }
  onSubmit(btnType: ButtonActions) {
    this.submitted = true;
    this.modalFormFroup.value['customFieldListItem'].forEach(element => {
      if (element.value == null) {
        this.checkCustomFieldType(this.modalFormFroup.controls['customFieldType'].value);
      }
    });

    if (this.modalFormFroup.invalid) {
      return;
    }
    this.showLoader();
    this.customFieldService.saveCustomField(this.modalFormFroup.value).
      subscribe(res => {
        this.hideLoader();
        if (this.routedPageState === 1) {
          this.alertService.success("Successfully Created");
        }
        else {
          this.alertService.success("Successfully Updated")
        }
        if (btnType == ButtonActions.SAVE) {
          this.goBackToMainPage();
        }
      }, error => {
        this.hideLoader();
      })
  }


  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.BIA_CONFIG_CUSTOM_FIELD_LIST);
  }

  addRow(noUpdate?: boolean) {
    const row = this.fb.group({
      id: [null],
      value: [null, Validators.required],
      sortOrder: [null],
      version: [null],
    });
    this.customFieldListItem.push(row);
    this.setSortOrder(this.customFieldListItem.controls, 'sortOrder');
    if (!noUpdate) { this.updateView(); }

  }
  updateView() {
    this.dataSource.next(this.customFieldListItem.controls);
  }
  deleteRow(index: number, row) {
    const control = this.modalFormFroup.get('customFieldListItem') as FormArray;
    if (this.customFieldListItem.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      control.removeAt(index);
      this.updateView();
      this.alertService.success("Successfully Deleted");
    }
    else {
      control.removeAt(index);
      this.updateView();
    }
  }


  dropTable(event: CdkDragDrop<any[]>) {
    let listObjectives = this.modalFormFroup.get("customFieldListItem") as FormArray;
    const prevIndex = listObjectives.controls.findIndex((d) => d === event.item.data);
    moveItemInArray(listObjectives.controls, prevIndex, event.currentIndex);
    this.table.renderRows();
    this.setSortOrder(listObjectives.controls, 'sortOrder');

  }

  onRoleChangeCheckbox(ev, obj) {
    let list: any = [];
    let index = this.checkboxes.findIndex(ele => ele.type == obj.type);
    list = this.modalFormFroup.get("systemRecordType") as FormArray;
    if (ev == true) {
      list.push(new FormControl(this.checkboxes[index].type));
    }
    else {
      let newVal = list.value.findIndex(val => val == obj.type);
      list.removeAt(newVal)
    }
    this.checkboxes[index].value = ev;
  }

  checkCustomFieldType(value) {
    const control = this.modalFormFroup.get('customFieldListItem') as FormArray;
    if (value['name'] !== "Single Select List" || value['name'] !== "Multiple Select List") {
      control.removeAt(0);
    }
  }

}