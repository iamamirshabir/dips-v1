export class ChevronMenuClassName{ 
    public static ContactListChevronMenu:string = "ContactListChevronMenu";
    public static ExercisesListChevronMenu:string = "ExercisesListChevronMenu";
    public static AnalysisColorsListChevronMenu:string = "AnalysisColorsListChevronMenu";    
    public static RiskStrategiesChevronMenu:string = "RiskStrategiesChevronMenu";   
    public static ImpactCategoriesChevronMenu:string = "ImpactCategoriesChevronMenu"; 
    public static ImpactLevelsChevronMenu:string = "ImpactLevelsChevronMenu";     
    public static EmployeeTypeListChevronMenu:string = "EmployeeTypeListChevronMenu";
    public static BIAProcessesChevronMenu:string = "BIAProcessesChevronMenu";
    public static ItServiceTypeListCheveronMenue:string = "ItServiceTypeListCheveronMenue";
    public static RisksListChevronMenu:string = "RisksListChevronMenu";
    public static BIAProductServiceChevronMenu:string = "BIAProductServiceChevronMenu";
    public static CostCenterListChevronMenu:string = "CostCenterListChevronMenu";
    public static BusinessEntityListChevronMenu:string = "BusinessEntityListChevronMenu";
    public static BIAResourcesListChevronMenu:string = "BIAResourcesListChevronMenu";
    public static PerspectivesChevronMenu:string = "PerspectivesChevronMenu";
    public static RecoveryPolicyListChevronMenu:string ="RecoveryPolicyListChevronMenu";
    public static CategoryITListChevronMenu:string ="CategoryITListChevronMenu";
    public static CategoryLocationListChevronMenu: string = "CategoryLocationListChevronMenu";
    public static CategorySupplierListChevronMenu:string ="CategorySupplierListChevronMenu";
    public static CategoryProductServiceListChevronMenu:string = "CategoryProductServiceListChevronMenu";
    public static SuppliersListChevronMenu:string = "SuppliersListChevronMenu";
    public static BusinessAreaListChevronMenu:string = "BusinessAreaListChevronMenu";
    public static BiaRecordChevronMenu:string = "BiaRecordChevronMenu";
    public static OrganisationListChevronMenu:string = "OrganisationListChevronMenu";
    public static TimeScalesListChevronMenu:string = "TimeScalesListChevronMenu";
    
    
    
}