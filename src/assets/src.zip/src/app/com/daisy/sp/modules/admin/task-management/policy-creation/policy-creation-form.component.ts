import { ThrowStmt, viewClassName } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { SpChipFormFieldComponent } from '../../../../common/components/sp-chip-form-field/sp-chip-form-field.component';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { PageState } from '../../../../utils/constants/page-state-constants';
import { policyCreation } from '../../../../utils/constants/policy-creation-constants';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { PolicyCreationService } from './policy-creation.service';

@Component({
  selector: 'app-policy-creation-form',
  templateUrl: './policy-creation-form.component.html',
  styleUrls: ['./policy-creation-form.component.sass']
})
export class PolicyCreationFormComponent extends BaseClass implements OnInit {
  policyConstants: any;
  displayedColumns = ['name', 'days', 'after', 'actions']
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  dataSource1 = new BehaviorSubject<AbstractControl[]>([]);
  @ViewChild('reviewSelect') reviewSelect: SpChipFormFieldComponent;

  @ViewChild('taskType') taskType: SpChipFormFieldComponent;
  policyCreationForm: FormGroup;
  defaultReminderForm: FormGroup;
  policyCreationObject: any;
  beforeAfter = [{ name: "Before", value: true },
  { name: "After", value: false }
  ];
  approver1: boolean = false;
  approver2: Boolean = false;
  escalationEnable: boolean = false;
  selectedFrequency: boolean;
  obj = {
    monthlyCheck: false,
    weeklyCheck: false,
    yearlyCheck: false
  }
  remindersList: any = [];
  routeParams: any;
  contactId: any;
  policyId: any;




  constructor(public formBuilder: FormBuilder, public policyCreationService: PolicyCreationService) {
    super();
    this.policyConstants = policyCreation;
  }
  ngOnInit() {
    this.initializeData();
    this.secondApproverAndExcalationChecker();
  
  }

  initializeData() {

    this.policyCreationForm = this.formBuilder.group({
      id: [null],
      name: [null, Validators.required],
      reviewFrequencyType: [null, Validators.required],
      reviewFrequencyValue: [null],
      reviewFrequencyDay: [null],
      reviewFrequencyYear: [null],
      firstApprover: [false],
      secondApprover: [false],
      firstApproverPeriod: [null],
      secondApproverPeriod: [null],
      reminderOwner: new FormArray([]),
      reminderApprover: new FormArray([]),
      taskType: [null, Validators.required],
      version: [null],
      escalation: [false],
    });
  }
  frequencyChanged(item) {
    switch (item) {
      case 0:
        this.obj.weeklyCheck = true;
        this.obj.monthlyCheck = false;
        this.obj.yearlyCheck = false;
        break;

      case 1:
        this.obj.monthlyCheck = true;
        this.obj.weeklyCheck = false;
        this.obj.yearlyCheck = false;
        break;

      case 2:
        this.obj.yearlyCheck = true;
        this.obj.monthlyCheck = false;
        this.obj.weeklyCheck = false;
        break;
    }
  }
  reminderApprover(): FormArray {
    return this.policyCreationForm.controls["reminderApprover"] as FormArray;
  }
  get remindersApprover() {
    return this.policyCreationForm.controls["reminderApprover"] as FormArray;
  }

  reminderOwner(): FormArray {
    return this.policyCreationForm.controls["reminderOwner"] as FormArray;
  }
  get reminderOwners() {
    return this.policyCreationForm.controls["reminderOwner"] as FormArray;
  }
  secondApproverAndExcalationChecker()
  {
    if(this.approver1 === false || this.policyCreationObject.firstApprover === false || 
      this.policyCreationForm.value.firstApprover===false)
      {
        this.policyCreationForm.controls['secondApprover'].disable();
        this.policyCreationForm.controls['escalation'].disable();
      }
      else
      {
        this.policyCreationForm.controls['secondApprover'].enable();
        this.policyCreationForm.controls['escalation'].enable();
      }
  }
  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.policyId = this.routeParams['id'];
    if (this.routeParams.pageState != 1) {
      if (this.policyId) {
        // this.secondApproverAndExcalationChecker();
        if(this.policyCreationForm.value.firstApprover===false)
    {
     this.policyCreationForm.controls['secondApprover'].disable();
     this.policyCreationForm.controls['escalation'].disable();
    }
    else{
     this.policyCreationForm.controls['secondApprover'].enable();
     this.policyCreationForm.controls['escalation'].enable();
 
    }
        if (this.policyCreationForm.value.reminderApprover == null && this.policyCreationForm.value.reminderOwner == null) {
          this.createRemindersArray(true, this.policyConstants.type, this.policyConstants.type.typeOwner);
          this.createRemindersArray(true, this.policyConstants.type, this.policyConstants.type.typeApprover);
        }
        
        this.getPolicyById(this.policyId);
      }
    }
    else {
      if(this.policyCreationForm.value.firstApprover===false)
      {
       this.policyCreationForm.controls['secondApprover'].disable();
       this.policyCreationForm.controls['escalation'].disable();
      }
      else{
       this.policyCreationForm.controls['secondApprover'].enable();
       this.policyCreationForm.controls['escalation'].enable();
   
      }
      this.createRemindersArray(false, this.policyConstants.type, this.policyConstants.type.typeOwner);
      this.createRemindersArray(false, this.policyConstants.type, this.policyConstants.type.typeApprover);
    }
  }

  getPolicyById(id) {
    this.showLoader();
    this.policyCreationService.getTaskPolicyById(id).subscribe(data => {
      this.hideLoader();
      this.policyCreationObject = data;
      this.patchData();
    }, error => {
      this.hideLoader();
    })
  }
  patchData() {
    if (this.policyCreationObject.reminder.length <= 0  ) {
      this.createRemindersArray(false, this.policyConstants.type, this.policyConstants.type.typeOwner);
      this.createRemindersArray(false, this.policyConstants.type, this.policyConstants.type.typeApprover);

    }
    
    else  if (this.policyCreationObject.reminder.length ==1)
    {
      this.createRemindersArray(false, this.policyConstants.type, this.policyConstants.type.typeApprover);

    }
    this.secondApproverAndExcalationChecker();

    this.reviewSelect = this.policyCreationObject.reviewFrequencyType;
    this.taskType.patchDataInControls(this.policyCreationObject.taskType);

    this.policyCreationForm.controls.reviewFrequencyType.patchValue(this.policyCreationObject.reviewFrequencyType);


    this.approver1 = this.policyCreationObject.firstApprover;
    this.approver2 = this.policyCreationObject.secondApprover;
    this.escalationEnable = this.policyCreationObject.escalation;

    this.policyCreationObject.reminder.forEach(element => {
      this.createRemindersArray(false, element);
    });
    this.policyCreationForm.patchValue(this.policyCreationObject);
  }
  approverFirst() {
    this.approver1 = !this.approver1;
    if(this.approver1===false)
    {
     this.policyCreationForm.controls['secondApprover'].disable();
     this.policyCreationForm.controls['escalation'].disable();
    }
    else{
     this.policyCreationForm.controls['secondApprover'].enable();
     this.policyCreationForm.controls['escalation'].enable();
 
    }
  
  }
  approverSecond() {
    this.approver2 = !this.approver2;
  }
  escalationEnabled() {
    this.escalationEnable = !this.escalationEnable;
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 ? f1.value === f2.value : f1 === f2;
  }
  compareObjects(o1: any, o2: any): boolean {
    return o1.duration === o2.duration && o1 === o2.type;
  }

  updateView() {
    this.dataSource.next(this.reminderOwners.controls);
    this.dataSource1.next(this.remindersApprover.controls);
  }

  createRemindersArray(noUpdate?: boolean, element = null, type = null) {
    if (element.initial) {
      if (type === this.policyConstants.type.typeOwner) {
        const addReminderOwnerForm = this.formBuilder.group({
          id: [null],
          name: [null],
          days: [null],
          after: [null],
          type: [element.typeOwner],
          version: [null],
        });
        this.reminderOwners.push(addReminderOwnerForm);
        if (!noUpdate) { this.updateView(); }
      }
      if (type === this.policyConstants.type.typeApprover) {
        const addReminderApproverForm = this.formBuilder.group({
          id: [null],
          name: [null],
          days: [null],
          after: [null],
          type: [element.typeApprover],
          version: [null],
        });
        this.remindersApprover.push(addReminderApproverForm);
        if (!noUpdate) { this.updateView(); }
      }
    }
    else {
      if (element.type === 1) {
        const addReminderForm = this.formBuilder.group({
          id: [null],
          name: [null],
          days: [null],
          after: [null],
          type: [element.typeOwner],
          version: [null],
        });
        addReminderForm.patchValue(element);
        this.reminderOwners.push(addReminderForm);
        if (!noUpdate) { this.updateView(); }
      }
      if (element.type === 2) {
        const addReminderForm = this.formBuilder.group({
          id: [null],
          name: [null],
          days: [null],
          after: [null],
          type: [element.typeApprover],
          version: [null],
        });
        addReminderForm.patchValue(element);
        this.remindersApprover.push(addReminderForm);
        if (!noUpdate) { this.updateView(); }
      }
    }

  }

  onSubmit(btnType: ButtonActions) {
    if (this.policyCreationForm.invalid) {
      this.policyCreationForm.controls['name'].markAsTouched();
      this.policyCreationForm.controls['reviewFrequencyType'].markAsTouched();
      this.policyCreationForm.controls['taskType'].markAsTouched();
      this.policyCreationForm.controls['reminderOwner'].markAsPending();
      return;
    }

    if (this.policyCreationForm.value.firstApprover === false) {
      this.remindersList = [...this.policyCreationForm.value.reminderOwner];

    }
    else 
    {
          this.remindersList = [...this.policyCreationForm.value.reminderOwner,...this.policyCreationForm.value.reminderApprover];
    }
   
    if(this.policyCreationForm.controls['reminderOwner'].untouched)
    {
      this.remindersList=[];
    }

    delete this.policyCreationForm.value.reminderApprover;
    delete this.policyCreationForm.value.reminderOwner;
    this.policyCreationForm.value['reminder'] = this.remindersList;
    this.policyCreationObject = this.policyCreationForm.value;
    this.policyCreationService.savePolicyForm(this.policyCreationForm.value).subscribe(res => {
      if (btnType == ButtonActions.SAVE) {
        if (this.routeParams.pageState == 1) {
          this.alertService.success("creation.successfull", true);
          this.goBackToMainPage();
        }
        else {
          this.alertService.success("updation.successfull", true);
          this.goBackToMainPage();
        }
      }
      else if (btnType == ButtonActions.SAVE_AND_CONT) {
        if (this.routeParams.pageState == 1) {
          this.alertService.success("creation.successfull", true);
        }
        else {
          this.alertService.success("updation.successfull", true);
        }
      }
    },
      error => {
        this.alertService.error('saving.error', true);

      })
  }


  goBackToMainPage() {

    this.routingService.openPage(RouteConstants.ADMIN_TASK_MANAGEMENT_POLICY_CREATION_LIST);

  }
  removeReminderOwnerArray(index) {
    if (this.reminderOwners.length == 1) {
      return
    }
    else {
      this.reminderOwners.removeAt(index);
      this.updateView();

    }
  }
  removeReminderApproverArray(index) {
    if (this.remindersApprover.length == 1) {

      return
    }
    else {
      this.remindersApprover.removeAt(index);
      this.updateView();
    }

  }
}
