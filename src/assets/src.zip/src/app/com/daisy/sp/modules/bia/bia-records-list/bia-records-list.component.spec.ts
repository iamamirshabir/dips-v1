import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BiaRecordsListComponent } from './bia-records-list.component';

describe('BiaRecordsListComponent', () => {
  let component: BiaRecordsListComponent;
  let fixture: ComponentFixture<BiaRecordsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BiaRecordsListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaRecordsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
