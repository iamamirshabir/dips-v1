import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalenderDateTimeComponent } from './calender-date-time.component';

describe('CalenderDateTimeComponent', () => {
  let component: CalenderDateTimeComponent;
  let fixture: ComponentFixture<CalenderDateTimeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CalenderDateTimeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CalenderDateTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
