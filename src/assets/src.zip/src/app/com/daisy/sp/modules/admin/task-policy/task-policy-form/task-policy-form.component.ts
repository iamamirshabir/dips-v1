import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-task-policy-form',
  templateUrl: './task-policy-form.component.html',
  styleUrls: ['./task-policy-form.component.sass']
})
export class TaskPolicyFormComponent extends BaseClass implements OnInit {

  taskpolicyForm: FormGroup;
  defaultReminderForm: FormGroup;
  showhide: boolean;
  dueDates= [
          {name:"After", value:0},
          {name:'Before', value:1}
        ];
  selectedValue;
  showReminder: any;
  reminderName: any;
  reminderList: any = [];
  reminderListToShow: any = [];


  constructor(public formBuilder: FormBuilder,) {
    super();
  }
  ngOnInit() {
    this.initializeData();
  }

  initializeData() {
    this.taskpolicyForm = this.formBuilder.group({
      policyName: [null],
      owner: [null],
      policyReview: [null],
      defaultNotifyOption: [],
      actionPlan: [],
      recoveryPlanning: [],
      localProcess: [],
      document: [],
      contactGroup: [],
      resourceType: [],
      assets: [],
      reportTemplate: [],
      test: [false],
      incident: [false],
      showValidation: [false],
      validationPeriod: [null],

    });
    this.defaultReminderForm = this.formBuilder.group({
      reminderName: [''],
      defaultDays: [''],
      dueDates: [''],
      owner: [],
    })
  }

  showHide() {
    this.showhide = !this.showhide;
  }

  addReminderList() {
    this.showReminder = true;
    this.reminderList = {
      reminderName: this.defaultReminderForm.value.reminderName,
      reminderDays: this.defaultReminderForm.value.defaultDays,
      reminderDueDate: this.defaultReminderForm.value.dueDates,
      reminderOwner: this.defaultReminderForm.value.owner
    };
    this.reminderListToShow.push(this.reminderList);
    this.reminderList = [];
    this.defaultReminderForm.reset();
  }

   removeOrClearRow(index: number) {
    this.reminderListToShow.splice(index, 1)
    if (this.reminderListToShow == 0) {
      this.showReminder = false;
    }
    let that = this;
    this.alertService.confirmation("deleteOneConfirm",
      function () {
        that.reminderListToShow(index);
      });
  }
  onSubmit() {
    console.log(this.taskpolicyForm);
  }
  // compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  // compareByValue(f1: any, f2: any) {
  //     return f1 && f2 && f1.name === f2.name;
  // }
  goBackToMainPage() {
    this.routingService.navigate(['/shadowplanner'])

  }
}