import { TestBed } from '@angular/core/testing';

import { EditableListingViewService } from './editable-listing-view.service';

describe('EditableListingViewService', () => {
  let service: EditableListingViewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EditableListingViewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
