import { AfterViewInit, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { RecoveryPoliciesService } from '../recovery-policies.service';

@Component({
  selector: 'app-recovery-policies-list',
  templateUrl: './recovery-policies-list.component.html',
  styleUrls: ['./recovery-policies-list.component.sass']
})
export class RecoveryPoliciesListComponent extends BaseClass implements OnInit, AfterViewInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  constructor(private router: Router, protected activatedRoute: ActivatedRoute, private recoveryPolicyService: RecoveryPoliciesService) {
    super();
  }

  ngOnInit(): void {
    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'description', name: 'Policy Description', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": this.ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": this.ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.filterSelectObj = [{name : 'Name',columnProp : 'name', option : []},
    {name : 'Policy Description',columnProp : 'description', option : []}
    ];

    this.setDataTable([]);

  }
  ngAfterViewInit() {
    this.hideLoader();
  }
  ngAfterContentInit() {
    this.getRecoveryPolicies();
  }

  getRecoveryPolicies() {
    this.showLoader();
    this.recoveryPolicyService.getAllRecoveryPolicies(this.organisation.id).subscribe((res) => {
      this.tableData = res;
      this.setDataTable(this.tableData);
    }, err => {
      this.hideLoader();
      this.tableData = [];
      this.setDataTable(this.tableData);
    })
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.bia.recoverypolicies.title'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.RecoveryPolicyListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
    this.hideLoader();
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, this.PageState.EDIT_STATE);
  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    routeParams.parentParams = this.pageParams;
    routeParams.id = data['id'];
    routeParams.data = data;
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.BIA_CONFIG_RECOVERY_POLICIES_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  printClick(data, exportType) {

  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == this.ButtonActions.EDIT) {
      this.openFormHandler(data, this.PageState.EDIT_STATE);
    }
    if (btnAction == this.ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteRecoveryPolicyById(data.id);
        });

    }
    if (btnAction == this.ButtonActions.VIEW) {
      this.openFormHandler(data, this.PageState.VIEW_STATE);
    }
  }
  deleteRecoveryPolicyById(data) {
    this.showLoader();
    this.recoveryPolicyService.deleteRecoveryPolicBySingleId(data).subscribe(res => {
      console.log(res);
      this.hideLoader();
      this.getRecoveryPolicies();
    }, error => {
      this.hideLoader();
    })
  }

  deleteAllClick(data) {
    let policyId = this.getIdsFromList(data);
    this.showLoader();
    this.recoveryPolicyService.deleteRecoveryPolicByIds(policyId).subscribe(res => {
      console.log(res);
      this.hideLoader();
      this.getRecoveryPolicies();
    }, error => {
      this.hideLoader();
    })
  }
}
