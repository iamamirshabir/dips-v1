import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-productService',
  templateUrl: './category-productService.component.html',
  styleUrls: ['./category-productService.component.sass']
})
export class CategoryProductServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
