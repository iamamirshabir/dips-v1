import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';

@Component({
  selector: 'app-cost-center-form',
  templateUrl: './cost-center-form.component.html',
  styleUrls: ['./cost-center-form.component.sass']
})
export class CostCenterFormComponent extends BaseClass implements OnInit {

  costCenterForm: FormGroup;
  routeParams: any;
  public modalData: any;
  public wasFormChanged = false;

  constructor(private formBuilder: FormBuilder, public dialog: MatDialog, public dialogRef: MatDialogRef<CostCenterFormComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.initialiseFormData();
    this.modalData = data;
  } 
  get f() { return this.costCenterForm.controls; }
  ngOnInit(): void {
    if(this.modalData.pageState && this.modalData.data){
      if(this.modalData.pageState == this.PageState.VIEW_STATE){
        this.costCenterForm.disable();
      }
      this.costCenterForm.patchValue(this.modalData.data);
    }
  }

  initialiseFormData() {
    this.costCenterForm = this.formBuilder.group({
      name:[null, Validators.required],
      description: [''],
      id: [null],
      version: [null]
    });
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  closeModal(): void {
    this.dialogRef.close(null);
  }

  saveFormData(): void {
    if (this.costCenterForm.invalid) {
      Object.keys(this.costCenterForm.controls).forEach(field => {
        const control = this.costCenterForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      return;
    }
    
    this.modalData.data = this.costCenterForm.value;
    this.dialogRef.close(this.modalData);
  }

}
