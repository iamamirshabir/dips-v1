import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";

@Component({
    selector: 'app-cf-record-type-editor',
    templateUrl: './cf-record-type-editor.component.html',
    styleUrls: ['./cf-record-type-editor.component.sass']
})
export class CfRecordTypeEditorComponent implements OnInit {
  @Input() checkboxName;
  @Input() checkboxData: boolean;
  @Output() toggle: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor() {}

  ngOnInit() {}

  onToggle() {
    const checkedOption = this.checkboxData;
    this.toggle.emit(checkedOption);
  }
}
