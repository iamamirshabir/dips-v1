import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RealEntityListComponent } from './real-entity-list.component';

describe('RealEntityListComponent', () => {
  let component: RealEntityListComponent;
  let fixture: ComponentFixture<RealEntityListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RealEntityListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealEntityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
