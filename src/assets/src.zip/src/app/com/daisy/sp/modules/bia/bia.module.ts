import { NgModule } from '@angular/core';
import { BIAComponent } from './bia.component';
import { BiaRecordComponent } from './bia-record/bia-record.component';
import { RouterModule, Routes } from '@angular/router';
import { ComponentsModule } from '../../common/components/components.module';
import { AngularMaterialModule } from 'src/app/app.material.module';
import { BiaRecordsListComponent } from './bia-records-list/bia-records-list.component';
import { DependencyMapComponent } from './dependency-map/dependency-map.component';
const routes: Routes = [
  {
    path: '', component: BIAComponent,
    children: [
      { path: 'bia-records-list', component: BiaRecordsListComponent },
      { path: 'bia-record', component: BiaRecordComponent },
      { path: 'dependency-map', component: DependencyMapComponent },
      { path: 'bia-record-tab', loadChildren: () => import('../../modules/bia/bia-record-tab/bia-record-tab.module').then(m => m.BIARecordTabModule) },
    ]
  }
];

@NgModule({
  declarations: [BIAComponent, BiaRecordComponent, BiaRecordsListComponent, DependencyMapComponent],
  imports: [
    ComponentsModule,
    AngularMaterialModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [BIAComponent]

})
export class BIAModule { }
