import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { TimeScalesConstant } from '../../../utils/constants/timeScales-constant';
import { ProductService } from '../bia-record-tab/product-services/product-services.service';
import { BIAService } from '../bia.service';
import { CategoryTypes } from '../../../utils/constants/category-types';
@Component({
  selector: 'app-bia-records-list',
  templateUrl: './bia-records-list.component.html',
  styleUrls: ['./bia-records-list.component.sass']
})
export class BiaRecordsListComponent extends BaseClass implements OnInit, AfterViewInit {
  iListingView: IListingView;
  typeConstants: any;
  public productService: ProductService;
  protected biaName: any;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  RTOdurationString: string;
  ArtdurationString: string;
  RPOdurationString: string;
  public static RPO_TYPE: number = 1;
  public static RTO_TYPE: number = 2;
  public static ART_TYPE: number = 3;
  RTOArray: any;
  RPOArray: any;
  routeParams: any;
  biaType: any;
  departmentArray: any = [];
  locationArray: any = [];;
  constructor(private biaService: BIAService, router: Router) {
    super();
    this.typeConstants = CategoryTypes;
    router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
  }

  ngOnInit(): void {
   
    this.tableButtons = [{ "name": "Delete", "type": this.ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE }];


    this.filterSelectObj = [
      { key: 'Name', columnProp: 'name', options: [] },
      { key: 'Owner', columnProp: 'owner', options: [] },
      { key: 'Recovery Time Objective', columnProp: 'rtoName', options: [] },
      { key: 'Type', columnProp: 'type', options: [] }
    ];

    
  }
  ngAfterContentInit() {

    this.hideLoader();
  }
  openFormByState(routeParams) {

    this.hideLoader();
    let that = this;
    this.routeParams = routeParams;
    this.routedPageState = that.routeParams['pageState'];
    if (this.routeParams.data) {
      this.getBiaTypeList(this.routeParams.data);
    }
    else {
      this.getBiaTypeList(this.routeParams);

    }
  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
      routeParams.data = data;
    }
    if (this.routeParams.data) {
      routeParams.parentParams = this.routeParams.data;
    }
    else {
      routeParams.parentParams = this.routeParams;
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.BIA_RECORD;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  getBiaRecordList() {
    this.CategoryProductServiceService.getAllByOrganisationIdAndCanDoBia(this.organisation.id).subscribe((res) => {
      this.populateDatatable(res);
    })
  }

  populateDatatable(data) {
    this.tableData = data;
    if (this.tableData) {
      this.tableData.forEach(element => {

        if (element && element != null) {
          if (element.owner != null) {
            // element.owner = element.owner.firstName + " " + element.owner.lastName;
            element.owner = element.owner.fullName;
          }
          if (element.category.type == this.typeConstants.PRODUCT) {
            element.type = this.languageTranslator('bia.category.type.produc.service');
          }
          else if (element.category.type == this.typeConstants.SUPPLIER) {
            element.type = this.languageTranslator('bia.category.type.supplier');
          }
          else if (element.category.type == this.typeConstants.IT) {
            element.type = this.languageTranslator('bia.category.type.it');
          }
          else if (element.category.type == this.typeConstants.BUSINESS_AREA) {
            element.type = this.languageTranslator('bia.category.type.business.area');
          }
          else if (element.category.type == this.typeConstants.RESOURCE) {
            element.type = this.languageTranslator('bia.category.type.resource');
          }
          else if (element.category.type == this.typeConstants.LOCATION) {
            element.type = this.languageTranslator('bia.category.type.location');
          }
          if (element.category != null) {
            element.categoryName = element.category.name;
          }
          if (element.perspectiveDepartmental && element.perspectiveLocational != null) {
            element.perspectiveDepartmental.forEach(d => {
              this.departmentArray.push(d.name);
              element.realEntity = this.departmentArray + "/";
            });
            element.perspectiveLocational.forEach(l => {
              this.locationArray.push(l.name)
              element.realEntity = this.departmentArray + "/" + this.locationArray;
            });
            this.departmentArray = [];
            this.locationArray = [];
          }
          if (element.rto && element.rto != null) {
            this.RTOdurationString = this.timePointDurationbyMeasure(element.rto.measure, element.rto.duration);
            element.rtoName = this.RTOdurationString;
          }
          if (element.art && element.art != null) {
            this.ArtdurationString = this.timePointDurationbyMeasure(element.art.measure, element.art.duration);
            element.artName = this.ArtdurationString;
          }
        }
        else
          return
      });
    }
    this.hideLoader();
     this.setDataTable(this.tableData);
  }

  getBiaTypeList(data) {

    if (this.pageParams || !this.pageParams) {
      let id: number = data['type'];
      let idNo: number = data['id'];
      let name: string = data.name;
    
      if (idNo === this.typeConstants.ALL || idNo === this.typeConstants.DEPENDENCY_MAP) {
        this.getBiaRecordList();
        this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
        { key: 'name', name: 'Record Name', checked: 'true' },
        { key: 'owner', name: 'Owner', checked: 'true' },
        { key: 'rtoName', name: 'Recovery Time Objective', checked: 'true' },
        { key: 'MTPD', name: 'MTPD', checked: 'true' },
        { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
        { key: 'type', name: 'Type', checked: 'true' },
        { key: 'action', name: '', checked: 'true' }];
      
        this.setDataTable([]);
      } else {
        switch (idNo) {

          case 3:
            this.CategoryProductServiceService.getCategoryProductServiceByOrgIdAndCanDoBia(this.organisation.id)
              .subscribe((res) => {
                this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
                { key: 'name', name: 'Record Name', checked: 'true' },
                { key: 'owner', name: 'Owner', checked: 'true' },
                { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
                { key: 'rtoName', name: 'RTO', checked: 'true' },
                { key: 'MTPD', name: 'MTPD', checked: 'true' },
                { key: 'lastBiaReview', name: 'Last BIA Review', checked: 'true' },
                { key: 'nextBiaReview', name: 'Next BIA Review' },
                { key: 'lastUpdated', name: 'Last Updated' },
                { key: 'updated', name: 'Updated By' },
                { key: 'type', name: 'Type' },
                { key: 'action', name: '', checked: 'true' }

                ];
                this.populateDatatable(res);
              });
            break;
          case 4:
            this.categorySupplierService.getCategorySupplierByOrgIdAndCanDoBia(this.organisation.id)
              .subscribe((res) => {
                this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
                { key: 'name', name: 'Record Name', checked: 'true' },
                { key: 'owner', name: 'Owner', checked: 'true' },
                { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
                { key: 'rtoName', name: 'RTO', checked: 'true' },
                { key: 'MTPD', name: 'MTPD', checked: 'true' },
                { key: 'lastBiaReview', name: 'Last BIA Review', checked: 'true' },
                { key: 'requiredRto', name: 'Required RTO' },
                { key: 'nextBiaReview', name: 'Next BIA Review' },
                { key: 'lastUpdated', name: 'Last Updated' },
                { key: 'updated', name: 'Updated By' },
                { key: 'type', name: 'Type' },  
                { key: 'action', name: '', checked: 'true' }
                ];
                this.populateDatatable(res);
              });
            break;
          case 5:
            this.categoryItService.getCategoryITServiceByOrgIdAndCanDoBia(this.organisation.id)
              .subscribe((res) => {
                this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
                { key: 'name', name: 'Record Name', checked: 'true' },
                { key: 'owner', name: 'Owner', checked: 'true' },
                { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
                { key: 'rtoName', name: 'RTO', checked: 'true' },
                { key: 'MTPD', name: 'MTPD', checked: 'true' },
                { key: 'lastBiaReview', name: 'Last BIA Review', checked: 'true' },
                { key: 'artName', name: 'ART' },
                { key: 'requiredRto', name: 'Required RTO' },
                { key: 'requiredRpo', name: 'Required RPO' },
                { key: 'rpoName', name: 'RPO' },
                { key: 'arp', name: 'ARP' },
                { key: 'nextBiaReview', name: 'Next BIA Review' },
                { key: 'lastUpdated', name: 'Last Updated' },
                { key: 'updated', name: 'Updated By' },
                { key: 'type', name: 'Type' },
                { key: 'action', name: '', checked: 'true' }
                ];
                this.populateDatatable(res);
              });
            break;
          case 6:
            this.categoryBusinessAreaService.getBusinessEntityByOrgIdAndCanDoBia(this.organisation.id)
              .subscribe((res) => {
                this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
                { key: 'name', name: 'Record Name', checked: 'true' },
                { key: 'owner', name: 'Owner', checked: 'true' },
                { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
                { key: 'rtoName', name: 'RTO', checked: 'true' },
                { key: 'MTPD', name: 'MTPD', checked: 'true' },
                { key: 'lastBiaReview', name: 'Last BIA Review', checked: 'true' },
                { key: 'artName', name: 'ART' },
                { key: 'nextBiaReview', name: 'Next BIA Review' },
                { key: 'lastUpdated', name: 'Last Updated' },
                { key: 'updated', name: 'Updated By' },
                { key: 'type', name: 'Type' },
                { key: 'action', name: '', checked: 'true' }
                ];
                this.populateDatatable(res);
              });
            break;
          case 7:
            this.categoryResourceService.getCategoryResourceByOrgIdAndCanDoBia(this.organisation.id)
              .subscribe((res) => {
              
                this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
                { key: 'name', name: 'Record Name', checked: 'true' },
                { key: 'owner', name: 'Owner', checked: 'true' },
                { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
                { key: 'rtoName', name: 'RTO', checked: 'true' },
                { key: 'MTPD', name: 'MTPD', checked: 'true' },
                { key: 'lastBiaReview', name: 'Last BIA Review', checked: 'true' },
                { key: 'artName', name: 'ART' },
                { key: 'nextBiaReview', name: 'Next BIA Review' },
                { key: 'lastUpdated', name: 'Last Updated' },
                { key: 'updated', name: 'Updated By' },
                { key: 'type', name: 'Sub-Category' },
                { key: 'action', name: '', checked: 'true' }
                ];
                this.populateDatatable(res);
              });
            break;
          case 8:
            this.categoryLocationService.getCategoryByOrgIdAndCanDoBia(this.organisation.id)
              .subscribe((res) => {
                this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
                { key: 'name', name: 'Record Name', checked: 'true' },
                { key: 'owner', name: 'Owner', checked: 'true' },
                { key: 'realEntity', name: 'Real Entity Perspective', checked: 'true' },
                { key: 'rtoName', name: 'RTO', checked: 'true' },
                { key: 'MTPD', name: 'MTPD', checked: 'true' },
                { key: 'lastBiaReview', name: 'Last BIA Review', checked: 'true' },
                { key: 'artName', name: 'ART' },
                { key: 'requiredRto', name: 'Required RTO' },
                { key: 'nextBiaReview', name: 'Next BIA Review' },
                { key: 'lastUpdated', name: 'Last Updated' },
                { key: 'updated', name: 'Updated By' },
                { key: 'type', name: 'Type' },
                { key: 'action', name: '', checked: 'true' }
                ];
                this.populateDatatable(res);
              });
            break;
        }
      }
    }
  }

  deleteAllClick(data) {
    let recordId = this.getIdsFromList(data);
    this.showLoader();
    this.biaService.deleteBiaByCategoryRecordId(recordId).subscribe(res => {
      this.hideLoader();
      this.getBiaRecordList();
    }, error => {
      this.hideLoader();
    })
  }
  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.bia.recordList.name'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.BiaRecordChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, this.PageState.EDIT_STATE);
  }

  printClick(data, exportType) {

  }
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == this.ButtonActions.EDIT) {
      this.openFormHandler(data, this.PageState.EDIT_STATE);
    }
    if (btnAction == this.ButtonActions.DELETE) {
      this.deleteAllClick([data]);
    }
    if (btnAction == this.ButtonActions.VIEW) {
      this.openFormHandler(data, this.PageState.VIEW_STATE);
    }
  }

}