export class SecurityActions {    
    public static SECURITY_ACTION_CREATE:number  = 1;      
    public static SECURITY_ACTION_READ:number  = 2;   
    public static SECURITY_ACTION_UPDATE:number  = 3;   
    public static SECURITY_ACTION_DELETE:number  = 4; 

    public static YES:any  = 1;   
    public static NO:any  = 0; 
}