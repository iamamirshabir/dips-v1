import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login/login.service';
import { BaseClass } from '../../../utils/baseclass';
import { RouteConstants } from '../../../utils/constants/route-constants';
import { Subscription } from 'rxjs';
import { RoutingService } from '../../../common/services/routing-service';
import { MainLayoutService } from '../../main-layout-service';
import { RouteParams } from '../../../utils/model.route-params';
import { PageState } from '../../../utils/constants/page-state-constants';

@Component({
  selector: 'app-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.sass']
})
export class UserMenuComponent implements OnInit {
  userInfo:any;
  subscription: Subscription;
  constructor(private loginService : LoginService,
              private routingService: RoutingService,
              private mainLayoutService: MainLayoutService) { 
      this.userInfo = this.mainLayoutService.getloggedInUser();
  }

  ngOnInit(): void {
  } 

  changePassword(){
    this.routingService.openPage(RouteConstants.CHANGE_PASSWORD);
  }
  
  logOut() { 
    this.loginService.logout();
  } 
  ngOnDestroy() {
  }
  openContactForm(data){ 
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
  openFormHandler(data = null, pageState) {
      let routeParams: RouteParams = new RouteParams();
      if (data) {
        routeParams.id = data['id'];
      }
      routeParams.pageState = pageState;
      routeParams.routerLink = RouteConstants.CONTACT_FORM;
      this.routingService.openPage(routeParams.routerLink, routeParams);
  } 
}
