import { TestBed } from '@angular/core/testing';
import { ExpandListingViewService } from './expand-listing-view.service';



describe('ListingViewService', () => {
  let service: ExpandListingViewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExpandListingViewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
