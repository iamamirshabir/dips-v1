export class ChevronMenuItem {

    private _key:String;
    private _icon:String;
    private _accessArea:Number;
    private _securityAction:Number; 
    private _disabled:Boolean;

    public constructor( key:String, 
                        icon:String,
                        accessArea:Number = -1,
                        securityAction:Number = -1, 
                        disabled:Boolean = false){ 
        this._key = key;
        this._icon = icon;
        this._accessArea = accessArea;
        this._securityAction = securityAction; 
        this._disabled = disabled;
    }
    public set key(value:String){
            this._key = value;
    } 
    public get key():String {
            return this._key;
    } 
    public set icon(value:String){
            this._icon = value;
    } 
    public get icon():String {
            return this._icon;
    } 
    public set accessArea(value:Number){
            this._accessArea = value;
    } 
    public get accessArea():Number {
            return this._accessArea;
    } 
    public set securityAction(value:Number){
            this._securityAction = value;
    } 
    public get securityAction():Number {
            return this._securityAction;
    } 
    public set disabled(value:Boolean){
            this._disabled = value;
    } 
    public get disabled():Boolean {
            return this._disabled;
    } 
}