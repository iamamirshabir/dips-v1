import { Component, OnInit } from '@angular/core';
import { BaseClass } from '../../utils/baseclass'
@Component({
  selector: 'app-bcp',
  templateUrl: './bcp.component.html',
  styleUrls: ['./bcp.component.sass']
})
export class BCPComponent extends BaseClass implements OnInit {

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.hideLoader();
  }

}
