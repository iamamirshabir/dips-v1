import { Component, OnInit, Inject, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from '../../../../utils/baseclass';

@Component({
  selector: 'app-categories-form',
  templateUrl: './categories-form.component.html',
  styleUrls: ['./categories-form.component.sass']
})
export class CategoriesFormComponent extends BaseClass implements OnInit {
  public addCategoryForm: FormGroup;
  public modalData: any;
  @ViewChild('matDialogRealEntity') matDialogRealEntity: ElementRef;
  recoveryPolicies: any;
  rtoTimeScales: any;
  rpoTimeScales: any;
  artTimeScales: any;
  arpTimeScales: any;
  timeScalesRequired : boolean = true;
  constructor(private fb: FormBuilder, public dialog: MatDialog, public dialogRef: MatDialogRef<CategoriesFormComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
  }

  public ngOnInit(): void {

    this.addCategoryForm = this.fb.group({
      name: [null, [Validators.required]],
      description: [null],
      canDoBia: [true],
      recoveryPolicy: [null, [Validators.required]],
      rtoTimeScale: [null, [Validators.required]],
      rpoTimeScale: [null, [Validators.required]],
      artTimeScale: [null, [Validators.required]],
      arpTimeScale: [null, [Validators.required]],
      hideCategory: [false],
      inheritErto: false,
      parentName: [null],
      type: [null],
    });
    this.getRecoveryPolicies();
    this.getrtoTimeScales();
    this.getrpoTimeScales();
    this.getartTimeScales();
    this.getarpTimeScales();
    if (this.modalData) {
      if (this.modalData.node === null) {
        this.addCategoryForm.controls.parentName.patchValue(this.modalData.parentNode.name);
        this.addCategoryForm.controls.type.patchValue(this.modalData.parentNode.type);
      }
      else {
        this.addCategoryForm.controls.parentName.patchValue(this.modalData.node.parent.name);
      }
      this.setCanDoBiaRadio(this.modalData.node.canDoBia);
      this.addCategoryForm.patchValue(this.modalData.node);
    }
  }
  saveCategory(): void {
    if (this.addCategoryForm.invalid) {
      this.addCategoryForm.get('rtoTimeScale').markAsTouched();
      this.addCategoryForm.get('rpoTimeScale').markAsTouched();
      this.addCategoryForm.get('artTimeScale').markAsTouched();
      this.addCategoryForm.get('arpTimeScale').markAsTouched();
      this.addCategoryForm.get('recoveryPolicy').markAsTouched();
      return;
    }
    if (this.modalData && this.modalData.node) {
      this.modalData.node = Object.assign(this.modalData.node, this.addCategoryForm.value);
    }
    else {
      this.modalData.node = this.addCategoryForm.value;
    }
    this.dialogRef.close(this.modalData);
  }

  closeCategoryModal(): void {
    this.dialogRef.close(null);
  }
  getRecoveryPolicies() {
    this.showLoader();
    this.categoriesService.getAllRecoveryPolicies(this.organisation.id).subscribe((res) => {
      this.hideLoader();
      this.recoveryPolicies = res;
    }, err => {
      this.hideLoader();
    })
  }
  getrtoTimeScales() {
    this.showLoader();
    this.timeScalesService.getTimeScalesListByOrgIdAndType(this.organisation.id, 2).subscribe((res) => {
      this.hideLoader();
      this.rtoTimeScales = res;
    }, err => {
      this.hideLoader();
    })
  }
  getrpoTimeScales() {
    this.showLoader();
    this.timeScalesService.getTimeScalesListByOrgIdAndType(this.organisation.id, 1).subscribe((res) => {
      this.hideLoader();
      this.rpoTimeScales = res;
    }, err => {
      this.hideLoader();
    })
  }
  getartTimeScales() {
    this.showLoader();
    this.timeScalesService.getTimeScalesListByOrgIdAndType(this.organisation.id, 3).subscribe((res) => {
      this.hideLoader();
      this.artTimeScales = res;
    }, err => {
      this.hideLoader();
    })
  }
  getarpTimeScales() {
    this.showLoader();
    this.timeScalesService.getTimeScalesListByOrgIdAndType(this.organisation.id, 4).subscribe((res) => {
      this.hideLoader();
      this.arpTimeScales = res;
    }, err => {
      this.hideLoader();
    })
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.name === f2.name;
  }

  setCanDoBiaRadio(val) {
    
    const rtoTimeScaleControl = this.addCategoryForm.get('rtoTimeScale');
    const rpoTimeScaleControl = this.addCategoryForm.get('rpoTimeScale');
    const artTimeScaleControl = this.addCategoryForm.get('artTimeScale');
    const arpTimeScaleControl = this.addCategoryForm.get('arpTimeScale');
    const recoveryPolicyControl = this.addCategoryForm.get('recoveryPolicy');

    if (val === "true") {
      this.timeScalesRequired = true;
      recoveryPolicyControl.setValidators([Validators.required]);
      rtoTimeScaleControl.setValidators([Validators.required]);
      rpoTimeScaleControl.setValidators([Validators.required]);
      artTimeScaleControl.setValidators([Validators.required]);
      arpTimeScaleControl.setValidators([Validators.required])
      recoveryPolicyControl.enable();
      rtoTimeScaleControl.enable();
      rpoTimeScaleControl.enable();
      artTimeScaleControl.enable();
      arpTimeScaleControl.enable();
    }
    else if (val === "false") {
      this.timeScalesRequired = false;
      recoveryPolicyControl.setValidators(null);
      rtoTimeScaleControl.setValidators(null);
      rpoTimeScaleControl.setValidators(null);
      artTimeScaleControl.setValidators(null);
      arpTimeScaleControl.setValidators(null);
      recoveryPolicyControl.disable();
      rtoTimeScaleControl.disable();
      rpoTimeScaleControl.disable();
      artTimeScaleControl.disable();
      arpTimeScaleControl.disable();
    }

    recoveryPolicyControl.updateValueAndValidity();
    rtoTimeScaleControl.updateValueAndValidity();
    rpoTimeScaleControl.updateValueAndValidity();
    artTimeScaleControl.updateValueAndValidity();
    arpTimeScaleControl.updateValueAndValidity();
  }
}