import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactGroupHierarchyComponent } from './contact-group-hierarchy.component';

describe('ContactGroupHierarchyComponent', () => {
  let component: ContactGroupHierarchyComponent;
  let fixture: ComponentFixture<ContactGroupHierarchyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactGroupHierarchyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactGroupHierarchyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
