import { ChevronMenuItem } from './chevron-menu-item.model';

export class ChevronMenuBase { 
    menusList:any[] = [];
    recordsList:any[] = [];
    record:any; 
    constructor() {  
    }
    addMenu(key:String, icon:String, accessArea:Number = -1, securityAction:Number = -1,disabled:Boolean = false) { 
        this.menusList.push(new ChevronMenuItem(key, icon, accessArea, securityAction, disabled));
    }
    deleteMenu(key){ 
        let actionmenu = this.menusList.find(item => item.key == key);
        if(actionmenu){ 
            let indexes = this.menusList.indexOf(actionmenu);
            this.menusList.splice(indexes,1); 
        } 
    } 
    disableMenu(key, disable){ 
        let actionmenu = this.menusList.find(item => item.key == key);
        if(actionmenu){ 
            actionmenu.disabled = disable;
        }  
    }
}