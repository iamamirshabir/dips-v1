import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { MatIcons } from 'src/app/com/daisy/sp/utils/constants/mat-icons-constants';
import { ChevronMenuClassName } from 'src/app/com/daisy/sp/common/components/chevron-menus/chevron-menu-class-names';
import { data } from 'dom7';
import { RouteParams } from 'src/app/com/daisy/sp/utils/model.route-params';
import { PageState } from 'src/app/com/daisy/sp/utils/constants/page-state-constants';
import { RouteConstants } from 'src/app/com/daisy/sp/utils/constants/route-constants';
import { IListingView } from 'src/app/com/daisy/sp/common/components/listing-view/listing-view.interface';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-category-supplier-list',
  templateUrl: './category-supplier-list.component.html',
  styleUrls: ['./category-supplier-list.component.sass']
})
export class CategorySupplierListComponent extends BaseClass implements OnInit {
  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  routeParams: any;
  cat_Supplier: any;
  catId: any;
  catType: any;
  hierarchy:string;

  constructor(
    private router: Router, protected activatedRoute: ActivatedRoute) {
    super();
  }

  ngOnInit(): void {

    this.displayedColumns = [{ key: 'select', name: '', checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'description', name: 'Description', checked: 'true' },
    { key: 'category', name: 'Sub Category', checked: 'true' },
    { key: 'perspectiveDepartmental', name: 'Departmental', checked: 'true' },
    { key: 'perspectiveLocational', name: 'Locational', checked: 'true' },
    { key: 'rto', name: 'rto', },
    { key: 'art', name: 'art', },
    { key: 'bcpLastTest', name: 'Last Tested', checked: 'true' },
    { key: 'owner', name: 'Internal Owner', checked: 'true' },
    { key: 'accountManager', name: 'Account Manager', checked: 'true' },
    { key: 'address', name: 'Address', checked: 'true' },
    { key: 'action', name: '', checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD },
    ];

    this.filterSelectObj = [{ name: 'Name', columnProp: 'name', options: [] },
    { name: 'Username', columnProp: 'username', options: [] },
    { name: 'Email', columnProp: 'workEmail', options: [] }];
    this.setDataTable([]);
    this.getCategoryRecordFromTree();
  }
  // ngAfterViewInit() {
  
   
  // }
  openFormByState(routeParams) {
    this.hideLoader();
    console.log("reciever");
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.cat_Supplier= this.routeParams['data'];
    this.hierarchy = this.cat_Supplier.hierarchy;
    this.categorySupplierService.catSupplierDetails = this.cat_Supplier;
    this.getCategoryRecordFromTree();
  }
  getCategoryRecordFromTree(){
    if (this.categorySupplierService.catSupplierDetails) {
      this.catId= this.categorySupplierService.catSupplierDetails['id'];
      this.catType = this.categorySupplierService.catSupplierDetails['type'];
      if(!this.hierarchy) {
      this.hierarchy = this.categorySupplierService.catSupplierDetails.hierarchy;
      }
      this.getCategorySupplierList();
    }
  }
  getCategorySupplierList() {
    this.showLoader();
    this.categoriesService.getCategoryByOrgidAndCatidAndType(this.organisation.id,+this.catId,this.catType).
      subscribe(categorySupplier => {
        if (categorySupplier) {
          this.tableData = categorySupplier;
        } else {
          this.tableData = [];
        }
        this.hideLoader();
        if (this.tableData) {
          this.tableData.forEach(element => {
            element.bcpLastTest = this.setShortDateFormat(element.bcpLastTest);
            if(element.owner !== null){
              element.owner = element.owner.fullName;
            }
            if(element.accountManager !== null){
              element.accountManager = element.accountManager.fullName;
            }
            var deptArray: any = [];
            element.perspectiveDepartmental.forEach(department => {
              deptArray.push(department.name);
            });
            element.perspectiveDepartmental = deptArray.join(", ");
           
            var locArray : any = [];
            element.perspectiveLocational.forEach(location => {
              locArray.push(location.name);
            });
            element.perspectiveLocational = locArray.join(", "); 
            if(element.category !== null){
              element.category = this.hierarchy;
            }
          });
        }
        this.setDataTable(this.tableData);
      }, error => {
        this.hideLoader();
        this.tableData = [];
        this.setDataTable(this.tableData);
      })
  }

  setDataTable(tableData) {
    this.iListingView = {
      listTitle: this.languageTranslator('admin.category.categorySupplier.title'),
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.CategorySupplierListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
  btnDoubleClicked(data) {
    this.openFormHandler(data, PageState.EDIT_STATE);
  }
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
      data.hierarchy = this.hierarchy;
      routeParams.data =   this.categorySupplierService.catSupplierDetails;
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.CATEGORY_supplier_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
  printClick(data, exportType) {

  }

  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.EDIT) {
      this.openFormHandler(data, PageState.EDIT_STATE);
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteCategoryBySingleId(data);
        });
    }
    if (btnAction == ButtonActions.VIEW) {
      this.openFormHandler(data, PageState.VIEW_STATE);
    }
  }

  deleteCategoryBySingleId(data) {
    this.showLoader();
    let Id = this.getIdsFromList([data]);
    this.categorySupplierService.deleteCategorySupplierById(Id).
      subscribe(res => {
        this.hideLoader();
        this.alertService.success("deleteOne.successfull", true);
        this.getCategorySupplierList();
      }, error => {
        this.hideLoader();
      })
  }

  deleteAllClick(data) {
    let Id = this.getIdsFromList(data);
    console.log("data", data)
    this.showLoader();
    this.categorySupplierService.deleteCategorySupplierById(Id).
      subscribe(res => {
        this.hideLoader();
        this.alertService.success("deleteOne.successfull", true);
        this.getCategorySupplierList();
      }, error => {
        this.hideLoader();
      })
  }
  goBackToMainPage() {
    this.routingService.openPage(RouteConstants.ADMIN_LIBRARY_CATEGORY);
  }
}
