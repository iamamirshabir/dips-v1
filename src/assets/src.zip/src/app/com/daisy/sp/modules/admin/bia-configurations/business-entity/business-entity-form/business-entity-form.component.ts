import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';

@Component({
  selector: 'app-business-entity-form',
  templateUrl: './business-entity-form.component.html',
  styleUrls: ['./business-entity-form.component.sass']
})
export class BusinessEntityFormComponent extends BaseClass implements OnInit {

  businessEntityForm: FormGroup;
  routeParams: any;
  public modalData: any;
  public wasFormChanged = false;

  constructor(private formBuilder: FormBuilder, public dialog: MatDialog, public dialogRef: MatDialogRef<BusinessEntityFormComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.initialiseFormData();
    this.modalData = data;
  } 
  get f() { return this.businessEntityForm.controls; }
  ngOnInit(): void {
    if(this.modalData.pageState && this.modalData.data){
      if(this.modalData.pageState == this.PageState.VIEW_STATE){
        this.businessEntityForm.disable();
      }
      this.businessEntityForm.patchValue(this.modalData.data);
    }
  }

  initialiseFormData() {
    this.businessEntityForm = this.formBuilder.group({
      name:[null, Validators.required],
      description: [''],
      id: [null],
      version: [null]
    });
  }

  formChanged() {
    this.wasFormChanged = true;
  }
  closeModal(): void {
    this.dialogRef.close(null);
  }

  saveFormData(): void {
    if (this.businessEntityForm.invalid) {
      Object.keys(this.businessEntityForm.controls).forEach(field => {
        const control = this.businessEntityForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      return;
    }
    
    this.modalData.data = this.businessEntityForm.value;
    this.dialogRef.close(this.modalData);
  }

}
