import { Component, OnInit } from '@angular/core';
import { BaseClass } from '../../../../utils/baseclass';
import { Router, ActivatedRoute } from '@angular/router';
import { RouteParams } from '../../../../utils/model.route-params';
import { RouteConstants } from '../../../../utils/constants/route-constants';
import { PageState } from '../../../../utils/constants/page-state-constants';
import { element } from 'protractor';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';
import { group } from '@angular/animations';
import { SourceListMap } from 'source-list-map';

@Component({
  selector: 'app-contact-group-hierarchy',
  templateUrl: './contact-group-hierarchy.component.html',
  styleUrls: ['./contact-group-hierarchy.component.sass']
})
export class ContactGroupHierarchyComponent extends BaseClass implements OnInit {

  contactGroupList;
  contactGroupId;
  parentContactGroup: any;
  ContactGroupTitle: any = '';
  listingView: boolean = false;
  public displayedColumns: any;
  public tableButtons: any;
  public filterSelectObj: any = [];
  iListingView: IListingView;

  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    super();
    this.activatedRoute.queryParams.subscribe(val => {
      this.contactGroupId = 0;
    })
  }

   openFormByState(data){
    this.hideLoader();
    this.initializePageData();
   }

  initializePageData() {
    let params = this.currentNavigation.extras.state as RouteParams;
    if (params && params.id) {
      this.contactGroupId = params.id
    }
    this.getContactGroupList();
  }

  ngOnInit(): void { 

    this.displayedColumns = [{ key: 'select', name: '',checked: 'true' },
    { key: 'name', name: 'Name', checked: 'true' },
    { key: 'description', name: 'Description', checked: 'true' },
    { key: 'updatedOn', name: 'Last Updated', checked: 'true' },
    { key: 'rolesString', name: 'Roles'},
    { key: 'deputiesString', name: 'Deputies'},
    { key: 'action', name: '',checked: 'true' }];

    this.tableButtons = [{ "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
    { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }];

    this.filterSelectObj = [
    { name: 'Name', columnProp: 'name', options: [] },
    { name: 'Description', columnProp: 'description', options: [] },
    { name: 'Last Updated', columnProp: 'updatedOn', options: [] }];

    if(this.contactGroupList){
        this.setDataTable(this.contactGroupList);
    }else{
      this.setDataTable([]);
    }
    
  }

  setDataTable(tableData) {
    this.iListingView = {
      listTitle: "",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: true,
      search: true,
      recordsPerpage: true,
      showSelectAll: true,
      showFilters: true,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.ContactListChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }

  async getContactGroupList() {
    this.showLoader()
    await this.contactGroupService.getContactGroupByParentId(this.contactGroupId).
      subscribe(contactGroupList => {
        if (contactGroupList) {
          this.contactGroupList = contactGroupList;
          this.parentContactGroup = '';
          this.setDataTable(this.contactGroupList)
        }
        if (this.contactGroupId > 0) {
          this.contactGroupService.getContactGroupById(this.contactGroupId).
            subscribe(contactGroup => {
              this.parentContactGroup = contactGroup;
            }, error => { })
        }
        this.hideLoader();
      }, error => { });
  }

  deleteAllClick(data){
    this.showLoader();
    this.contactGroupService.removeAllContactGroups(data).
      subscribe(res => {
        this.hideLoader();
        this.getContactGroupList();
      }, error => {
        this.hideLoader();
      })
   }

  openChildContactGroups(contactGroup) {
    this.showLoader();
    this.contactGroupId = contactGroup.id;
    let routeParams: RouteParams = new RouteParams();
        routeParams.id = contactGroup.id;
        routeParams.name = contactGroup.name;
        routeParams.pageState = PageState.EDIT_STATE;
        routeParams.parentParams = this.pageParams;
        routeParams.routerLink = RouteConstants.CONTACT_GROUPS_HEIRARCHY;
    this.reloadCurrentPage(routeParams.routerLink, routeParams);
  }

  openContactGroupRoles(contactGroup) {
    let routeParams: RouteParams = new RouteParams();
    routeParams.id = contactGroup.id;
    routeParams.name = contactGroup.name;
    routeParams.data = contactGroup;
    routeParams.pageState = PageState.ADD_STATE;
    routeParams.parentParams = this.pageParams;
    routeParams.routerLink = RouteConstants.CONTACT_GROUPS_ROLE;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }

  addNewContactGroup() {
    let routeParams: RouteParams = new RouteParams();
    routeParams.pageState = PageState.ADD_STATE;
    routeParams.parentParams = this.pageParams;
    routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }

  contactGroupOperations(group, param) {
    if (param === 'edit') {
      let routeParams: RouteParams = new RouteParams();
      routeParams.id = group.id;
      routeParams.pageState = PageState.EDIT_STATE;
      routeParams.parentParams = this.pageParams;
      routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
      this.routingService.openPage(routeParams.routerLink, routeParams);

    } else if (param === 'view') {
      let routeParams: RouteParams = new RouteParams();
      routeParams.id = group.id;
      routeParams.pageState = PageState.VIEW_STATE;
      routeParams.parentParams = this.pageParams;
      routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
      this.routingService.openPage(routeParams.routerLink, routeParams);

    }
    else if (param === 'addSubgroup') {
      let routeParams: RouteParams = new RouteParams();
      routeParams.id = group.id;
      routeParams.pageState = PageState.ADD_STATE;
      routeParams.parentParams = this.pageParams;
      routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
      this.routingService.openPage(routeParams.routerLink, routeParams);
    }
    else if (param === 'removeGroup') {  
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () { 
          that.removeContactGroupById(group.id);
        });  
    }
  }
  removeContactGroupById(id){ 
    this.showLoader()
    this.contactGroupService.removeContactGroupById(id).subscribe(contactgroupheirarchy => {
      this.hideLoader();
      this.alertService.success("Successfully Removed");
      this.getContactGroupList();
    },error => {this.hideLoader();});
  }
  closePage(){
    let routeParams: RouteParams = new RouteParams();
      if(this.pageParams.parentParams){
        routeParams = this.pageParams.parentParams;
      }
      else{
        routeParams = this.pageParams;
      }
      routeParams.routerLink = RouteConstants.CONTACT_GROUPS_HEIRARCHY;
    this.reloadCurrentPage(routeParams.routerLink, routeParams);
  }

  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data;
    if (btnAction == ButtonActions.VIEW) {
      this.contactGroupOperations(data, 'view');
    }
    if (btnAction == ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deleteContactById(data.id);
        });
    }
    if (btnAction == ButtonActions.EDIT) {
      this.contactGroupOperations(data, 'edit');
    }

  }

  deleteContactById(id) {
    this.showLoader();
    this.contactGroupService.removeContactGroupById(id).
      subscribe(res => {
        this.alertService.success("deleteOne.successfull", true);
        this.hideLoader();
        this.getContactGroupList();
      }, error => {
        this.hideLoader();
      })
  }

  btnDoubleClicked(data) {
    this.openChildContactGroups(data);
    //  here we will call for childern and set it in table
    // this.openFormHandler(data, PageState.EDIT_STATE);
  }
  
  openFormHandler(data = null, pageState) {
    let routeParams: RouteParams = new RouteParams();
    if (data) {
      routeParams.id = data['id'];
    }
    routeParams.pageState = pageState;
    routeParams.routerLink = RouteConstants.CONTACT_GROUPS_FORM;
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }


  listView(){
    let routeParams: RouteParams = new RouteParams();
    routeParams.routerLink = RouteConstants.CONTACT_GROUPS_LISTING
    this.routingService.openPage(routeParams.routerLink, routeParams);
  }
}
