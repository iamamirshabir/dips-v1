import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Api } from '../../../../utils/api';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryBusinessAreaService {

  constructor(private httpClient: HttpClient) { }
  public catBusinessAreaDetails: any;
  getSubCategories(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategoryBuisnessAreaByOrgId(orgID) {
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_BUSINESS_AREA_FIND_BY_ORG_ID + '/' + orgID);
  }
  getRealEntityByOrgId(id){
    return this.httpClient.post<any>(`${environment.baseUrl}`+Api.REAL_ENTITY_FIND_BY_ORG_ID+"/"+id,id);
  }
  getCategoryITByOrgId(orgID){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_IT_SERVICE_FIND_BY_ORG_ID + '/' + orgID);
  }
  getCategoryBusinessAreaById(id){
    return this.httpClient.get<any>(`${environment.baseUrl}` + Api.CATEGORY_BUSINESS_AREA_SERVICE_FIND_BY_ID + '/' + id);
  }
  saveCategoryBusinessArea(data): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_BUSINESS_AREA_SERVICE_SAVE}`, data);
  }

  deleteCategoryBuisnessAreaById(id): Observable<any> {
    return this.httpClient.post(`${environment.baseUrl + Api.CATEGORY_BUSINESS_AREA_SERVICE_REMOVE_BY_ID}`, id);
  }
  getBusinessEntityByOrgId(orgID){
    return this.httpClient.get(`${environment.baseUrl + Api.BIA_CONFIGURATIONS_BUSINESS_ENTITY_BY_ORG_ID}` + orgID);
  }
  getBusinessEntityByOrgIdAndCanDoBia(orgID){
    return this.httpClient.get(`${environment.baseUrl + Api.CATEGORY_BUSINESS_AREA_FIND_BY_ORG_ID}/` + orgID + Api.CAN_DO_BIA);
  }
  getCategoryBuisnessAreaBySearchCriteria(data){
    return this.httpClient.post<any>(`${environment.baseUrl}` + Api.SEARCH_BUSINESS_AREA, data);
  }
}
