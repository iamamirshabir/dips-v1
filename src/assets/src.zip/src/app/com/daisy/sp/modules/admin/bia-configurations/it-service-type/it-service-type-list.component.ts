import { AfterViewInit, Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { SHARE_ENV } from 'worker_threads';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { BaseClass } from '../../../../utils/baseclass';
import { ButtonActions } from '../../../../utils/constants/btn-types-constants';
import { MatIcons } from '../../../../utils/constants/mat-icons-constants';
import { ItServiceTypeComponent } from './it-service-type-form/it-service-type.component';

@Component({
  selector: 'app-it-service-type',
  templateUrl: './it-service-type-list.component.html',
  styleUrls: ['./it-service-type-list.component.sass']
})
export class ItServiceTypeListComponent extends BaseClass implements OnInit {

  private tableButtons:any;
  private displayedColumns:any;
  private iListingView:IListingView;
  private filterSelectObj:any[];
  private dialogRef:MatDialogRef<ItServiceTypeComponent> | null;
  myOrganisation: any;

  constructor(public dailog:MatDialog) {
    super();
  }

  ngOnInit(): void {
    this.displayedColumns = [
    { key: 'select', name: '' ,checked: 'true'},
    { key: 'name', name: 'Name',checked: 'true'},
    { key: 'description', name: 'Description', checked: 'true'},
    { key: 'action', name: '' ,checked: 'true'}
  ];

    this.filterSelectObj = [{name : 'Name',columnProp : 'name', option : []},
    {name : 'Description',columnProp : 'description', option : []}
    ];

    this.tableButtons = [
      { "name": "Delete", "type": ButtonActions.DELETE_ALL, "icon": MatIcons.DELETE },
      { "name": "Add", "type": ButtonActions.ADD, "icon": MatIcons.ADD }
    ];
    this.setTableData([]);
  }

 private setTableData(data){
   this.iListingView = {
    listTitle: this.languageTranslator('admin.confirguration.it.service.type'),
    displayedColumns: this.displayedColumns,
    dataSource: data,
    tableButtons: this.tableButtons,
    pagination: true,
    search: true,
    recordsPerpage: true,
    showSelectAll: true,
    showFilters: true,
    filterSelectObj: this.filterSelectObj,
    chevronMenuClassName: ChevronMenuClassName.ItServiceTypeListCheveronMenue,
    listObject:new Object
   }
   this.listingViewService.sendListingView(this.iListingView);
 }

 ngAfterViewInit(){
  this.getandSetList();
 }

 private getandSetList() {
    this.showLoader();
    this.itServiceTypeService.listByOrganisationId(this.organisation.id).subscribe(
      result => {
        this.hideLoader();
        this.setTableData(result);
      },
        error =>{
          this.hideLoader()
          this.setTableData([]);
        }
    )
 }

 btnDoubleClicked(record){
  let data = {"data": record, "pageState": this.PageState.EDIT_STATE};
  this.openDialog(data);
 }


 save(data){
  this.showLoader();
  this.itServiceTypeService.save(data).subscribe(res => { 
    this.hideLoader();
    this.alertService.success('creation.successfull', true);
   this.getandSetList();
   }, error => {
     this.setTableData([]);
   })
 }

 update(data){
  this.showLoader();
  this.itServiceTypeService.update(data).subscribe(res => { 
    this.hideLoader();
    this.alertService.success('updation.successfull', true);
   this.getandSetList();

   }, error => {
     this.setTableData([]);
   })
}

openFormHandler(record){
  let data = {"data": record, "pageState": this.PageState.ADD_STATE};
  this.openDialog(data);
}

openDialog(data) {
    this.dialogRef = this.dailog.open(ItServiceTypeComponent, {
      width: '600px',
      disableClose: true,
      hasBackdrop: true,
      data: data
    });
    this.dialogRef.afterClosed().subscribe( result =>{
      let resultData = result ? result.data : null;
      if(result){

        if(result.pageState == this.PageState.ADD_STATE){
          resultData.organisation = this.organisation;
          this.save(resultData);
        } else if(result.pageState == this.PageState.EDIT_STATE){
          this.update(resultData);
        }
      }
      this.dialogRef = null;
    })
  }

  chevronMenuClick(menue){
     let action = menue.btnAction;
    if(action == ButtonActions.EDIT){
      this.btnDoubleClicked(menue.data)
    }else if(action == ButtonActions.VIEW){
      let data = {"data": menue.data, "pageState": this.PageState.VIEW_STATE};
      this.openDialog(data);
    }else if(action == ButtonActions.DELETE){
      let that = this;
        this.alertService.confirmation("deleteOneConfirm",
          function () {
            that.delete( menue.data.id);
        }); 
    }
  }

  delete(id) {
    this.showLoader();
    let list:number[] = [ id ];
    this.itServiceTypeService.delete(list).
    subscribe(res => { 
      this.hideLoader();
      this.getandSetList();
    }, error => { 
      this.hideLoader();
    }) 
  }

  deleteAllClick(data) {
    let list:number[] = [];
    data.forEach(element => { 
      list.push(element.id);
    });
    this.showLoader();
    this.itServiceTypeService.delete(list).
    subscribe(res => {
      this.hideLoader();
      this.getandSetList();
    }, error => { 
      this.hideLoader();
    }) 
  }


}
