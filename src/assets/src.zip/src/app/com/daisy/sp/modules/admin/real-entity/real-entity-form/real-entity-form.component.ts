import { Component, OnInit, Inject, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseClass } from '../../../../utils/baseclass';
import { IListingView } from '../../../../common/components/listing-view/listing-view.interface';
import { ChevronMenuClassName } from '../../../../common/components/chevron-menus/chevron-menu-class-names';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';

@Component({
  selector: 'app-real-entity-form',
  templateUrl: './real-entity-form.component.html',
  styleUrls: ['./real-entity-form.component.sass']
})
export class RealEntityFormComponent extends BaseClass implements OnInit {
  private _transformer = (node: any, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
      data: node,
    };
  }
  treeControl = new FlatTreeControl<any>(node => node.level, node => node.expandable);
  treeFlattener = new MatTreeFlattener(this._transformer, node => node.level, node => node.expandable, node => node.children);

  public breakpoint: number;
  public name: string = ``;
  public address: string = ``;
  public organisation: any;
  public addRealEntityForm: FormGroup;
  public addPerspectiveForm: FormGroup;
  public modalData: any;
  public wasFormChanged = false;
  public contentHeight = '';
  public addedPerspectives: any[] = [];
  public perspectivesTree: any[] = [];
  public perspectivesCount: any = 0;
  public saveClicked:boolean = false;
  @ViewChild('matDialogRealEntity') matDialogRealEntity: ElementRef;

  selectedPerspective: any = '0';

  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RealEntityFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    super();
    this.modalData = data;
  }

  public ngOnInit(): void {
    this.addRealEntityForm = this.fb.group({
      name: [null, [Validators.required]],
      address: [null],
      parentName: [null],
      perspectives: [null],
    });
    if (this.modalData) {
      this.addRealEntityForm.patchValue({
        parentName: this.modalData.node ? this.modalData.node.parent?this.modalData.node.parent.name:"" : this.modalData.parentNode ? this.modalData.parentNode.name : "",
        name: this.modalData.node ? this.modalData.node.name : "",
        address: this.modalData.node ? this.modalData.node.address : "",
        perspectives: this.modalData.node ? this.modalData.node.perspectives : [],
      });
      this.addedPerspectives = this.modalData.node ? this.modalData.node.perspectives : []; 
    }
    this.breakpoint = window.innerWidth <= 600 ? 1 : 1; // Breakpoint observer code 

    this.tableButtons = [];
    this.filterSelectObj = [];
    this.getPerspectivesTree();
  }
  hasChild = (_: number, node: any) => node.expandable;
  ngAfterViewInit() {
   setTimeout(() => {
       this.contentHeight = (this.matDialogRealEntity.nativeElement.offsetHeight - 60) + 'px';
    },1000);
   
    this.setDataTable(this.addedPerspectives);
  }
  getPerspectivesTree() {
    this.realEntityService.getPerspectivesListByOrgId(this.organisation.id).subscribe(data => {
      let response: any = data;
      if (response && response.children) {
        this.sortTreeData(response.children);
        this.perspectivesTree = response.children;
        this.perspectivesTree.forEach(perspectives => {
          perspectives.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
          perspectives.dataSource.data = [perspectives]
        });
      } else {
        this.perspectivesTree = [];
      } 
      this.makeTableHeading(this.perspectivesTree);
      this.addPerspectiveForm = this.makeDynamicFormGroup(this.perspectivesTree);
      this.setDataTable(this.addedPerspectives);
    }); 
  }
  sortTreeData(treeData) { 
    treeData.forEach(element => { 
      if (element.children && element.children.length > 0) {
        element.children = element.children.sort((a, b) => a.order - b.order);
        this.sortTreeData(element.children);
      } 
    }); 
  }
  makeTableHeading(perspectivesTree) {
    if (perspectivesTree && perspectivesTree.length > 0) {
      let index:any = 0;
      perspectivesTree.forEach(element => {
        if(index==0){
          this.displayedColumns.push({ key:'perspective1Name', name: element.name, checked: 'true' }) 
        }else if(index==1){
          this.displayedColumns.push({ key:'perspective2Name', name: element.name, checked: 'true' }) 
        }else if(index==2){
          this.displayedColumns.push({ key:'perspective3Name', name: element.name, checked: 'true' }) 
        }else if(index==3){
          this.displayedColumns.push({ key:'perspective4Name', name: element.name, checked: 'true' }) 
        }else if(index==4){
          this.displayedColumns.push({ key:'perspective5Name', name: element.name, checked: 'true' }) 
        } 
        index++;
      });
    }
    this.displayedColumns.push({ key: 'action', name: '', checked: 'true' });
  }
  makeDynamicFormGroup(perspectivesTree){
    const group: any = {};
    if (perspectivesTree && perspectivesTree.length > 0) {
      perspectivesTree.forEach(pers => {
        group[pers.name] = new FormControl('');
      });
    }
    return new FormGroup(group);
  }
  
  saveRealEntity(): void {
    if (this.addRealEntityForm.invalid) {
      return;
    } 
    let perspectives = this.addedPerspectives;
    if (this.modalData && this.modalData.node) {
      this.modalData.node.name = this.addRealEntityForm.value['name'];
      this.modalData.node.address = this.addRealEntityForm.value['address'];
      this.modalData.node.perspectives = perspectives;  
    } else {
      this.modalData.node = { "name": this.addRealEntityForm.value['name'], 
                              "address": this.addRealEntityForm.value['address'],
                              "perspectives":perspectives }
    }
    this.dialogRef.close(this.modalData);
  }

  closeRealEntityModal(): void {
    this.dialogRef.close(null);
  }

  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 1;
  }

  private markAsDirty(group: FormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  } 
  addPerspective() {
    let data: any = new Object;
    let index = 0;
    this.displayedColumns.forEach(column => {
      if (column.key != 'action') {
        data[column.key] = this.addPerspectiveForm.value[column.name].name;
        
      let cloneObject = Object.assign({}, this.addPerspectiveForm.value[column.name].data);
      cloneObject.dataSource = null;
        if(index==0){
          data['perspective1'] = cloneObject;
        }else if(index == 1){
          data['perspective2'] = cloneObject;
        }else if(index == 2){
          data['perspective3'] = cloneObject;
        }else if(index == 3){
          data['perspective3'] = cloneObject;
        }else if(index == 4){
          data['perspective3'] = cloneObject;
        }
      }
      index++;
    }); 
    this.addedPerspectives.push(data) 
    this.setDataTable(this.addedPerspectives);
  }
  resetPerspective() {

  }

  iListingView: IListingView;
  public tableData: any[] = [];
  public displayedColumns: any[] = [];
  public tableButtons: any;
  public filterSelectObj: any = [];
  chevronMenuClick(chevronMenu: any) {
    let btnAction = chevronMenu.btnAction;
    let data = chevronMenu.data; 
    if (btnAction == this.ButtonActions.DELETE) {
      let that = this;
      this.alertService.confirmation("deleteOneConfirm",
        function () {
          that.deletePerspective(data.id);
        });
    } 
  }
  deletePerspective(persId){
    this.addedPerspectives = this.addedPerspectives.filter(item=> item.id != persId); 
    this.setDataTable(this.addedPerspectives);
  }
  setDataTable(tableData) { 
    if(tableData && tableData.length>0){
       tableData.forEach(element => {
        element.perspective1Name = element.perspective1?element.perspective1.name:'';
        element.perspective2Name = element.perspective2?element.perspective2.name:'';
        element.perspective3Name = element.perspective3?element.perspective3.name:'';
        element.perspective4Name = element.perspective4?element.perspective4.name:'';
        element.perspective5Name = element.perspective5?element.perspective5.name:'';
     }); 
    }
    this.iListingView = {
      listTitle: "",
      displayedColumns: this.displayedColumns,
      dataSource: tableData,
      tableButtons: this.tableButtons,
      pagination: false,
      search: false,
      recordsPerpage: false,
      showSelectAll: false,
      showFilters: false,
      filterSelectObj: this.filterSelectObj,
      chevronMenuClassName: ChevronMenuClassName.PerspectivesChevronMenu,
      listObject: new Object
    }
    this.listingViewService.sendListingView(this.iListingView);
  }
}