import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ItServiceTypeComponent } from './it-service-type-form/it-service-type.component';

describe('ItServiceTypeComponent', () => {
  let component: ItServiceTypeComponent;
  let fixture: ComponentFixture<ItServiceTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItServiceTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItServiceTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
