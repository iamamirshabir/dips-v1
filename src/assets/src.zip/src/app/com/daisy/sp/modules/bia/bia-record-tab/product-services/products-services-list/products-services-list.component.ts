
import { BaseClass } from 'src/app/com/daisy/sp/utils/baseclass';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RouteConstants } from '../../../../../utils/constants/route-constants';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { BehaviorSubject } from 'rxjs';
import { ButtonActions } from 'src/app/com/daisy/sp/utils/constants/btn-types-constants';
import { SpChipFormFieldComponent } from 'src/app/com/daisy/sp/common/components/sp-chip-form-field/sp-chip-form-field.component';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { GlobalConstants } from 'src/app/com/daisy/sp/utils/global-constants';
import { CategoryTypes } from '../../../../../utils/constants/category-types'



@Component({
  selector: 'app-products-services-list',
  templateUrl: './products-services-list.component.html',
  styleUrls: ['./products-services-list.component.sass']
})
export class ProductsServicesListComponent extends BaseClass {

  displayColumns = ['name', 'description', 'processes', 'actions'];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  routeParams: any;
  productServices: FormArray = this.fb.array([]);
  modalFormGroup: FormGroup = this.fb.group({ 'productServices': this.productServices });
  @ViewChild(MatSort) sort: MatSort;
  biaRecordId: any;
  biaType: any;
  biaRecord: any;
  processes: any;
  selectedProcess: any;
  memberDropped: any;
  globals: GlobalConstants;
  @ViewChild('productField') productField: SpChipFormFieldComponent;
  selectedBiaCategory: any;


  constructor(private fb: FormBuilder, private elRef: ElementRef, globals: GlobalConstants) {

    super();
    this.globals = globals;

  }

  ngOnInit(): void {

  }

  patchDescription(ev) {
    console.log(ev);
    var rowSelected = ev;
    if (rowSelected.value.productService != null) {
      rowSelected.controls.description.patchValue(rowSelected.value.productService[0].description)
    }

  }

  openFormByState(routeParams) {
    this.hideLoader();
    this.routeParams = routeParams;
    this.routedPageState = this.routeParams['pageState'];
    this.biaRecordId = this.routeParams.data.id;
    this.biaType = this.routeParams.parentParams;
    this.biaRecord = this.routeParams.data;
    this.selectedBiaCategory = this.biaRecord.categoryRecord.category.type;
    this.getProcesses(this.biaRecordId);
    this.productService.getProductsByBIA(this.biaRecordId).subscribe((res) => {
      if (res.length >= 1) {
        this.patchBusinessAreaValues(res);

      }
      else {
        this.addRow();
      }
    }, err => {
      console.log(err);
    })
  }
  patchBusinessAreaValues(res) {
    var productValues = res;
    let i = 0;
    productValues.forEach(Rows => {
      this.addRow();
      this.productServices.patchValue(res);
      this.productServices['controls'][i]['controls'].description.patchValue(Rows.productService.description);
      i++;
      this.updateView();
    });

  }


  emptyTable() {
    while (this.productServices.length !== 0) {
      this.productServices.removeAt(0);
    }
  }
  compareObjects(o1: any, o2: any): boolean {
    return o1.name === o2.name && o1.id === o2.id;
  }
  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.id === f2.id;
  }

  addRow(noUpdate?: boolean, droppedElement = null, objectToReplace = null) {
    this.globals.DROPPED_ID_ARRAY = [];
    if (objectToReplace != null && objectToReplace.key === 2) {
      var row = this.fb.group({
        id: [null],
        version: [null],
        productService: [null],
        description: [null],
        processes: [null, Validators.required],
      });
      this.productServices.insert(objectToReplace.index, row);
    }
    else {
      if (this.productServices.controls[this.productServices.controls.length - 1] != undefined) {
        if (this.productServices.controls[this.productServices.controls.length - 1]['controls'].productService.invalid) {
          this.productServices.controls[this.productServices.controls.length - 1]['controls'].productService.markAsTouched();
          return
        }
      }
      var row = this.fb.group({
        id: [null],
        version: [null],
        productService: [null],
        description: [null],
        processes: [null, this.decideValidator()],
      });
      this.productServices.push(row);
    }
    if (!noUpdate) { this.updateView(); }
    if (droppedElement != null) {
      row.controls.productService.patchValue(droppedElement);
    }
    for (var i = 0; i < this.productServices.controls.length; i++) {
      this.globals.DROPPED_ID_ARRAY.push('list-' + i)
    }

  }

  updateView() {
    this.dataSource.next(this.productServices.controls);
  }
  dropFromSearch(event: CdkDragDrop<string[]>, businessAreaRow) {
    this.memberDropped = event.previousContainer.data;

    if (this.memberDropped[0].category.type != CategoryTypes.PRODUCT) {
      return
    }

    if (businessAreaRow.value.productService === null) {
      if (this.memberDropped.length === 1 && this.productServices.value[0].productService === null) {
        this.productServices.controls[0]['controls'].productService.patchValue(this.memberDropped[0]);
        this.productField.patchDataInControls(this.productServices.controls[0]['controls'].productService.value);
      }
      else if (this.memberDropped.length === 1 && this.productServices.value[this.productServices.value.length - 1].productService === null) {
        this.productServices.controls.pop();
        this.addRow(false, this.memberDropped[0]);
      }
      else if (this.memberDropped.length > 1 && this.productServices.value[0].productService === null) {
        this.productServices.controls[0]['controls'].productService.patchValue(this.memberDropped[0]);
        this.productField.patchDataInControls(this.productServices.controls[0]['controls'].productService.value);
        for (var i = 1; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else if (this.memberDropped.length > 1 && this.productServices.value[this.productServices.value.length - 1].productService === null) {
        this.productServices.controls.pop();
        for (var i = 0; i < this.memberDropped.length; i++) {
          if (this.memberDropped[i]['dragged']) {
            this.addRow(false, this.memberDropped[i]);
          }
        }
      }
      else {
        this.memberDropped.forEach(droppedElement => {
          if (droppedElement['dragged']) {
            this.addRow(false, droppedElement);
          }
        });
      }
    }

    else {
      if (this.memberDropped.length > 1) {
        this.alertService.error("You can replace single record at a time");
        return
      }
      const index = this.productServices.controls.indexOf(businessAreaRow);
      var row = this.productServices.controls[index];
      if (row.value.id != null) {
        this.productService.deleteAllProducts([row.value.id]).subscribe((res) => { });
      }
      this.productServices.removeAt(index);
      var memberObject = { key: 2, index: index, memberDropped: this.memberDropped[0], rowDropped: businessAreaRow };
      this.addRow(false, this.memberDropped[0], memberObject);
    }
  }


  deleteRow(index: number, row) {
    const control = this.modalFormGroup.get('productServices') as FormArray;
    if (this.productServices.controls.length === 0) {
      this.addRow();
    }
    if (row.value.id != null) {
      let that = this;
     
        this.alertService.confirmation("deleteListConfirm",
          function () {
            that.productService.deleteAllProducts([row.value.id]).subscribe((res) => {
            
              control.removeAt(index);
            that.updateView();
            that.alertService.success("Successfully Deleted");
            }, err => {
              console.log(err);
            })
          });
    }
    else if (row.value.id === null) {
      let that = this;
      if (this.productServices.at(index).dirty) {
        this.alertService.confirmation("deleteListConfirm",
          function () {
            control.removeAt(index);
            that.updateView();
            that.alertService.success("Successfully Deleted");
          });
      }
      else {
        
        control.removeAt(index);
        that.updateView();
      }
    }
  }
  clickComplete(btnAction: ButtonActions) {
    this.showLoader();
    this.biaRecord['productServicesComplete'] = true;
    this.productService.saveBiaRecord(this.biaRecord).subscribe((res) => {
      this.hideLoader();
      this.alertService.success('Product Service Completed Successfully', true);
      var index = this.routeParams.nextRouterLink.findIndex(x => x.route === this.routeParams.routerLink);
      this.routeParams.routerLink = this.routeParams.nextRouterLink[index + 1].route;
      this.biaRecord = res;
      this.navigationHandlerAfterSave(btnAction, res, this.routeParams.nextRouterLink[index + 1].route, this.routeParams);
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  onSubmit(btnAction: ButtonActions) {
    if (this.productServices.invalid) {
      return
    }
    this.showLoader();
    this.productServices.value.forEach(data => {
      data['bia'] = this.biaRecord;
      if (Array.isArray(data.productService)) {
        data.productService = data.productService[0];
      }
    });

    this.productService.saveAllProducts(this.productServices.value).subscribe((res) => {
      this.navigationHandlerAfterSave(btnAction, res, RouteConstants.BIA_RECORD, this.routeParams);
      this.hideLoader();
      if (this.routedPageState === 1) {
        this.alertService.success("Successfully Created");
      }
      else {
        this.alertService.success("Successfully Updated")
      }
    }, err => {
      this.hideLoader();
      console.log(err);
    });
  }
  getProcesses(biaID) {
    this.showLoader();
    this.productService.getProcessesByBIA(biaID).
      subscribe(res => {
        this.hideLoader();
        this.processes = res;
        this.setProcesses(this.processes)

      }, error => {
        this.hideLoader();

      })
  }


  setProcesses(processes) {
    let i = 0
    if (processes.length > 0) {
      processes.forEach(value => {
        i++;
        value.processesName = "Process" + " " + (i) + " " + "-" + " " + "Customer Service" + " " + "|" + " " + value.name;
      });
    }

  }
  goBackToMainPage(btnAction: ButtonActions) {
    var arrayControls = [];
    arrayControls.push(this.modalFormGroup.get('productServices'));
    this.navigationHandlerAfterSave(btnAction, "", RouteConstants.BIA_RECORD, this.routeParams);
  }

  decideColumns() {
    if (this.selectedBiaCategory == CategoryTypes.BUSINESS_AREA) {
      this.displayColumns = ['name', 'description', 'processes', 'actions'];
    } else {
      this.displayColumns = ['name', 'description', 'actions'];
    }
    return this.displayColumns;
  }

  decideValidator(): ValidationErrors {
    if (this.selectedBiaCategory == CategoryTypes.BUSINESS_AREA) {
      return Validators.required;
    } else {
      return null;
    }
  }

}
