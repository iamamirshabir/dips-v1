import { AfterViewChecked, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent implements OnInit, AfterViewChecked {
  constructor(private router: Router, private changeDetect: ChangeDetectorRef) {
  }

  ngOnInit() {
    var currentRoute = window.location.href;
    var isForrgotPassword = currentRoute.search("reset-password");
    if (isForrgotPassword == -1) {
      this.router.navigate([''])
    }
  }
  ngAfterViewChecked() {

    this.changeDetect.detectChanges(); 

  }
}
