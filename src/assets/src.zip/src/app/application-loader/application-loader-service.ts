import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, forkJoin } from 'rxjs';
import { Api } from '../com/daisy/sp/utils/api';

@Injectable({
  providedIn: 'root'
})
export class ApplicationLoaderService {
    constructor(private httpClient : HttpClient){}

    getLoggedInUser(contactId):Observable<any> {
        return this.httpClient.get(`${environment.baseUrl + Api.GET_LOGGED_IN_USER_INFO}`); 
    }

    getLanguageById(Id){
        return this.httpClient.get(`${environment.baseUrl + Api.LANGUAGE_FIND_BY_ID}/`+Id);
    }

    getLanguagePropertiesById(languageId){
        return this.httpClient.get(`${environment.baseUrl + Api.LANGUAGE_FIND_LANGUAGE_PROPERTIES_BY_ID}/`+languageId);
    }
    
}