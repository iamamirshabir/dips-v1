import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from '../core-services/loader.service';
import { TokenStorageService } from '../core-services/token.storage.service';
import { MainLayoutService } from '../com/daisy/sp/main-layout/main-layout-service';
import { ApplicationLoaderService } from './application-loader-service';
import { timer } from 'rxjs';
import { RealEntityService } from '../com/daisy/sp/modules/admin/real-entity/real-entity.service';

@Component({
  selector: 'app-application-loader',
  templateUrl: './application-loader.component.html',
  styleUrls: ['./application-loader.component.sass']
})
export class ApplicationLoaderComponent implements OnInit{
  info : any = 'Loading Languages...';
  progress : number = 0;
  user : any;
  constructor(private router: Router, 
              private applicationLoaderService : ApplicationLoaderService,
              private realEntityService:RealEntityService, 
              private tokenStorage: TokenStorageService, 
              private mainLayoutService : MainLayoutService) { 
    this.user = this.tokenStorage.getUser();
  }

  ngOnInit(){
    this.progress = 10
    timer(500).subscribe(val =>{
      this.getLoggedInUser();
    })  
  }

  getLoggedInUser(){
    this.info = 'Loading User Info...'
    let contactId = this.user.id;
    this.applicationLoaderService.getLoggedInUser(contactId).
      subscribe(data => {
        this.mainLayoutService.setloggedInUser(data.contact);
        this.mainLayoutService.setloggedInOrganisation(data.organisation);
        this.progress = 20;
        this.getOrganisationLanguage(data.organisation)
      },error =>{})
  }
  getOrganisationLanguage(organisation){
    this.info = 'Loading Organisation Info...'
    this.progress = 30
    this.applicationLoaderService.getLanguageById(organisation.language.id).
    subscribe(language => {
        this.progress = 40
        this.getApplicationData(language)
    },error =>{})
  }

  getApplicationData(language){
    this.info = 'Loading Language Info...'
    this.progress = 50
    this.applicationLoaderService.getLanguagePropertiesById(language.id).
    subscribe(res => {
      this.progress = 60
      this.getRealEntitiesList();
    },error =>{}) 
  } 
 
  getRealEntitiesList() {
    this.info = 'Loading Real Entities...'
    this.progress = 70
    let id = this.mainLayoutService.getloggedInOrganisation().id; 
    this.realEntityService.getRealEntityListByOrgId(id).subscribe(data => {
      this.mainLayoutService.setRealEntitiesList(data); 
      this.progress = 100
      this.router.navigate(['/shadowplanner'])
    }, error => { 
    });
  } 
}
